# Paper 1 / JBES figure reproduction code

Paper: **Bounded State Updating under Extreme Macroeconomic Releases and Data Revisions**

This compact bundle reproduces the four PDF figures currently referenced by the JBES manuscript:

1. `figure1_response.pdf` — bounded mean response and working-uncertainty response.
2. `figure2_realtime_paths.pdf` — March–August 2020 EMPLOY/CUT real-time forecast paths.
3. `figure2_controlled.pdf` — controlled accumulation and recovery comparison.
4. `figure3_refitting.pdf` — refitting contribution and CB–MB fitted-layer contrast.

## Run

From the bundle root:

```bash
python scripts/run_all.py
```

Outputs are written to `outputs/` in PDF, SVG, PNG, and TIFF formats. Layout QA JSON files are written to `qa/`.

Required Python packages are listed in `requirements.txt`: NumPy, pandas, and Matplotlib.

## Source data

Only the source-data files needed by these four figures are included:

- `source_data/figure_table_source_data/figure1_response.csv`
- `source_data/figure_table_source_data/controlled_evidence.csv`
- `source_data/figure_table_source_data/fitted_evidence.csv`
- `source_data/w11_source_data/figure4_realtime_paths.csv`

The final filename remains `figure2_realtime_paths.*` to match the current JBES manuscript; the source-data filename retains the historical `figure4_realtime_paths.csv` name for traceability.

## Reference figures

`reference_figures/` contains the four current JBES PDFs for visual comparison. The scripts use relative paths only; no local machine path is required.

This bundle contains no model-fitting code and does not recompute scientific results. It renders figures from the validated source-data tables.

The included reference PDFs were produced in the manuscript build environment. PDF byte hashes can differ across Matplotlib/font/PDF backends even when the plotted data and geometry are the same; the scripts include structural and formula assertions for the source data.
