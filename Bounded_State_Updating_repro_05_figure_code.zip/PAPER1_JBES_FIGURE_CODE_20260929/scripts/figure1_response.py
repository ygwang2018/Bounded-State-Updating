from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from style import SRC, QA, COLORS, LINES, LABELS, clean_axes, panel_label, save_all

src = SRC / "figure_table_source_data" / "figure1_response.csv"
d = pd.read_csv(src)
assert list(d.columns) == ["x", "value", "series", "panel"]
assert len(d) == 6005
assert set(d["panel"]) == {"mean_response", "working_uncertainty"}

nu = 5.0
c_h = 1.345
checks = {}
for series, formula in [
    ("G-MATCH", lambda x: x),
    ("Huber-ST", lambda x: np.clip(x, -c_h, c_h)),
    ("MB-ST", lambda x: x * np.minimum(1.0, (nu + 1.0) / (nu + nu*x*x/(nu-2.0)))),
]:
    z = d[(d.panel=="mean_response") & (d.series==series)].sort_values("x")
    expected = formula(z.x.to_numpy(float))
    checks[series] = float(np.max(np.abs(z.value.to_numpy(float)-expected)))
    assert checks[series] < 1e-12

z = d[(d.panel=="working_uncertainty") & (d.series=="MB-ST")].sort_values("x")
checks["MB_working"] = float(np.max(np.abs(z.value.to_numpy(float)-0.5)))
assert checks["MB_working"] < 1e-12
z = d[(d.panel=="working_uncertainty") & (d.series=="CB-ST")].sort_values("x")
w = np.minimum(1.0, (nu + 1.0) / (nu + nu*z.x.to_numpy(float)**2/(nu-2.0)))
checks["CB_working"] = float(np.max(np.abs(z.value.to_numpy(float)-(1.0-0.5*w))))
assert checks["CB_working"] < 1e-12

fig, axs = plt.subplots(1, 2, figsize=(6.5, 2.9))
fig.subplots_adjust(left=0.095, right=0.985, top=0.91, bottom=0.25, wspace=0.26)

ax = axs[0]
for key, series, lw in [("G_MATCH","G-MATCH",1.05),("HUBER_ST","Huber-ST",1.05),("MB_ST","MB-ST",1.05)]:
    z=d[(d.panel=="mean_response")&(d.series==series)].sort_values("x")
    ax.plot(z.x,z.value,color=COLORS[key],linestyle=LINES[key],lw=lw)
ax.axhline(0,color="#A7A7A7",lw=0.5,zorder=0)
ax.axvline(0,color="#A7A7A7",lw=0.5,zorder=0)
ax.set_xlim(-5,5); ax.set_ylim(-2,2)
ax.set_xticks([-4,-2,0,2,4]); ax.set_yticks([-2,-1,0,1,2])
ax.set_xlabel("Standardized innovation")
ax.set_ylabel("Standardized mean correction")
clean_axes(ax); panel_label(ax,"a")

ax = axs[1]
for key, series, lw in [("MB_ST","MB-ST",1.05),("CB_ST","CB-ST",1.10)]:
    z=d[(d.panel=="working_uncertainty")&(d.series==series)].sort_values("x")
    ax.plot(z.x,z.value,color=COLORS[key],linestyle=LINES[key],lw=lw)
ax.set_xlim(-5,5); ax.set_ylim(0.45,1.02)
ax.set_xticks([-4,-2,0,2,4]); ax.set_yticks([0.50,0.75,1.00])
ax.set_xlabel("Standardized innovation")
ax.set_ylabel("Post-update P / pre-update P")
clean_axes(ax); panel_label(ax,"b")

legend_keys=["G_MATCH","HUBER_ST","MB_ST","CB_ST"]
handles=[Line2D([0],[0],color=COLORS[k],linestyle=LINES[k],lw=1.1,label=LABELS[k]) for k in legend_keys]
fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(0.5,0.025),ncol=4,frameon=False,
           handlelength=2.9,columnspacing=1.5,handletextpad=0.55)

save_all(fig,"figure1_response")
plt.close(fig)
(QA/"figure1_formula_identity.json").write_text(json.dumps(checks,indent=2),encoding="utf-8")
