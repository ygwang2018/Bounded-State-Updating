import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from style import SRC, COLORS, MARKERS, LABELS, clean_axes, panel_label, save_all

d=pd.read_csv(SRC/"figure_table_source_data"/"fitted_evidence.csv")
refit=d[d.panel=="refit"].copy()
cbmb=d[d.panel=="cbmb"].copy()
assert len(refit)==9 and len(cbmb)==6
assert set(refit.design)=={"Primary","Replication","Recovery"}
assert set(cbmb.design)=={"Primary","Replication","Recovery"}
assert set(refit.method)=={"Huber","MB","CB"}
assert set(cbmb.fit_mode)=={"Frozen","Full"}
assert (refit.ci_low<=refit.estimate).all() and (refit.estimate<=refit.ci_high).all()
assert (cbmb.ci_low<=cbmb.estimate).all() and (cbmb.estimate<=cbmb.ci_high).all()

base={"Primary":2.0,"Replication":1.0,"Recovery":0.0}
mkey={"Huber":"HUBER_ST","MB":"MB_ST","CB":"CB_ST"}
offset={"Huber":.18,"MB":0.0,"CB":-.18}

fig,axs=plt.subplots(1,2,figsize=(6.5,2.9))
fig.subplots_adjust(left=.11,right=.985,top=.91,bottom=.27,wspace=.31)

ax=axs[0]
for method in ["Huber","MB","CB"]:
    k=mkey[method]
    z=refit[refit.method==method]
    for _,r in z.iterrows():
        y=base[r.design]+offset[method]
        ax.hlines(y,r.ci_low,r.ci_high,color="#5A5A5A",lw=.75,zorder=1)
        ax.plot([r.ci_low,r.ci_low],[y-.035,y+.035],color="#5A5A5A",lw=.65,zorder=1)
        ax.plot([r.ci_high,r.ci_high],[y-.035,y+.035],color="#5A5A5A",lw=.65,zorder=1)
        ax.plot(r.estimate,y,marker=MARKERS[k],color=COLORS[k],linestyle="None",
                markersize=4.7,markeredgewidth=.75,zorder=3)
ax.axvline(0,color="#929292",lw=.5,zorder=0)
ax.set_yticks([0,1,2],["Recovery","Replication","Primary"])
ax.set_ylim(-.48,2.48)
ax.set_xlim(-.55,19.6)
ax.set_xticks([0,5,10,15])
ax.set_xlabel(r"$\Delta_{refit}$ (MASE)")
clean_axes(ax); panel_label(ax,"a")

ax=axs[1]
fit_offset={"Frozen":.14,"Full":-.14}
for mode in ["Frozen","Full"]:
    z=cbmb[cbmb.fit_mode==mode]
    for _,r in z.iterrows():
        y=base[r.design]+fit_offset[mode]
        ax.hlines(y,r.ci_low,r.ci_high,color="#4F4F4F",lw=.78,zorder=1)
        ax.plot([r.ci_low,r.ci_low],[y-.035,y+.035],color="#4F4F4F",lw=.65,zorder=1)
        ax.plot([r.ci_high,r.ci_high],[y-.035,y+.035],color="#4F4F4F",lw=.65,zorder=1)
        ax.plot(r.estimate,y,marker="o",linestyle="None",markersize=4.7,
                markeredgewidth=.85,markeredgecolor="#111111",
                markerfacecolor="white" if mode=="Frozen" else "#111111",zorder=3)
ax.axvline(0,color="#929292",lw=.5,zorder=0)
ax.set_yticks([0,1,2],["Recovery","Replication","Primary"])
ax.set_ylim(-.48,2.48)
ax.set_xlim(-1.15,.55)
ax.set_xticks([-1.0,-.5,0,.5])
ax.set_xlabel("CB - MB MASE contrast")
clean_axes(ax); panel_label(ax,"b")

h1=[Line2D([0],[0],marker=MARKERS[mkey[m]],color="none",markerfacecolor=COLORS[mkey[m]],
           markeredgecolor=COLORS[mkey[m]],markersize=4.7,label=LABELS[mkey[m]])
    for m in ["Huber","MB","CB"]]
leg1=axs[0].legend(handles=h1,loc="upper left",bbox_to_anchor=(0.01,-.21),ncol=3,frameon=False,
                   borderaxespad=0,handletextpad=.45,columnspacing=1.2)
h2=[Line2D([0],[0],marker="o",color="none",markeredgecolor="#111111",
           markerfacecolor="white",markersize=4.7,label="Frozen fit"),
    Line2D([0],[0],marker="o",color="none",markeredgecolor="#111111",
           markerfacecolor="#111111",markersize=4.7,label="Full refit")]
axs[1].legend(handles=h2,loc="upper left",bbox_to_anchor=(.16,-.21),ncol=2,frameon=False,
              borderaxespad=0,handletextpad=.45,columnspacing=1.3)

save_all(fig,"figure3_refitting")
plt.close(fig)
