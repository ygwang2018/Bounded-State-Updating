from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SCRIPTS = [
    "figure1_response.py",
    "figure2_realtime_paths.py",
    "figure2_controlled.py",
    "figure3_refitting.py",
]

for script in SCRIPTS:
    print(f"=== {script} ===", flush=True)
    subprocess.run([sys.executable, str(HERE / script)], check=True)

print("All four JBES figures generated successfully.")
