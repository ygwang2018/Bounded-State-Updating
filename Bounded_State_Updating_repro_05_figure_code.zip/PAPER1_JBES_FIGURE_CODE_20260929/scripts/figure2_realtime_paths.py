import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib.lines import Line2D
from style import SRC, COLORS, LINES, MARKERS, LABELS, clean_axes, panel_label, save_all

d=pd.read_csv(SRC/"w11_source_data"/"figure4_realtime_paths.csv")
assert len(d)==60
assert not d.duplicated(["series","target_date","method"]).any()
assert set(d.series)=={"EMPLOY","CUT"}
assert set(d.method)=={"G_MATCH","HUBER_ST","MB_ST","CB_ST","NAIVE"}
assert d.groupby(["series","target_date"]).target_third.nunique().eq(1).all()
assert d.groupby("series").target_date.nunique().eq(6).all()
dates=sorted(d.target_date.unique().tolist())
assert dates==["2020-03-01","2020-04-01","2020-05-01","2020-06-01","2020-07-01","2020-08-01"]
x=range(6)
xlabels=["Mar","Apr","May","Jun","Jul","Aug"]

fig,axs=plt.subplots(1,3,figsize=(6.5,3.15))
fig.subplots_adjust(left=.105,right=.985,top=.87,bottom=.29,wspace=.34)

def draw_series(ax, series, methods, target=True, bounded_emphasis=False):
    a=d[d.series==series]
    t=a[["target_date","target_third"]].drop_duplicates().sort_values("target_date")
    assert t.target_date.tolist()==dates
    if target:
        ax.plot(x,t.target_third,color=COLORS["TARGET"],linestyle=LINES["TARGET"],
                marker=MARKERS["TARGET"],lw=1.35,markersize=4.2,
                markeredgewidth=.65,label=LABELS["TARGET"],zorder=5)
    for m in methods:
        z=a[a.method==m].sort_values("target_date")
        assert z.target_date.tolist()==dates
        lw=1.08 if bounded_emphasis else (.98 if m!="CB_ST" else 1.02)
        ms=4.0 if m in {"CB_ST","NAIVE"} else 3.6
        ax.plot(x,z.forecast_pre_realtime,color=COLORS[m],linestyle=LINES[m],
                marker=MARKERS[m],lw=lw,markersize=ms,markeredgewidth=.75,
                label=LABELS[m],zorder=3 if m in {"HUBER_ST","MB_ST","CB_ST"} else 2)

all_methods=["G_MATCH","HUBER_ST","MB_ST","CB_ST","NAIVE"]
draw_series(axs[0],"EMPLOY",all_methods,target=True)
draw_series(axs[1],"EMPLOY",["HUBER_ST","MB_ST","CB_ST"],target=False,bounded_emphasis=True)
draw_series(axs[2],"CUT",all_methods,target=True)

titles=["Employment change","Employment, bounded variants","Capacity utilization"]
for i,(ax,title) in enumerate(zip(axs,titles)):
    ax.set_xticks(list(x),xlabels)
    ax.set_xlim(-.2,5.2)
    ax.set_xlabel("2020")
    ax.set_title(title,pad=5.5,fontweight="normal")
    clean_axes(ax)
    panel_label(ax,"abc"[i],x=-.18,y=1.05)

axs[0].axhline(0,color="#A4A4A4",lw=.5,zorder=0)
axs[0].set_ylim(-24000,6500)
axs[0].set_yticks([-20000,-10000,0,5000])
axs[0].yaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{int(v):,}"))
axs[0].set_ylabel("Thousands of employees")

axs[1].axhline(0,color="#A4A4A4",lw=.5,zorder=0)
axs[1].set_ylim(-700,600)
axs[1].set_yticks([-500,0,500])
axs[1].set_ylabel("Thousands of employees")

axs[2].set_ylim(60,79)
axs[2].set_yticks([60,65,70,75])
axs[2].set_ylabel("Level (%)")

legend_keys=["TARGET","G_MATCH","HUBER_ST","MB_ST","CB_ST","NAIVE"]
handles=[Line2D([0],[0],color=COLORS[k],linestyle=LINES[k],marker=MARKERS[k],
                lw=1.3 if k=="TARGET" else 1.0,markersize=4.0,label=LABELS[k])
         for k in legend_keys]
fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.5,.018),ncol=3,frameon=False,
           handlelength=2.7,columnspacing=1.25,handletextpad=.55,labelspacing=.75)

save_all(fig,"figure2_realtime_paths")
plt.close(fig)
