import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from style import SRC, COLORS, LINES, MARKERS, LABELS, clean_axes, panel_label, save_all

d = pd.read_csv(SRC / "figure_table_source_data" / "controlled_evidence.csv")
acc=d[d.panel=="accumulation"].copy()
rec=d[d.panel=="recovery"].copy()
assert len(acc)==6 and len(rec)==10
assert set(acc.method)=={"Gaussian","Huber"} and set(rec.method)=={"Gaussian","Huber"}
assert sorted(acc.x.unique().tolist())==[1,3,5]
assert sorted(rec.x.unique().tolist())==[0,1,2,4,8]
mm={"Gaussian":"G_MATCH","Huber":"HUBER_ST"}

fig,axs=plt.subplots(1,2,figsize=(6.5,2.72),sharey=True)
fig.subplots_adjust(left=.09,right=.985,top=.91,bottom=.26,wspace=.22)
for ax,z,tag in [(axs[0],acc,"a"),(axs[1],rec,"b")]:
    for raw in ["Gaussian","Huber"]:
        q=z[z.method==raw].sort_values("x")
        k=mm[raw]
        ax.plot(q.x,q.estimate,color=COLORS[k],linestyle=LINES[k],marker=MARKERS[k],
                lw=1.0,markersize=4.0,markeredgewidth=.75)
    ax.set_ylim(0,.62)
    ax.set_yticks([0,.1,.2,.3,.4,.5,.6])
    clean_axes(ax)
    panel_label(ax,tag)
axs[0].set_xticks([1,3,5]); axs[0].set_xlim(.7,5.3)
axs[0].set_xlabel("Contaminated block length, k")
axs[0].set_ylabel("Normalized retained displacement")
axs[1].set_xticks([0,1,2,4,8]); axs[1].set_xlim(-.25,8.35)
axs[1].set_xlabel("Subsequent clean observations, d")

handles=[Line2D([0],[0],color=COLORS[k],linestyle=LINES[k],marker=MARKERS[k],
                lw=1.0,markersize=4.0,label=LABELS[k]) for k in ["G_MATCH","HUBER_ST"]]
fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.5,.025),ncol=2,frameon=False,
           handlelength=2.8,columnspacing=1.8,handletextpad=.6)
save_all(fig,"figure2_controlled")
plt.close(fig)
