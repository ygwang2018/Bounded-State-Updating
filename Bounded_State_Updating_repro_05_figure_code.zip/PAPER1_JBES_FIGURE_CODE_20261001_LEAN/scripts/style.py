from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source_data"
OUT = ROOT / "outputs"
QA = ROOT / "qa"
OUT.mkdir(parents=True, exist_ok=True)
QA.mkdir(parents=True, exist_ok=True)

COLORS = {
    "TARGET": "#000000",
    "G_MATCH": "#4D4D4D",
    "HUBER_ST": "#0072B2",
    "MB_ST": "#D55E00",
    "CB_ST": "#7B3294",
    "NAIVE": "#009E73",
    "REF": "#8C8C8C",
}
LABELS = {
    "TARGET": "Third-release target",
    "G_MATCH": "Gaussian-ST",
    "HUBER_ST": "Huber-ST",
    "MB_ST": "MB-ST",
    "CB_ST": "CB-ST",
    "NAIVE": "Naive",
}
LINES = {
    "TARGET": "-",
    "G_MATCH": "-",
    "HUBER_ST": "--",
    "MB_ST": "-.",
    "CB_ST": (0, (1.2, 1.5)),
    "NAIVE": (0, (4.0, 1.4, 1.0, 1.4)),
}
MARKERS = {
    "TARGET": "D",
    "G_MATCH": "s",
    "HUBER_ST": "o",
    "MB_ST": "^",
    "CB_ST": "x",
    "NAIVE": "+",
}

def apply_rc():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 7.6,
        "axes.labelsize": 8.0,
        "axes.titlesize": 8.1,
        "xtick.labelsize": 7.3,
        "ytick.labelsize": 7.3,
        "legend.fontsize": 7.2,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 3.0,
        "ytick.major.size": 3.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "mathtext.fontset": "custom",
        "mathtext.rm": "Arial",
        "mathtext.it": "Arial:italic",
        "mathtext.bf": "Arial:bold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
    })

def clean_axes(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.6)
    ax.spines["bottom"].set_linewidth(0.6)
    ax.tick_params(direction="out", pad=2.5)

def panel_label(ax, label, x=-0.12, y=1.035):
    ax.text(x, y, f"({label})", transform=ax.transAxes,
            ha="left", va="bottom", fontsize=9.4, fontweight="bold",
            clip_on=False)

def save_all(fig, stem, dpi_png=300, dpi_tiff=1000):
    import json
    from matplotlib.text import Text
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    items = []
    outside = []
    for t in fig.findobj(match=Text):
        if not t.get_visible() or not t.get_text().strip():
            continue
        b = t.get_window_extent(renderer=renderer)
        rec = {"text": t.get_text(), "x0": float(b.x0), "y0": float(b.y0),
               "x1": float(b.x1), "y1": float(b.y1)}
        items.append(rec)
        if b.x0 < -1 or b.y0 < -1 or b.x1 > width + 1 or b.y1 > height + 1:
            outside.append(rec)
    overlaps = []
    for i in range(len(items)):
        a = items[i]
        for j in range(i + 1, len(items)):
            b = items[j]
            dx = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
            dy = min(a["y1"], b["y1"]) - max(a["y0"], b["y0"])
            if dx > 1.0 and dy > 1.0:
                overlaps.append({"a": a["text"], "b": b["text"], "dx": dx, "dy": dy})
    (QA / f"{stem}_text_layout.json").write_text(
        json.dumps({"canvas_px": [width, height], "outside": outside,
                    "text_overlaps": overlaps}, indent=2), encoding="utf-8")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", pad_inches=0.025)
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight", pad_inches=0.025)
    fig.savefig(OUT / f"{stem}.png", dpi=dpi_png, bbox_inches="tight", pad_inches=0.025)
    fig.savefig(OUT / f"{stem}.tiff", dpi=dpi_tiff, bbox_inches="tight",
                pad_inches=0.025, pil_kwargs={"compression": "tiff_lzw"})

apply_rc()
