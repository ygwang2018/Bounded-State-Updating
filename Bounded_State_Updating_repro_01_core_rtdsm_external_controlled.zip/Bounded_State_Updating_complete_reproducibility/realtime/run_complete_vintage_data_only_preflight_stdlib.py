# RST-O Discussion 3: origin-consistent complete-vintage DATA-ONLY preflight
# Standard-library XLSX parser. NO forecasting/model fitting.
from __future__ import annotations
import csv, math, re, zipfile
from pathlib import Path
from datetime import date
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SPECS = [
    ("EMPLOY","EMPLOY_complete_vintages.xlsx","diff","EMPLOY"),
    ("IPT","IPT_complete_vintages.xlsx","growth","IPT"),
    ("IPM","IPM_complete_vintages.xlsx","growth","IPM"),
    ("H","H_complete_vintages.xlsx","growth","H"),
    ("CUT","CUT_complete_vintages.xlsx","level","CUT"),
]

def add_month(d: date, k: int) -> date:
    m = d.year*12 + d.month-1 + k
    return date(m//12, m%12+1, 1)

def month_range(a: date, b: date):
    x=a
    while x<=b:
        yield x
        x=add_month(x,1)

def col_index(ref: str) -> int:
    letters=re.match(r"[A-Z]+", ref.upper()).group(0)
    n=0
    for ch in letters: n=n*26+ord(ch)-64
    return n

def parse_obs(s: str|None):
    if not s: return None
    m=re.fullmatch(r"\s*(\d{4})[:/-]?M?(\d{1,2})\s*", str(s), re.I)
    if not m: return None
    y,mo=map(int,m.groups())
    if not 1<=mo<=12: return None
    return date(y,mo,1)

def parse_vintage(s: str|None, prefix: str):
    if not s: return None
    m=re.fullmatch(re.escape(prefix)+r"(\d{2,4})M(\d{1,2})", str(s).strip(), re.I)
    if not m: return None
    y,mo=map(int,m.groups())
    if y<100: y += 2000 if y<=40 else 1900
    if not 1<=mo<=12: return None
    return date(y,mo,1)

def shared_strings(zf):
    try: raw=zf.read("xl/sharedStrings.xml")
    except KeyError: return []
    root=ET.fromstring(raw); out=[]
    for si in root.iter():
        if si.tag.endswith('}si'):
            out.append(''.join((t.text or '') for t in si.iter() if t.tag.endswith('}t')))
    return out

def cell_value(c, shared):
    typ=c.attrib.get('t')
    if typ=='inlineStr':
        return ''.join((t.text or '') for t in c.iter() if t.tag.endswith('}t'))
    v=None
    for x in c:
        if x.tag.endswith('}v'): v=x.text; break
    if v is None: return None
    if typ=='s':
        try: return shared[int(v)]
        except Exception: return None
    return v

def read_workbook(path: Path, prefix: str):
    with zipfile.ZipFile(path) as zf:
        shared=shared_strings(zf)
        with zf.open('xl/worksheets/sheet1.xml') as fh:
            context=ET.iterparse(fh, events=('end',))
            headers={}; vdates={}; required_cols=set(); obs_values={}
            for _,elem in context:
                if not elem.tag.endswith('}row'): continue
                rnum=int(elem.attrib.get('r','0'))
                cells={}
                for c in elem:
                    if c.tag.endswith('}c'):
                        ref=c.attrib.get('r','')
                        if ref: cells[col_index(ref)]=cell_value(c,shared)
                if rnum==1:
                    headers=cells
                    for ci,h in headers.items():
                        vd=parse_vintage(h,prefix)
                        if vd is not None: vdates[ci]=(h,vd)
                    required_cols={ci for ci,(h,vd) in vdates.items() if date(2018,1,1)<=vd<=date(2025,8,1)}
                    obs_values={headers[ci]:{} for ci in required_cols}
                else:
                    od=parse_obs(cells.get(1))
                    if od is not None:
                        for ci in required_cols:
                            raw=cells.get(ci)
                            if raw not in (None,''):
                                try: obs_values[headers[ci]][od]=float(raw)
                                except Exception: pass
                elem.clear()
    vd_by_name={h:vd for ci,(h,vd) in vdates.items()}
    name_by_vd={vd:h for h,vd in vd_by_name.items()}
    return vd_by_name,name_by_vd,obs_values

def make_window(values, target: date, kind: str):
    end=add_month(target,-1)
    if kind in ('diff','growth'):
        dates=list(month_range(add_month(target,-121),end))
        if len(dates)!=121 or any(d not in values for d in dates): return False,'missing_or_nonfinite_level',[],[]
        z=[values[d] for d in dates]
        if not all(math.isfinite(x) for x in z): return False,'missing_or_nonfinite_level',[],[]
        if kind=='diff': y=[z[i]-z[i-1] for i in range(1,len(z))]
        else: y=[100*((z[i]/z[i-1])**12-1) for i in range(1,len(z))]
        td=dates[1:]
    else:
        td=list(month_range(add_month(target,-120),end))
        if len(td)!=120 or any(d not in values for d in td): return False,'missing_or_nonfinite_level',[],[]
        y=[values[d] for d in td]
        if not all(math.isfinite(x) for x in y): return False,'missing_or_nonfinite_level',[],[]
    return len(y)==120 and max(td)==end, None, td, y

targets=list(month_range(date(2018,1,1),date(2025,6,1)))
required=list(month_range(date(2018,1,1),date(2025,8,1)))
census=[]; qa=[]; identity=[]; train_rows=[]

for series,fn,kind,prefix in SPECS:
    vd_by_name,name_by_vd,obs_values=read_workbook(ROOT/fn,prefix)
    all_vd=list(vd_by_name.values())
    census.append(dict(series=series,n_vintages=len(all_vd),first_vintage=min(all_vd).isoformat(),last_vintage=max(all_vd).isoformat(),required_vintages=len(required),missing_required=sum(v not in name_by_vd for v in required),duplicate_vintage_dates=len(all_vd)-len(set(all_vd))))
    for t in targets:
        pn=name_by_vd.get(t); rv=add_month(t,2); rn=name_by_vd.get(rv)
        rec=dict(series=series,target=t.isoformat(),pre_vintage=pn or '',ref_vintage=rn or '',pre_exists=bool(pn),ref_exists=bool(rn),pre_ok=False,ref_ok=False,same_dates=False,leakage='',reason='')
        if not pn or not rn:
            rec['reason']='missing_vintage'; qa.append(rec); continue
        pre=make_window(obs_values[pn],t,kind); ref=make_window(obs_values[rn],t,kind)
        rec['pre_ok']=pre[0]; rec['ref_ok']=ref[0]
        if not pre[0] or not ref[0]:
            bits=[]
            if not pre[0]: bits.append('PRE:'+str(pre[1]))
            if not ref[0]: bits.append('REF:'+str(ref[1]))
            rec['reason']=';'.join(bits); qa.append(rec); continue
        rec['same_dates']=pre[2]==ref[2]
        rec['leakage']=max(pre[2])>=t or max(ref[2])>=t
        if not rec['same_dates']: rec['reason']='date_support_mismatch'
        if rec['leakage']: rec['reason']='target_leakage'
        qa.append(rec)
        identity.append(dict(series=series,target=t.isoformat(),obs_date=add_month(t,-1).isoformat(),pre_last=pre[3][-1],ref_last=ref[3][-1]))
        if not rec['reason']:
            for d,y in zip(pre[2],pre[3]): train_rows.append(dict(series=series,target=t.isoformat(),interface='PRE',train_date=d.isoformat(),y=y))
            for d,y in zip(ref[2],ref[3]): train_rows.append(dict(series=series,target=t.isoformat(),interface='REF',train_date=d.isoformat(),y=y))

summary=[]
for series,_,_,_ in SPECS:
    z=[r for r in qa if r['series']==series]
    summary.append(dict(series=series,n_targets=len(z),pre_exists=sum(bool(r['pre_exists']) for r in z),ref_exists=sum(bool(r['ref_exists']) for r in z),pre_ok=sum(bool(r['pre_ok']) for r in z),ref_ok=sum(bool(r['ref_ok']) for r in z),same_dates=sum(bool(r['same_dates']) for r in z),leakage_fail=sum(r['leakage'] is True for r in z),reason_fail=sum(bool(r['reason']) for r in z)))

def write_csv(name, rows):
    p=ROOT/name
    with p.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

write_csv('py_complete_vintage_census.csv',census)
write_csv('py_complete_vintage_origin_support_qa.csv',qa)
write_csv('py_complete_vintage_origin_support_summary.csv',summary)
write_csv('py_complete_vintage_latest_training_values.csv',identity)
write_csv('complete_vintage_training_long.csv',train_rows)
print('DATA-ONLY PYTHON PREFLIGHT COMPLETE')
for r in census: print(r)
for r in summary: print(r)
print('No forecasting or model fitting was run.')
