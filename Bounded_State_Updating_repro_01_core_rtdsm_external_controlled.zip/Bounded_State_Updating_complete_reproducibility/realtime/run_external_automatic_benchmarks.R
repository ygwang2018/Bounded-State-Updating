#!/usr/bin/env Rscript
# Reproduce the frozen ETS, AutoARIMA and signed AutoTheta full-refit records.
# Outputs are separate from evidence. No fallback, tuning or result replacement.
# Usage: Rscript run_external_automatic_benchmarks.R --upstream "Part I.R"
#        --mode smoke|full --workers 4 --output /separate/output

options(stringsAsFactors = FALSE, warn = 1)

phase_of <- function(x) {
  ifelse(x <= "2020-02-01", "PRE_COVID_2018_TO_2020_02",
    ifelse(x <= "2020-07-01", "COVID_SHOCK_2020_03_TO_07",
      ifelse(x <= "2021-12-01", "RECOVERY_2020_08_TO_2021_12", "POST_2022_TO_2025_06")))
}

text_value <- function(x) {
  if (is.null(x) || !length(x) || all(is.na(x))) "" else paste(x, collapse = ";")
}

# One frozen history and one method. Compare immediately; never retry a mismatch.
fit_and_compare <- function(task) {
  y <- task$y
  warnings <- character()
  failure <- ""
  started <- proc.time()[[3L]]
  fit <- tryCatch(withCallingHandlers({
    if (task$method == "AutoTheta") {
      f <- AUTO(y)
      stopifnot(length(f$fitted) == 120L, all(is.finite(f$fitted)), is.finite(f$theta))
      list(forecast_h1 = as.numeric(f$mean[1L]),
           selected_model_description = f$description,
           theta = f$theta, seasonality_code = f$seasonality_code,
           combination_code = f$combination_code, trend_code = f$trend_code,
           SES_alpha = f$SES_alpha, SES_beta = f$SES_beta,
           SES_par2_name = f$SES_par2_name, SES_par2_value = f$SES_par2_value,
           base = f$base, raw_forecast_scaled = f$raw_forecast_scaled[1L],
           selected_forecast_scaled = f$selected_forecast_scaled[1L],
           candidate_names = paste(f$candidate_names, collapse = ";"))
    } else {
      f <- if (task$method == "ETS") forecast::ets(stats::ts(y, frequency = 1)) else
        forecast::auto.arima(stats::ts(y, frequency = 1))
      fc <- as.numeric(forecast::forecast(f, h = 1)$mean[1L])
      orders <- if (task$method == "AutoARIMA") forecast::arimaorder(f) else numeric()
      list(forecast_h1 = fc, selected_model = text_value(f$method),
           components = text_value(f$components),
           damped = if (task$method == "ETS") text_value(f$components[4L]) else "",
           orders = paste(names(orders), orders, sep = "=", collapse = ";"),
           drift = "drift" %in% names(f$coef), mean = "intercept" %in% names(f$coef),
           AIC = f$aic, AICc = f$aicc, BIC = f$bic, convergence = text_value(f$code))
    }
  }, warning = function(w) {
    warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")
  }), error = function(e) { failure <<- conditionMessage(e); NULL })
  if (is.null(fit)) fit <- list(forecast_h1 = NA_real_)
  if (!is.finite(fit$forecast_h1) && !nzchar(failure)) failure <- "Nonfinite forecast"
  status <- if (nzchar(failure)) "FAILED" else if (length(warnings)) "OK_WARNING" else "OK"
  row <- c(list(series = task$series, target_date = task$target_date,
                interface = task$interface, method = task$method, fit_interface = "full_refit",
                n_train = length(y), phase = phase_of(task$target_date),
                target_third = task$truth, train_mean = mean(y),
                train_min = min(y), train_max = max(y), contains_nonpositive = any(y <= 0)),
           fit, list(abs_error = abs(fit$forecast_h1 - task$truth),
                     sq_error = (fit$forecast_h1 - task$truth)^2,
                     fit_status = status, warning = paste(unique(warnings), collapse = " | "),
                     failure = failure, runtime_sec = proc.time()[[3L]] - started))
  expected <- task$expected
  numeric_fields <- c("forecast_h1", "target_third")
  identity_fields <- c("fit_status", "warning", "failure")
  if (task$method == "AutoTheta") {
    numeric_fields <- c(numeric_fields, "theta", "SES_alpha", "SES_par2_value",
                        "raw_forecast_scaled", "selected_forecast_scaled", "base")
    identity_fields <- c(identity_fields, "selected_model_description", "seasonality_code",
                         "combination_code", "trend_code", "SES_par2_name", "candidate_names")
  } else {
    identity_fields <- c(identity_fields, "selected_model", "components", "damped",
                         "orders", "drift", "mean", "convergence")
  }
  bad <- list()
  for (field in numeric_fields) {
    a <- as.numeric(row[[field]]); b <- as.numeric(expected[[field]])
    if (length(a) != 1L || length(b) != 1L || !is.finite(a) || !is.finite(b) ||
        abs(a - b) > 1e-10 * (1 + abs(b)))
      bad[[length(bad) + 1L]] <- list(field = field, expected = text_value(b), observed = text_value(a))
  }
  for (field in identity_fields) {
    a <- text_value(row[[field]]); b <- text_value(expected[[field]])
    # Python-generated frozen CSVs use True/False; R uses TRUE/FALSE.
    # Normalize logical serialization only, never model names or numeric values.
    if (field %in% c("drift", "mean")) { a <- toupper(a); b <- toupper(b) }
    if (a != b) bad[[length(bad) + 1L]] <- list(field = field, expected = b, observed = a)
  }
  row$forecast_abs_diff <- abs(row$forecast_h1 - as.numeric(expected$forecast_h1))
  row$theta_abs_diff <- if (task$method == "AutoTheta") abs(row$theta - as.numeric(expected$theta)) else NA_real_
  row$regression_status <- if (length(bad)) "FAIL" else "PASS"
  list(row = row, mismatches = bad)
}

main <- function() {
  script_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  script <- normalizePath(sub("^--file=", "", script_arg[1L]), mustWork = TRUE)
  here <- dirname(script)
  args <- commandArgs(TRUE)
  if (length(args) %% 2L) stop("Arguments must be --name value pairs.")
  opts <- if (length(args)) setNames(as.list(args[seq(2, length(args), 2)]),
                                   sub("^--", "", args[seq(1, length(args), 2)])) else list()
  allowed <- c("package-root", "autotheta-records", "upstream", "output", "mode", "workers")
  if (length(setdiff(names(opts), allowed))) stop("Unknown command-line option.")
  opt <- function(name, default) if (is.null(opts[[name]])) default else opts[[name]]
  pkg <- normalizePath(opt("package-root", dirname(here)), mustWork = TRUE)
  upstream <- normalizePath(opt("upstream", file.path(here, "upstream", "Structural Theta codes and results (Part I).R")), mustWork = TRUE)
  mode <- match.arg(opt("mode", "smoke"), c("smoke", "full"))
  workers <- as.integer(opt("workers", "1"))
  stopifnot(is.finite(workers), workers >= 1L, workers <= parallel::detectCores())
  out <- opt("output", file.path(pkg, "reproduced", paste0("external_", mode)))
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out <- normalizePath(out, mustWork = TRUE)
  if (tolower(out) %in% tolower(c(pkg, file.path(pkg, "realtime"), file.path(pkg, "R1_R2/05_R2_BENCHMARKS"))))
    stop("Output must be a separate reproduction directory.")
  result_file <- file.path(out, "EXTERNAL_REGRESSION_FITS.csv")
  if (file.exists(result_file)) stop("Output already contains a run; use a fresh directory.")
  stopifnot(as.character(getRversion()) == "4.3.3",
            as.character(utils::packageVersion("forecast")) == "8.24.0")
  source(file.path(here, "autotheta_adapter.R"), local = .GlobalEnv)
  AUTO <<- load_autotheta_upstream(upstream)
  capture.output(sessionInfo(), file = file.path(out, "R_SESSION_INFO.txt"))
  tr_path <- file.path(pkg, "realtime/complete_vintage_training_long.csv")
  # Preserve the parsers used by the respective frozen execution scripts.
  tr_auto <- read.csv(tr_path, fileEncoding = "UTF-8-BOM", check.names = FALSE)
  tr_r2 <- as.data.frame(data.table::fread(tr_path))
  tr_auto$target <- as.character(tr_auto$target); tr_r2$target <- as.character(tr_r2$target)
  tr_auto$train_date <- as.character(tr_auto$train_date); tr_r2$train_date <- as.character(tr_r2$train_date)
  stopifnot(nrow(tr_auto) == 108000L, nrow(tr_r2) == 108000L,
            all(is.finite(tr_auto$y)), all(is.finite(tr_r2$y)))
  targets <- read.csv(file.path(pkg, "realtime/frozen_release_targets.csv"))
  r2 <- read.csv(file.path(pkg, "R1_R2/05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FITS.csv"), check.names = FALSE)
  r2$warning <- ifelse(is.na(r2$warnings), "", r2$warnings)
  auto_path <- opt("autotheta-records", file.path(pkg, "R1_R2/05_R2_BENCHMARKS/R2_AUTOTHETA_FITS.csv"))
  auto <- read.csv(auto_path, check.names = FALSE)
  stopifnot(nrow(r2) == 1800L, nrow(auto) == 900L)
  key <- function(d) paste(d$series, d$target_date, d$interface, sep = "|")
  ak <- key(auto)
  stopifnot(!anyDuplicated(ak), !anyDuplicated(paste(key(r2), r2$method)))
  split_history <- function(d) split(seq_len(nrow(d)), paste(d$series, d$target, d$interface, sep = "|"))
  ai <- split_history(tr_auto); ri <- split_history(tr_r2)
  keys <- auto[c("series", "target_date", "interface")]
  # Prespecified smoke coverage: all series/interfaces in three epochs; all CUT
  # shock origins; EMPLOY April/May; 20 smallest-absolute-mean frozen histories.
  if (mode == "smoke") {
    ordinary <- keys$target_date %in% c("2019-06-01", "2020-05-01", "2024-06-01")
    focal <- (keys$series == "EMPLOY" & keys$target_date == "2020-04-01") |
             (keys$series == "CUT" & keys$target_date %in% paste0("2020-0", 3:7, "-01"))
    near <- order(abs(auto$train_mean), auto$series, auto$target_date, auto$interface)[1:20]
    keys <- keys[ordinary | focal | seq_len(nrow(keys)) %in% near, ]
  }
  keys <- keys[order(keys$series, keys$target_date, keys$interface), ]
  tasks <- list()
  for (i in seq_len(nrow(keys))) {
    k <- key(keys[i, ]); sn <- keys$series[i]; tt <- keys$target_date[i]
    truth <- targets$target_third[targets$series == sn & targets$target_date == tt]
    stopifnot(length(truth) == 1L, is.finite(truth))
    for (method in c("ETS", "AutoARIMA", "AutoTheta")) {
      d <- if (method == "AutoTheta") tr_auto[ai[[k]], ] else tr_r2[ri[[k]], ]
      d <- d[order(d$train_date), ]
      stopifnot(nrow(d) == 120L, !anyDuplicated(d$train_date), max(d$train_date) < tt)
      e <- if (method == "AutoTheta") auto[ak == k, ] else r2[key(r2) == k & r2$method == method, ]
      stopifnot(nrow(e) == 1L)
      tasks[[length(tasks) + 1L]] <- list(series = sn, target_date = tt,
        interface = keys$interface[i], method = method, y = d$y, truth = truth, expected = as.list(e))
    }
  }
  write.csv(keys, file.path(out, "HISTORY_KEYS.csv"), row.names = FALSE)
  cat("MODE", mode, "HISTORIES", nrow(keys), "FITS", length(tasks), "WORKERS", workers, "\n")
  cl <- NULL
  if (workers > 1L) {
    cl <- parallel::makePSOCKcluster(workers)
    on.exit(parallel::stopCluster(cl), add = TRUE)
    parallel::clusterExport(cl, c("phase_of", "text_value", "fit_and_compare"), envir = .GlobalEnv)
    parallel::clusterCall(cl, function(adapter, upstream) {
      options(stringsAsFactors = FALSE, warn = 1)
      source(adapter, local = .GlobalEnv)
      AUTO <<- load_autotheta_upstream(upstream)
      NULL
    }, file.path(here, "autotheta_adapter.R"), upstream)
  }
  rows <- list()
  # At most one worker-sized batch is in flight; stop before submitting another
  # batch after any forecast, model, theta or status mismatch.
  for (first in seq.int(1L, length(tasks), by = workers)) {
    ids <- seq.int(first, min(first + workers - 1L, length(tasks)))
    batch <- if (is.null(cl)) lapply(tasks[ids], fit_and_compare) else parallel::parLapply(cl, tasks[ids], fit_and_compare)
    for (j in seq_along(batch)) {
      z <- batch[[j]]; rows[[length(rows) + 1L]] <- z$row
      if (length(z$mismatches)) {
        fail <- do.call(rbind, lapply(z$mismatches, function(x)
          data.frame(series = z$row$series, target_date = z$row$target_date,
                     interface = z$row$interface, method = z$row$method,
                     field = x$field, expected = x$expected, observed = x$observed)))
        write.csv(fail, file.path(out, "FIRST_MISMATCH.csv"), row.names = FALSE)
        data.table::fwrite(data.table::rbindlist(rows, fill = TRUE), result_file, na = "")
        writeLines("BLOCKED_BY_REAL_IMPLEMENTATION_ISSUE", file.path(out, "STATUS.txt"))
        stop("Regression mismatch. No algorithm change or retry is authorized.")
      }
    }
    if (max(ids) %% 60L == 0L || max(ids) == length(tasks)) {
      cat("Validated", max(ids), "/", length(tasks), "fits\n"); flush.console()
    }
  }
  result <- as.data.frame(data.table::rbindlist(rows, fill = TRUE))
  data.table::fwrite(result, result_file, na = "")
  qa <- do.call(rbind, lapply(c("ETS", "AutoARIMA", "AutoTheta"), function(m) {
    z <- result[result$method == m, ]
    data.frame(method = m, fits = nrow(z), failures = sum(z$fit_status != "OK"),
      warnings = sum(nzchar(z$warning)), mismatches = sum(z$regression_status != "PASS"),
      max_forecast_abs_diff = max(z$forecast_abs_diff),
      max_theta_abs_diff = if (m == "AutoTheta") max(z$theta_abs_diff) else NA_real_)
  }))
  write.csv(qa, file.path(out, "EXTERNAL_REGRESSION_QA.csv"), row.names = FALSE, na = "")
  writeLines("PASS", file.path(out, "STATUS.txt"))
  print(qa)
}

if (sys.nframe() == 0L) main()
