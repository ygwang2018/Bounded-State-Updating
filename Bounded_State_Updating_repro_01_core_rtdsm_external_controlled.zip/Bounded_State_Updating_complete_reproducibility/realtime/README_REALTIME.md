# RTDSM historical inputs, ten-method full refit, and five-method replay

## Fixed information sets

Five series (EMPLOY, IPT, IPM, H, CUT), 90 monthly targets from January 2018 through June 2025, and 450 series–origin pairs are retained. PRE uses V(t), REF uses V(t+2). Both histories contain the same dates t−120 through t−1. The target is the Third release at t, from V(t+3); the history endpoint matches First in PRE and Third in REF.

`complete_vintage_training_long.csv` contains 108,000 values: 5 × 90 × 2 × 120. The origin manifest and release/support checks document the information sets. EMPLOY is a within-vintage monthly difference in thousands; IPT/IPM/H use 100 × [(level ratio)^12 − 1]; CUT remains a level in percentage points. The provider's seasonally adjusted inputs are fitted at frequency one. The materialized histories and `frozen_release_targets.csv`, not a fresh provider download, define these results.

## Two fitting entry points, one ten-method comparison

| Entry point | Responsibility | Output |
|---|---|---|
| `run_complete_vintage_forecasting.R` | Original seven-method full refit and five-Structural-Theta reference-frozen replay | `realtime/reproduced/` |
| `run_external_automatic_benchmarks.R` | ETS, AutoARIMA and signed AutoTheta full refit only | Package `reproduced/external_smoke/` or `reproduced/external_full/` |

The seven original methods are ST-Author, G-MATCH, Huber-ST, MB-ST, CB-ST, ROBETS and Naive. `complete_vintage_full_refit_long.csv` retains their 3,150 paired PRE/REF rows. ETS/AutoARIMA records are in `../R1_R2/05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FITS.csv` and `_FORECASTS.csv`; AutoTheta's 900 records are in `R2_AUTOTHETA_FITS.csv` in that same directory.

The current 500-row full-refit comparison is `../R1_R2/07_SUMMARIES/R2_TEN_METHOD_COMPARISON.csv`. It contains all ten methods at both interfaces in the full period and four phases (26, 5, 17 and 42 targets per series). The old nine-method `R2_COMPARISON_WITH_EXISTING_METHODS.csv` and original seven-method summaries remain historical provenance. Current table code reads only the ten-method summary for Main Tables 4–5 and S9–S11.

## External runner and upstream dependency

Use R 4.3.3 with forecast 8.24.0 and data.table (recorded 1.17.0). ETS and AutoARIMA use their original default calls. All three methods use h=1, frequency=1 and the same 120-observation histories, with independent PRE/REF fits. The R2 fread and AutoTheta read.csv input readers are retained; the supplied input arrays agree exactly under the two readers in the recorded environment.

Obtain the pinned Sbrana–Silvestrini Part I source file using `THIRD_PARTY_PROVENANCE.md`. From this directory:

```sh
Rscript run_external_automatic_benchmarks.R --upstream "PATH/Structural Theta codes and results (Part I).R" --mode smoke --workers 4
Rscript run_external_automatic_benchmarks.R --upstream "PATH/Structural Theta codes and results (Part I).R" --mode full --workers 4
```

Both modes check newly fitted records against the frozen results. The smoke union has 58 histories and 174 fits; full mode has 900 histories and 2,700 fits. Optional `--package-root`, `--autotheta-records` and `--output` support isolated staging. A completed output directory is never silently reused. The runner writes fit-level predictions/selection metadata and maximum-difference QA. It stops on a real mismatch and does not retry, alter the algorithm or replace any scientific source. Boolean CSV spelling (`False` versus `FALSE`) is normalized as a logical value; numerical tolerances are not relaxed.

`autotheta_adapter.R` is a loader and return-field instrumentation layer, not a copied upstream implementation. It extracts only SeasonalityTest, Theta.models.fit and AutoTheta definitions. The sole forecast adaptation passes `positive=FALSE` into the two internal fit calls. Candidate construction/exclusions, [1,3] theta search, SES extrapolation, mean scaling and fitted-MAE selection remain upstream. AutoTheta here denotes the accepted `AUTOTHETA_ST2025_SIGNED` identity; it is not forecast::thetaf or a newly substituted 4Theta implementation.

`R2_AUTOTHETA_SIGNED_EXACT_DIAGNOSTIC.csv` preserves the 875 equal / 25 clipping-different / 5 negative-base cases. The original exact diagnostic used 25 actual clip-trigger refits and 875 algebraically equal no-clip records. It is a diagnostic, not an eleventh comparison method, a second primary benchmark or a refitting-depth study.

## Five-method fixed context and seven-method target sensitivity

`complete_vintage_ref_frozen_long.csv` retains 2,250 corrected five-method rows. At each origin, the numerical REF initial state, fitted parameters and working-variance context are fixed while replaying the actual PRE observations. No such replay is assigned to ROBETS, AutoTheta, ETS, AutoARIMA or Naive.

Let A be PRE at its own fit, B be PRE at the fixed REF context and C be REF at that same context. A−C = (B−C)+(A−B) is evaluated before taking absolute values. The difference of mean absolute full-refit and fixed-context changes is not the mean absolute refitting component. The signed records are in `../w11_source_data/rtdsm_signed_revision_decomposition.csv`.

Most_Recent sensitivity retains the same original seven-method PRE forecasts and archived targets; it does not refit and does not acquire the external three methods. Fitting-depth sensitivity remains the four internal methods. Figure 4 retains G-MATCH, Huber-ST, MB-ST, CB-ST and Naive only: 60 forecasts and 12 Third-release targets across EMPLOY/CUT, March–August 2020. August is a displayed continuation, not an extension of the March–July accuracy window.

The historical data-only preflight and fitting-depth runners document original execution paths. Raw provider workbook collections are not included. The current table generators write independently to a reproduction directory and never repair or rewrite the fixed-context, target-sensitivity or Figure 4 sources.
