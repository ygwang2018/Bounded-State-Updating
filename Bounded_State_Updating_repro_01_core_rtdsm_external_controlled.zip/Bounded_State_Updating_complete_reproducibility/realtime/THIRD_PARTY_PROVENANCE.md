# AutoTheta upstream provenance and packaging decision

Checked on **2026-09-11** against the live official repositories, their recursive Git trees, repository license metadata, `/license` endpoint, source text and README where present. The revisions below also match the original internal C28 snapshots.

| Role | Official repository | Checked / pinned revision | Live license findings |
|---|---|---|---|
| Primary executed implementation | https://github.com/giacsbrana/Structural-THETA-Codes-and-results | `dbda1fc9a91b2cdc89aec627201bb465547c5b4a` (main) | Repository metadata `license: null`; `/license` returned 404. The tree contains only Part I and Part II R files. No licensing statement was found in their text. |
| Method provenance, not a substituted implementation | https://github.com/vangspiliot/4Theta | `dcfa50aef7a7863acc57b4df67afa7b69055b799` (master) | Repository metadata `license: null`; `/license` returned 404. The tree contains `.gitignore`, `4Theta method.R` and `README.md`; no licensing statement was found. |

The Structural Theta repository supplies the paper's reproduction scripts. The primary AutoTheta definition is in **Structural Theta codes and results (Part I).R**. 4Theta supplies the generalized/automatic-Theta provenance; this integration does not substitute FourTheta for the accepted Sbrana–Silvestrini AutoTheta.

## Acquisition

Obtain Part I at the pinned revision from the official repository, save it outside the distributable package, and supply its path with `--upstream`. Its pinned raw-file address is:

```text
https://raw.githubusercontent.com/giacsbrana/Structural-THETA-Codes-and-results/dbda1fc9a91b2cdc89aec627201bb465547c5b4a/Structural%20Theta%20codes%20and%20results%20%28Part%20I%29.R
```

For a local Windows reproduction, a download command is:

```powershell
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/giacsbrana/Structural-THETA-Codes-and-results/dbda1fc9a91b2cdc89aec627201bb465547c5b4a/Structural%20Theta%20codes%20and%20results%20%28Part%20I%29.R" -OutFile "$env:TEMP\st-part-i.R"
Rscript realtime/run_external_automatic_benchmarks.R --upstream "$env:TEMP\st-part-i.R" --mode full --workers 4
```

Alternatively, the runner's default path is `realtime/upstream/Structural Theta codes and results (Part I).R`; this is a user-populated input location, not a vendored source directory. Do not include a downloaded upstream file when redistributing this package. There is no need to obtain M4/Mcomp data or execute the full upstream script for this RTDSM runner.

## Loader and adapter

`autotheta_adapter.R` parses the user-supplied file and evaluates only the top-level definitions of `SeasonalityTest`, `Theta.models.fit` and `AutoTheta`. It does not execute the other upstream expressions, including the Monte Carlo and M4 study code.

The runtime patch forwards the existing `positive` argument to the two internal `Theta.models.fit` calls and invokes the top-level function with `positive=FALSE`. This disables point-forecast nonnegativity clipping for the signed transformed histories. No candidate, exclusion, theta interval, sample-mean scaling, SES call, fitted-MAE selection criterion, horizon or frequency is changed. Return-only instrumentation exposes unrounded theta, selected family, SES parameters and the scaled forecast for regression checks; it does not enter estimation.

The frozen raw metadata are retained in `R2_AUTOTHETA_FITS.csv`. The original exact clipping diagnostic is retained separately and is not a primary benchmark. The local internal snapshots and C28's copied implementation/parallel runners remain in their original internal archive, not in this package.

## Distribution decision

No explicit redistribution license was found at the inspected revisions. This integration adds **no complete Part I, Part II or 4Theta source snapshot, no repository clone and no copied C28 AutoTheta function-body implementation** to the distributable package. It supplies the RST-O runner, loading/instrumentation layer, frozen result records and provenance/acquisition instructions. AutoTheta refitting is therefore conditional on the separately obtained upstream source, whereas regenerating the six numerical tables needs only the packaged records.

No third-party license has been invented or changed. This document does not relicense the existing project code or dependencies. GitHub's official explanation distinguishes public repository visibility from an open-source license: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository .
