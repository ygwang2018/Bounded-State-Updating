# RST-O's loader and instrumentation, not a redistributed upstream implementation.
# Obtain the pinned Sbrana--Silvestrini Part I file described in
# THIRD_PARTY_PROVENANCE.md. Never source the whole upstream experiment script.

load_autotheta_upstream <- function(path) {
  if (!file.exists(path)) stop("Supply the upstream Part I file via --upstream.")
  wanted <- c("SeasonalityTest", "Theta.models.fit", "AutoTheta")
  expressions <- parse(path, keep.source = FALSE, encoding = "UTF-8")
  env <- new.env(parent = globalenv())
  env$ses <- forecast::ses
  env$naive <- forecast::naive
  found <- setNames(integer(length(wanted)), wanted)
  for (expr in expressions) {
    if (!is.call(expr)) next
    if (!(identical(expr[[1L]], as.name("<-")) || identical(expr[[1L]], as.name("=")))) next
    if (!is.symbol(expr[[2L]])) next
    name <- as.character(expr[[2L]])
    if (name %in% wanted) {
      eval(expr, envir = env)
      found[name] <- found[name] + 1L
    }
  }
  if (any(found != 1L)) stop("The upstream file must define each of the three functions once.")

  # The only behavioral adaptation: forward the existing positive argument to
  # the two internal calls. Candidate construction and all estimation stay upstream.
  calls_changed <- 0L
  forward_positive <- function(expr) {
    if (!is.call(expr)) return(expr)
    if (identical(expr[[1L]], as.name("Theta.models.fit"))) {
      expr$positive <- as.name("positive")
      calls_changed <<- calls_changed + 1L
    }
    if (length(expr) > 1L) for (j in seq.int(2L, length(expr))) {
      if (is.call(expr[[j]])) expr[[j]] <- forward_positive(expr[[j]])
    }
    expr
  }
  body(env$AutoTheta) <- forward_positive(body(env$AutoTheta))
  if (calls_changed != 2L) stop("Unexpected upstream point-forecast call structure.")

  # Observe the unrounded selected theta and SES parameters. These fields are
  # returned only: they do not enter the objective, search, selection or forecast.
  b <- as.list(body(env$Theta.models.fit))
  clip <- which(vapply(b, function(x) {
    is.call(x) && identical(x[[1L]], as.name("if")) &&
      identical(x[[2L]], quote(positive == T))
  }, logical(1L)))
  if (length(clip) != 1L) stop("Unexpected upstream clipping branch.")
  b <- append(b, list(quote(.rst_raw_forecast <- as.numeric(forecastsOut))), after = clip - 1L)
  extra <- quote({
    pars <- sesmodel$model$par
    output$theta <- as.numeric(theta)
    output$seasonality_code <- seasonality
    output$combination_code <- model
    output$trend_code <- curve
    output$SES_alpha <- unname(pars["alpha"])
    output$SES_beta <- if ("beta" %in% names(pars)) unname(pars["beta"]) else NA_real_
    output$SES_par2_name <- names(pars)[2L]
    output$SES_par2_value <- unname(pars[2L])
    output$raw_forecast_scaled <- .rst_raw_forecast
    output$selected_forecast_scaled <- as.numeric(forecastsOut)
  })
  b <- append(b, list(extra), after = length(b) - 1L)
  body(env$Theta.models.fit) <- as.call(b)

  b <- as.list(body(env$AutoTheta))
  extra <- quote({
    fields <- c("theta", "seasonality_code", "combination_code", "trend_code",
                "SES_alpha", "SES_beta", "SES_par2_name", "SES_par2_value",
                "raw_forecast_scaled", "selected_forecast_scaled")
    for (name in fields) output[[name]] <- selected.model[[name]]
    output$base <- as.numeric(base)
    output$candidate_names <- listnames
  })
  b <- append(b, list(extra), after = length(b) - 1L)
  body(env$AutoTheta) <- as.call(b)

  function(y, exact = FALSE) {
    stopifnot(length(y) == 120L, all(is.finite(y)))
    env$AutoTheta(stats::ts(y, frequency = 1), fh = 1L, positive = exact)
  }
}
