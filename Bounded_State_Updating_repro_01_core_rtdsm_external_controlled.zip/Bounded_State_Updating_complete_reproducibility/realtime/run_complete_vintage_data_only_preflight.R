# RST-O Discussion 3
# Data-only preflight for origin-consistent complete vintages.
# NO forecasting/model fitting is allowed in this script.

suppressPackageStartupMessages({
  library(readxl)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
root <- if (length(script_arg)) dirname(normalizePath(sub("^--file=", "", script_arg[[1L]]), winslash = "/", mustWork = TRUE)) else normalizePath(getwd(), winslash = "/", mustWork = TRUE)

specs <- data.frame(
  series = c("EMPLOY","IPT","IPM","H","CUT"),
  file = c(
    "EMPLOY_complete_vintages.xlsx",
    "IPT_complete_vintages.xlsx",
    "IPM_complete_vintages.xlsx",
    "H_complete_vintages.xlsx",
    "CUT_complete_vintages.xlsx"
  ),
  transform = c("diff","growth","growth","growth","level"),
  prefix = c("EMPLOY","IPT","IPM","H","CUT"),
  stringsAsFactors = FALSE
)

parse_obs <- function(x) {
  x <- trimws(as.character(x))
  z <- regexec("^([0-9]{4})[:/-]([0-9]{1,2})$", x)
  m <- regmatches(x, z)
  out <- rep(as.Date(NA), length(x))
  ok <- lengths(m) == 3L
  if (any(ok)) {
    yy <- as.integer(vapply(m[ok], `[`, "", 2))
    mm <- as.integer(vapply(m[ok], `[`, "", 3))
    out[ok] <- as.Date(sprintf("%04d-%02d-01", yy, mm))
  }
  out
}

parse_vintage <- function(nm, prefix) {
  z <- regexec(paste0("^", prefix, "([0-9]{2})M([0-9]{1,2})$"), nm, ignore.case=TRUE)
  m <- regmatches(nm, z)[[1]]
  if (length(m) != 3L) return(as.Date(NA))
  yy <- as.integer(m[2]); mm <- as.integer(m[3])
  yy <- if (yy <= 40) 2000 + yy else 1900 + yy
  as.Date(sprintf("%04d-%02d-01", yy, mm))
}

read_complete <- function(path, prefix) {
  sh <- excel_sheets(path)
  pieces <- vector("list", length(sh))
  for (i in seq_along(sh)) {
    x <- read_excel(path, sheet=sh[i], .name_repair="minimal")
    if (ncol(x) < 2L) next
    names(x)[1] <- "obs_raw"
    x$obs_date <- parse_obs(x$obs_raw)
    keep <- !is.na(x$obs_date)
    x <- x[keep, c("obs_date", setdiff(names(x), c("obs_raw","obs_date"))), drop=FALSE]
    pieces[[i]] <- x
  }
  pieces <- Filter(Negate(is.null), pieces)
  if (!length(pieces)) stop("No readable sheets: ", path)

  all_dates <- sort(unique(do.call(c, lapply(pieces, `[[`, "obs_date"))))
  out <- data.frame(obs_date=all_dates)
  seen <- character()
  for (x in pieces) {
    vcs <- setdiff(names(x), "obs_date")
    for (v in vcs) {
      if (v %in% seen) {
        old <- out[[v]]
        idx <- match(x$obs_date, out$obs_date)
        new <- suppressWarnings(as.numeric(x[[v]]))
        conflict <- !is.na(old[idx]) & !is.na(new) & abs(old[idx]-new) > 1e-10
        if (any(conflict, na.rm=TRUE)) stop("Duplicate vintage conflict: ", v)
        fill <- is.na(old[idx]) & !is.na(new)
        old[idx[fill]] <- new[fill]
        out[[v]] <- old
      } else {
        idx <- match(out$obs_date, x$obs_date)
        out[[v]] <- suppressWarnings(as.numeric(x[[v]][idx]))
        seen <- c(seen, v)
      }
    }
  }

  vintage_cols <- setdiff(names(out), "obs_date")
  vd <- as.Date(vapply(vintage_cols, parse_vintage, as.Date(NA), prefix=prefix), origin="1970-01-01")
  good <- !is.na(vd)
  out <- out[, c("obs_date", vintage_cols[good]), drop=FALSE]
  attr(out, "vintage_dates") <- setNames(vd[good], vintage_cols[good])
  out
}

month_add <- function(d, k) {
  lt <- as.POSIXlt(d)
  lt$mon <- lt$mon + k
  as.Date(format(as.Date(lt), "%Y-%m-01"))
}

vintage_name_for_date <- function(vdates, d) {
  n <- names(vdates)[which(vdates == d)]
  if (length(n) != 1L) NA_character_ else n
}

transform_window <- function(obs_date, level, target, kind) {
  end <- month_add(target, -1L)
  if (kind %in% c("diff","growth")) {
    start_level <- month_add(target, -121L)
    want <- seq(start_level, end, by="month")
    idx <- match(want, obs_date)
    if (anyNA(idx)) return(list(ok=FALSE, reason="missing_obs_date"))
    z <- level[idx]
    if (any(!is.finite(z))) return(list(ok=FALSE, reason="nonfinite_level"))
    y <- if (kind == "diff") diff(z) else 100*((z[-1]/z[-length(z)])^12 - 1)
    dates <- want[-1]
  } else {
    start <- month_add(target, -120L)
    want <- seq(start, end, by="month")
    idx <- match(want, obs_date)
    if (anyNA(idx)) return(list(ok=FALSE, reason="missing_obs_date"))
    y <- level[idx]; dates <- want
    if (any(!is.finite(y))) return(list(ok=FALSE, reason="nonfinite_level"))
  }
  list(ok=length(y)==120L && max(dates)==end, reason=NA_character_, dates=dates, y=as.numeric(y))
}

targets <- seq(as.Date("2018-01-01"), as.Date("2025-06-01"), by="month")
qa <- list(); census <- list()

for (ii in seq_len(nrow(specs))) {
  sp <- specs[ii,]
  path <- file.path(root, sp$file)
  if (!file.exists(path)) stop("Missing workbook: ", path)

  x <- read_complete(path, sp$prefix)
  vd <- attr(x, "vintage_dates")
  req <- seq(as.Date("2018-01-01"), as.Date("2025-08-01"), by="month")

  census[[sp$series]] <- data.frame(
    series=sp$series,
    n_obs=nrow(x),
    n_vintages=length(vd),
    first_vintage=min(vd),
    last_vintage=max(vd),
    required_vintages=length(req),
    missing_required=sum(!(req %in% vd)),
    duplicate_vintage_dates=sum(duplicated(vd))
  )

  rows <- vector("list", length(targets))
  for (j in seq_along(targets)) {
    t <- targets[j]
    pre_d <- t; ref_d <- month_add(t, 2L)
    pre_n <- vintage_name_for_date(vd, pre_d)
    ref_n <- vintage_name_for_date(vd, ref_d)

    rec <- data.frame(
      series=sp$series, target=t,
      pre_vintage=pre_n, ref_vintage=ref_n,
      pre_exists=!is.na(pre_n), ref_exists=!is.na(ref_n),
      pre_ok=FALSE, ref_ok=FALSE, same_dates=FALSE,
      leakage=NA, reason=NA_character_
    )

    if (is.na(pre_n) || is.na(ref_n)) {
      rec$reason <- "missing_vintage"; rows[[j]] <- rec; next
    }

    pre <- transform_window(x$obs_date, x[[pre_n]], t, sp$transform)
    ref <- transform_window(x$obs_date, x[[ref_n]], t, sp$transform)
    rec$pre_ok <- isTRUE(pre$ok); rec$ref_ok <- isTRUE(ref$ok)

    if (!pre$ok || !ref$ok) {
      rec$reason <- paste(na.omit(c(
        if (!pre$ok) paste0("PRE:",pre$reason),
        if (!ref$ok) paste0("REF:",ref$reason)
      )), collapse=";")
      rows[[j]] <- rec; next
    }

    rec$same_dates <- identical(pre$dates, ref$dates)
    rec$leakage <- max(pre$dates) >= t || max(ref$dates) >= t
    if (!rec$same_dates) rec$reason <- "date_support_mismatch"
    if (isTRUE(rec$leakage)) rec$reason <- "target_leakage"
    rows[[j]] <- rec
  }
  qa[[sp$series]] <- do.call(rbind, rows)
}

census_df <- do.call(rbind, census)
qa_df <- do.call(rbind, qa)

write.csv(census_df, file.path(root, "complete_vintage_census.csv"), row.names=FALSE)
write.csv(qa_df, file.path(root, "complete_vintage_origin_support_qa.csv"), row.names=FALSE)

summary_df <- do.call(rbind, lapply(split(qa_df, qa_df$series), function(z) data.frame(
  series=z$series[1],
  n_targets=nrow(z),
  pre_exists=sum(z$pre_exists %in% TRUE, na.rm=TRUE),
  ref_exists=sum(z$ref_exists %in% TRUE, na.rm=TRUE),
  pre_ok=sum(z$pre_ok %in% TRUE, na.rm=TRUE),
  ref_ok=sum(z$ref_ok %in% TRUE, na.rm=TRUE),
  same_dates=sum(z$same_dates %in% TRUE, na.rm=TRUE),
  leakage_fail=sum(z$leakage %in% TRUE, na.rm=TRUE),
  reason_fail=sum(!is.na(z$reason) & nzchar(z$reason), na.rm=TRUE)
)))
write.csv(summary_df, file.path(root, "complete_vintage_origin_support_summary.csv"), row.names=FALSE)

cat("DATA-ONLY PREFLIGHT COMPLETE\n")
print(census_df)
print(summary_df)
cat("\nNo forecasting or model fitting was run.\n")
