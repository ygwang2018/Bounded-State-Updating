# RTDSM information-set construction and validation

The exact transformed PRE/REF histories used by the paper are already included as `complete_vintage_training_long.csv`, so the reported forecasting analyses can be reproduced without access to the original provider workbook collection.

When the archived complete-vintage XLSX files are available, `run_complete_vintage_data_only_preflight_stdlib.py` reconstructs the 5 series x 90 targets x 2 interfaces x 120 observations materialized history file and associated support QA. The two R scripts (`run_complete_vintage_data_only_preflight.R` and `run_complete_vintage_data_only_preflight_xml2.R`) provide independent vintage-support validation using R readers.

The data-only construction stage performs no forecasting or model fitting.