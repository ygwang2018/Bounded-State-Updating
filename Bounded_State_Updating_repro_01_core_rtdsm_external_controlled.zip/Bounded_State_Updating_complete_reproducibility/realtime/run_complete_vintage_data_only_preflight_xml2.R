# RST-O Discussion 3
# Origin-consistent complete-vintage DATA-ONLY preflight
# Pure XLSX/XML implementation: requires xml2 only.
# NO forecasting/model fitting.

suppressPackageStartupMessages(library(xml2))
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
root <- if (length(script_arg)) dirname(normalizePath(sub("^--file=", "", script_arg[[1L]]), winslash = "/", mustWork = TRUE)) else normalizePath(getwd(), winslash = "/", mustWork = TRUE)

specs <- data.frame(
  series=c("EMPLOY","IPT","IPM","H","CUT"),
  file=c("EMPLOY_complete_vintages.xlsx","IPT_complete_vintages.xlsx","IPM_complete_vintages.xlsx","H_complete_vintages.xlsx","CUT_complete_vintages.xlsx"),
  transform=c("diff","growth","growth","growth","level"),
  prefix=c("EMPLOY","IPT","IPM","H","CUT"), stringsAsFactors=FALSE)

col_to_int <- function(x) vapply(x,function(s){z<-utf8ToInt(toupper(s)); Reduce(function(a,b)a*26L+(b-64L),z,init=0L)},integer(1))
cell_col <- function(ref) sub("[0-9]+$","",ref)

xlsx_matrix <- function(path){
  td<-tempfile("xlsx_"); dir.create(td); on.exit(unlink(td,recursive=TRUE,force=TRUE),add=TRUE)
  members<-unzip(path,list=TRUE)$Name
  need<-intersect(c("xl/worksheets/sheet1.xml","xl/sharedStrings.xml"),members)
  unzip(path,files=need,exdir=td)
  shared<-character(); ssf<-file.path(td,"xl/sharedStrings.xml")
  if(file.exists(ssf)){
    ss<-read_xml(ssf)
    shared<-vapply(xml_find_all(ss,'.//*[local-name()="si"]'),function(si)paste(xml_text(xml_find_all(si,'.//*[local-name()="t"]')),collapse=""),character(1))
  }
  sh<-read_xml(file.path(td,"xl/worksheets/sheet1.xml"))
  rows<-xml_find_all(sh,'.//*[local-name()="sheetData"]/*[local-name()="row"]')
  if(!length(rows)) stop("No rows: ",basename(path))
  parse_cell<-function(cn){
    typ<-xml_attr(cn,"t")
    if(!is.na(typ)&&typ=="inlineStr") return(paste(xml_text(xml_find_all(cn,'./*[local-name()="is"]//*[local-name()="t"]')),collapse=""))
    vn<-xml_find_first(cn,'./*[local-name()="v"]'); if(inherits(vn,"xml_missing")) return(NA_character_)
    v<-xml_text(vn); if(!is.na(typ)&&typ=="s") return(shared[as.integer(v)+1L]); v
  }
  refs<-unlist(lapply(rows,function(r)xml_attr(xml_find_all(r,'./*[local-name()="c"]'),"r")),use.names=FALSE)
  nc<-max(col_to_int(cell_col(refs))); nr<-max(as.integer(xml_attr(rows,"r")))
  out<-matrix(NA_character_,nr,nc)
  for(r in rows){ rr<-as.integer(xml_attr(r,"r")); cells<-xml_find_all(r,'./*[local-name()="c"]'); if(!length(cells))next; cc<-col_to_int(cell_col(xml_attr(cells,"r"))); out[rr,cc]<-vapply(cells,parse_cell,character(1)) }
  out
}

parse_obs <- function(x){
  x<-trimws(as.character(x)); z<-regexec("^([0-9]{4})[:/-]?M?([0-9]{1,2})$",x,ignore.case=TRUE); m<-regmatches(x,z)
  out<-rep(as.Date(NA),length(x)); ok<-lengths(m)==3L
  if(any(ok)){ yy<-as.integer(vapply(m[ok],`[`,"",2)); mm<-as.integer(vapply(m[ok],`[`,"",3)); good<-mm>=1&mm<=12; ii<-which(ok)[good]; out[ii]<-as.Date(sprintf("%04d-%02d-01",yy[good],mm[good])) }
  out
}

parse_vintage <- function(x,prefix){
  x<-trimws(as.character(x)); z<-regexec(paste0("^",prefix,"([0-9]{2,4})M([0-9]{1,2})$"),x,ignore.case=TRUE); m<-regmatches(x,z)
  out<-rep(as.Date(NA),length(x)); ok<-lengths(m)==3L
  if(any(ok)){ yy<-as.integer(vapply(m[ok],`[`,"",2)); yy<-ifelse(yy<100,ifelse(yy<=40,2000+yy,1900+yy),yy); mm<-as.integer(vapply(m[ok],`[`,"",3)); good<-mm>=1&mm<=12; ii<-which(ok)[good]; out[ii]<-as.Date(sprintf("%04d-%02d-01",yy[good],mm[good])) }
  out
}

month_add <- function(d,k){ y<-as.integer(format(d,"%Y")); m<-as.integer(format(d,"%m"))+k; y2<-y+(m-1L)%/%12L; m2<-(m-1L)%%12L+1L; as.Date(sprintf("%04d-%02d-01",y2,m2)) }

read_complete <- function(path,prefix){
  mat<-xlsx_matrix(path); hdr<-trimws(mat[1,]); keepc<-!is.na(hdr)&nzchar(hdr); mat<-mat[,keepc,drop=FALSE]; hdr<-hdr[keepc]
  obs<-parse_obs(mat[-1,1]); keepr<-!is.na(obs); vals<-mat[-1,-1,drop=FALSE][keepr,,drop=FALSE]
  nums<-matrix(suppressWarnings(as.numeric(vals)),nrow=nrow(vals),ncol=ncol(vals),dimnames=list(NULL,hdr[-1]))
  vd<-parse_vintage(hdr[-1],prefix); good<-!is.na(vd)
  list(obs_date=obs[keepr],values=nums[,good,drop=FALSE],vintage_dates=setNames(vd[good],colnames(nums)[good]))
}

vname <- function(vd,d){h<-names(vd)[vd==d]; if(length(h)==1L) h else NA_character_}

make_window <- function(obj,vn,target,kind){
  level<-obj$values[,vn]; obs<-obj$obs_date; end<-month_add(target,-1L)
  if(kind%in%c("diff","growth")){
    want<-seq(month_add(target,-121L),end,by="month"); idx<-match(want,obs); if(anyNA(idx))return(list(ok=FALSE,reason="missing_obs_date")); z<-level[idx]; if(any(!is.finite(z)))return(list(ok=FALSE,reason="nonfinite_level")); y<-if(kind=="diff")diff(z) else 100*((z[-1]/z[-length(z)])^12-1); dates<-want[-1]
  } else {
    want<-seq(month_add(target,-120L),end,by="month"); idx<-match(want,obs); if(anyNA(idx))return(list(ok=FALSE,reason="missing_obs_date")); y<-level[idx]; dates<-want; if(any(!is.finite(y)))return(list(ok=FALSE,reason="nonfinite_level"))
  }
  list(ok=length(y)==120L && max(dates)==end,reason=NA_character_,dates=dates,y=as.numeric(y))
}

targets<-seq(as.Date("2018-01-01"),as.Date("2025-06-01"),by="month")
required<-seq(as.Date("2018-01-01"),as.Date("2025-08-01"),by="month")
census<-list(); qa<-list(); cache<-list()

for(ii in seq_len(nrow(specs))){
  sp<-specs[ii,]; obj<-read_complete(file.path(root,sp$file),sp$prefix); cache[[sp$series]]<-obj; vd<-obj$vintage_dates
  census[[sp$series]]<-data.frame(series=sp$series,n_obs=length(obj$obs_date),n_vintages=length(vd),first_vintage=min(vd),last_vintage=max(vd),required_vintages=length(required),missing_required=sum(!(required%in%vd)),duplicate_vintage_dates=sum(duplicated(vd)),stringsAsFactors=FALSE)
  rows<-vector("list",length(targets))
  for(j in seq_along(targets)){
    t<-targets[j]; pn<-vname(vd,t); rn<-vname(vd,month_add(t,2L))
    rec<-data.frame(series=sp$series,target=t,pre_vintage=ifelse(is.na(pn),NA_character_,pn),ref_vintage=ifelse(is.na(rn),NA_character_,rn),pre_exists=!is.na(pn),ref_exists=!is.na(rn),pre_ok=FALSE,ref_ok=FALSE,same_dates=FALSE,leakage=NA,reason=NA_character_,stringsAsFactors=FALSE)
    if(is.na(pn)||is.na(rn)){rec$reason<-"missing_vintage"; rows[[j]]<-rec; next}
    pre<-make_window(obj,pn,t,sp$transform); ref<-make_window(obj,rn,t,sp$transform); rec$pre_ok<-isTRUE(pre$ok); rec$ref_ok<-isTRUE(ref$ok)
    if(!pre$ok||!ref$ok){bits<-character(); if(!pre$ok)bits<-c(bits,paste0("PRE:",pre$reason)); if(!ref$ok)bits<-c(bits,paste0("REF:",ref$reason)); rec$reason<-paste(bits,collapse=";"); rows[[j]]<-rec; next}
    rec$same_dates<-identical(pre$dates,ref$dates); rec$leakage<-max(pre$dates)>=t || max(ref$dates)>=t; if(!rec$same_dates)rec$reason<-"date_support_mismatch"; if(isTRUE(rec$leakage))rec$reason<-"target_leakage"; rows[[j]]<-rec
  }
  qa[[sp$series]]<-do.call(rbind,rows)
}

census_df<-do.call(rbind,census); qa_df<-do.call(rbind,qa)
summary_df<-do.call(rbind,lapply(split(qa_df,qa_df$series),function(z)data.frame(series=z$series[1],n_targets=nrow(z),pre_exists=sum(z$pre_exists%in%TRUE),ref_exists=sum(z$ref_exists%in%TRUE),pre_ok=sum(z$pre_ok%in%TRUE),ref_ok=sum(z$ref_ok%in%TRUE),same_dates=sum(z$same_dates%in%TRUE),leakage_fail=sum(z$leakage%in%TRUE,na.rm=TRUE),reason_fail=sum(!is.na(z$reason)&nzchar(z$reason)),stringsAsFactors=FALSE)))

write.csv(census_df,file.path(root,"complete_vintage_census.csv"),row.names=FALSE)
write.csv(qa_df,file.path(root,"complete_vintage_origin_support_qa.csv"),row.names=FALSE)
write.csv(summary_df,file.path(root,"complete_vintage_origin_support_summary.csv"),row.names=FALSE)
cat("DATA-ONLY PREFLIGHT COMPLETE\n"); print(census_df); print(summary_df); cat("No forecasting or model fitting was run.\n")
