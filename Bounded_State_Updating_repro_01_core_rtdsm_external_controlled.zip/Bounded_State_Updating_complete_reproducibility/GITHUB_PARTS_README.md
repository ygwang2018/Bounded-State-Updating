# GitHub split archives

For repository distribution, the complete reproducibility package is split across four ZIP archives. Extract all four archives into the same parent directory. They share the top-level folder `Bounded_State_Updating_complete_reproducibility/` and merge to reconstruct the full package.

1. `Bounded_State_Updating_repro_01_core_rtdsm_external_controlled.zip`
2. `Bounded_State_Updating_repro_02_M3_analysis.zip`
3. `Bounded_State_Updating_repro_03_M3_primary_results.zip`
4. `Bounded_State_Updating_repro_04_M3_primary_fits.zip`
