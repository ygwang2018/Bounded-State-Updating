# Recovered-code provenance

Two publication-relevant execution components were restored from the local project archive into this submission staging package.

## Controlled contamination / persistent-shift runner

Source: `RST_O_CODE20_ABC_ASSET_COMPLETION_20260812/RST-O/`, using the formal-authorized `abc_config.yml`.

The scientific Module B implementation (`R/abc_module_b.R`), C1 generator, orchestration, and C1 configuration are byte-identical to the corresponding files in the later `RST_O_FORMAL_MODULE_B_SHARDS_20260814` execution archive. The only material config difference is execution authorization metadata; the recovered copy is the formal-authorized version. The frozen publication result has 3,564 cell/profile/metric/contrast rows with `n=16538` and profiles matching the 11-profile controlled design.

## RTDSM complete-vintage information-set construction

Sources: `RST_O_REALTIME_US_COMPLETE_VINTAGE_PREFLIGHT_20260904/` and the already-packaged standard-library Python materializer.

The two R preflight scripts were restored and their local root assignment was changed only to resolve the directory containing the script. The standard-library Python materializer was changed similarly from a machine-specific absolute path to the script directory. No date window, transformation, target definition, or numeric logic was changed.