# Recovered-code provenance

Two publication-relevant execution components were restored from the validated project archive into the portable reproduction package.

## Controlled contamination / persistent-shift runner

The scientific Module B implementation, controlled-study generator, orchestration, and configuration were checked against the execution version used to produce the frozen publication results. The frozen Module B result contains 3,564 cell/profile/metric/contrast rows with `n=16538` and the 11-profile controlled design.

The public release keeps the scientific equations, DGPs, seed mapping, estimands, and frozen numerical records unchanged. Only portability/documentation repairs are applied.

## RTDSM complete-vintage information-set construction

The complete-vintage preflight scripts were restored from the validated project archive. Machine-specific root assignments were replaced by script-relative resolution. No date window, transformation, target definition, vintage mapping, or numerical formula was changed.
