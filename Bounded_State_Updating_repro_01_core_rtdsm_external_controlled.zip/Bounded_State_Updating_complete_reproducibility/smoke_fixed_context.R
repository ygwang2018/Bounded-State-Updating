# Run from the reproducibility-package root; base R only. Uses accepted stored fits.
for (f in c('rst_o_config.R','rst_o_filters.R','rst_o_objectives.R','rst_o_optimizer.R','rst_o_fit.R','rst_o_forecast.R')) source(file.path('method_code','R',f))
source('method_code/gate_f_fitted_adapters.R')
source('method_code/author_rt_functions.R')
tr <- read.csv('realtime/complete_vintage_training_long.csv')
qa <- read.csv('R1_R2/02_FIXED_INITIALIZATION/FIXED_INITIALIZATION_QA.csv')
fits <- read.csv('R1_R2/03_R1_RTDSM/R1_RTDSM_FITS.csv')
fits <- fits[fits$depth=='D1' & fits$interface=='REF', ]
qa$first_values_differ <- tolower(as.character(qa$first_values_differ))=='true'
origins <- unique(qa[c('series','target_date','first_values_differ')])
checks <- rbind(origins[origins$first_values_differ, ][1, ], origins[!origins$first_values_differ, ][1, ])
rows <- list();i <- 0L
for (k in seq_len(nrow(checks))) {
 sn <- checks$series[k]; tt <- checks$target_date[k]
 p <- tr[tr$series==sn & tr$target==tt & tr$interface=='PRE', ];p <- p[order(p$train_date), ]
 r <- tr[tr$series==sn & tr$target==tt & tr$interface=='REF', ];r <- r[order(r$train_date), ]
 y <- p$y; initial <- r$y[1]
 for (m in c('G_MATCH','HUBER_ST','MB_ST','CB_ST')) {
  f <- fits[fits$series==sn & fits$target_date==tt & fits$method==m, ];stopifnot(nrow(f)==1)
  filter <- function(init) switch(m,
   G_MATCH=rst_o_filter_gaussian(y,f$omega_final,f$q_final,initial_state=init),
   HUBER_ST=gate_f_huber_filter(y,f$omega_final,f$q_final,f$H_final,initial_state=init),
   MB_ST=gate_f_mb_filter(y,f$omega_final,f$q_final,f$H_final,initial_state=init),
   CB_ST=rst_o_filter_finite_nu(y,f$omega_final,f$q_final,f$H_final,5,initial_state=init))
  z <- filter(initial);new <- z$a_next_after_train
  q <- qa[qa$series==sn & qa$target_date==tt & qa$method==m, ];stopifnot(nrow(q)==1)
  err <- abs(new-q$new_frozen_pre_forecast)
  stopifnot(err<=1e-8*(1+abs(q$new_frozen_pre_forecast)),identical(z$a_pred[1],initial),identical(z$v[1],y[1]-initial))
  i<-i+1L;rows[[i]]<-data.frame(series=sn,target_date=tt,method=m,first_values_differ=checks$first_values_differ[k],absolute_difference=err)
 }
}
# Indexed Date iteration retains the class through all 90 origin labels.
dates <- sort(unique(as.Date(tr$target)))
for (j in seq_along(dates)) stopifnot(inherits(dates[j],'Date'), nchar(format(dates[j],'%Y-%m-%d'))==10)
write.csv(do.call(rbind,rows),'interface_smoke_results.csv',row.names=FALSE)
cat('PASS: eight stored-fit replay checks; initial observation retained; 90 Date labels.\n')
