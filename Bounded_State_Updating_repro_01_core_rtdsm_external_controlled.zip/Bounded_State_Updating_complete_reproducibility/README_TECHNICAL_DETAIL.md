# Bounded State Updating — technical reproducibility notes

Paper: **Bounded State Updating under Extreme Macroeconomic Releases and Data Revisions**.

The current RTDSM full-refit comparison contains ten methods: ST-Author, G-MATCH, Huber-ST, MB-ST, CB-ST, ROBETS, AutoTheta, Naive, ETS and AutoARIMA. The accepted scientific records are frozen. Regenerated displays and new reproduction runs are written separately; they do not replace those records.

## Rebuild the ten-method tables

From this package directory, with Python, pandas and numpy installed (validated with Python 3.12.6, pandas 3.0.5 and numpy 2.3.2):

```sh
python w11_scripts/build_tables.py
python w11_scripts/translate_tables.py
```

The default destination is `reproduced/ten_method_tables/`, with `EN/`, `ZH/`, `source_data/` and shared `table_rows.json`. Both commands also accept `--output PATH`. Paths to inputs are resolved from the script/package location. They rebuild Main Tables 4–5 and Supplement Tables S8–S11, including unrounded-value ranks, component-level bold and automatic-selection counts. The Chinese command reuses the English numerical rows and changes labels only.

`table_layouts.json` stores presentation-only templates: no numerical body rows. S8's AutoTheta heading describes candidate-family selections and median theta, and the note defines N/A/M/Lrl/Exp. Running these commands does not modify either manuscript directory, any PDF, Figure 4 or the smaller-scope sources.

Other accepted tables and figures retain their existing scientific inputs and manuscript displays; see `source_data_mapping.md`. The current six-table builder does not claim to rebuild every inline manuscript table. Earlier nine-method build/translation code is retained in `w11_scripts/nine_method_generators_provenance.zip`, with its original path assumptions; it is not a current entry point.

## Current records and historical provenance

`R1_R2/07_SUMMARIES/R2_TEN_METHOD_COMPARISON.csv` is the current 500-row summary: ten methods × five series × five phase labels × PRE/REF. It directly preserves the accepted AutoTheta result-only combined summary. The old `R2_COMPARISON_WITH_EXISTING_METHODS.csv` remains the original nine-method evidence; it is not silently relabeled or overwritten.

`realtime/complete_vintage_full_refit_long.csv` retains the original 3,150 seven-method paired PRE/REF records. ETS/AutoARIMA add 1,800 interface-level records in `R1_R2/05_R2_BENCHMARKS/`; `R2_AUTOTHETA_FITS.csv` adds 900 signed-interface AutoTheta records. Their combined comparison is ten-method full refit. `R2_AUTOTHETA_SIGNED_EXACT_DIAGNOSTIC.csv` records the original clipping diagnostic, not an eleventh benchmark. The larger internal research/execution archive remains separate; temporary runners and repository clones are not packaged here.

Current display-source copies are in `w11_source_data/rtdsm_ten_method_metrics.csv`, `rtdsm_mae_ranks.csv` and `AutoTheta_selection_summary.csv`. The historical `rtdsm_nine_method_metrics.csv` is retained but is not read or overwritten by the current builder.

## Refit the external automatic benchmarks

Required frozen environment: R 4.3.3, forecast 8.24.0; data.table is used for the historical R2 CSV reader (recorded version 1.17.0). Obtain the pinned upstream Part I file as described in `realtime/THIRD_PARTY_PROVENANCE.md`, then run:

```sh
Rscript realtime/run_external_automatic_benchmarks.R --upstream "PATH/Structural Theta codes and results (Part I).R" --mode smoke --workers 4
Rscript realtime/run_external_automatic_benchmarks.R --upstream "PATH/Structural Theta codes and results (Part I).R" --mode full --workers 4
```

Use `--workers 1` on a single-core machine. The two modes write to different `reproduced/external_*` directories; a rerun requires a fresh `--output` directory. Smoke covers 58 prespecified histories; full covers all 900 histories for each of ETS, AutoARIMA and AutoTheta. The runner compares forecasts, selected identity, theta and status to the frozen records with declared strict numerical tolerance, and stops on a mismatch. It never tunes, falls back or overwrites evidence. `EXTERNAL_REGRESSION_FITS.csv` contains all returned fit metadata and `EXTERNAL_REGRESSION_QA.csv` reports maximum deviations.

AutoTheta is **not self-contained from this package alone**: upstream source is obtained separately from its official repository. Our loader evaluates only three function definitions, not the upstream Monte Carlo/M4 experiment script. Its sole behavioral adaptation forwards `positive=FALSE` to disable nonnegative point-forecast clipping. The package does not supply a license for upstream code or redistribute complete third-party source snapshots.

## Preserve the smaller studies

The unchanged `realtime/run_complete_vintage_forecasting.R` remains the original seven-method full-refit plus five-Structural-Theta reference-frozen replay runner. Run it from `realtime/`; it requires robets 1.4 and writes to its separate `reproduced/` directory. It is separate from the external three-method regression runner, which does not re-run the seven-method study.

Fixed-context replay remains five Structural Theta implementations. Most_Recent sensitivity re-scores the original seven-method stored predictions without fitting. Fitting-depth sensitivity remains the four internal methods. Controlled and M3 studies are unchanged. Figure 4 retains its five selected method paths, 60 forecasts and 12 targets; its unchanged `w11_scripts/figure4.py` is a figure-production entry point, not an all-ten-method comparison.

The package includes the 108,000 materialized RTDSM training values, frozen release targets, method code, detailed accepted M3/controlled/depth results, and historical execution code. Raw provider workbook collections and the M3 dataset package are not duplicated. Historical M3/depth/preflight runners retain machine-path assumptions and are not represented as a universal one-command raw-download-to-paper workflow. Display regeneration uses the frozen records; new fitting requires the recorded environment and, for AutoTheta, the separately obtained upstream file.
