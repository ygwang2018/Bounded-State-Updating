FIXED_INITIALIZATION_STATUS = PASS



All 450 origins and all five methods were checked (2250 rows). Different initial observations: 38/450; equal-first-value regression origins: 412.

Each replay accepts an explicit initial-state argument. Frozen PRE uses the REF initial-state numerical value with unchanged PRE observations. Gaussian/Huber/MB/CB assimilate their first observation under the existing response; ST-Author retains the public first-innovation-zero convention.

All 3600 internal D1 full-refit forecasts reproduce the stored baseline; original versus modified default-initialization replay is identical. All 900 ST-Author full-refit forecasts reproduce the stored baseline. No full-refit scientific result changed.

Exactly changed frozen PRE predictions: 82; changes exceeding 1e-10*(1+abs(old forecast)): 49; largest absolute change: 0.066671451798868006. Equal-first-value cases have zero change.

The first PRE observation was not replaced. No preprocessing, parameter estimation or observation response was changed.
