# Software environment

Principal frozen empirical environment:

- R 4.3.3
- `forecast` 8.24.0
- `robets` 1.4
- `Mcomp` 2.8 where M3 data are required
- `data.table` 1.17.0 for the recorded external-benchmark reader

Recorded environment files: `../controlled/code/sessionInfo.txt` and `../controlled/code/renv.lock`.
Python requirements for final table/figure generation are described in `../README_TECHNICAL_DETAIL.md`.
