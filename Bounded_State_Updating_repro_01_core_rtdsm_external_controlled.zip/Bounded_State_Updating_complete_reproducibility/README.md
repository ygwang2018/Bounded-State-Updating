# Bounded State Updating — complete empirical reproducibility package

Paper: **Bounded State Updating under Extreme Macroeconomic Releases and Data Revisions**

This package combines the validated empirical reproduction materials from the earlier IJF submission package with the new long-sample RTDSM extension. It is organized so that the legacy frozen analyses remain unchanged while the July 1983--June 2025 RTDSM extension is kept in a separate, auditable module.

## What is included

### 1. long-sample RTDSM extension

`long_sample_rtdsm/`

- builds the balanced July 1983--June 2025 PRE/REF histories;
- validates the construction and internal-method fits against the frozen January 2018--June 2025 records;
- runs Gaussian-ST, Huber-ST, MB-ST, and CB-ST on the long sample;
- summarizes long-sample accuracy and revision results;
- retains an independent Python construction audit and provenance records.

Run from that directory with:

```sh
Rscript R/run_all.R
```

The ten Philadelphia Fed source workbooks are not redistributed. Place them in `long_sample_rtdsm/data_raw/` or pass the location requested by the scripts.

### 2. Controlled experiments

`controlled/`

Contains the formal controlled contamination and persistent-shift code, configurations, frozen 36-cell registry, component-level results, and Module B contrast results used for the protection--adaptation analysis.

The formal Module B entry point retained from the validated package is:

```sh
Rscript controlled/code/scripts/run_abc.R --phase formal --module B --output-dir reproduced/MODULE_B
```

### 3. M3 analyses

`M3/` and the supporting records in `R1_R2/04_R1_M3_PRIMARY/` and `R1_R2/07_SUMMARIES/`.

These contain the 3,003-series M3 contamination/refitting analyses, sign-specific and sign-pooled summaries, the fitted-layer decomposition, formal Gate F records, and the series-level records used in the manuscript and Supplementary Information.

Important entry points include:

```sh
Rscript M3/formal_gate_f/run_formal_gate_f.R
Rscript M3/fitted_layer/run_fitted_layer_decomposition.R
Rscript fitting_depth_code/modified/run_m3.R
```

### 4. Fitting-depth experiments

`fitting_depth_code/` plus frozen fit/result records and summaries under `R1_R2/`.

The retained D1/D3/DSTABLE code covers the four internal methods for the RTDSM and M3 scopes documented in the manuscript. The protocol and stopping rules are in `fitting_depth_code/protocol/`.

### 5. External benchmark reproduction

`realtime/`, `method_code/`, `external/`, `w11_source_data/`, and `R1_R2/05_R2_BENCHMARKS/`.

The validated ten-method RTDSM comparison contains Structural Theta (ST-Author), Gaussian-ST (G-MATCH), Huber-ST, MB-ST, CB-ST, ROBETS, AutoTheta, Naive, ETS, and AutoARIMA.

Key scripts are:

```sh
Rscript realtime/run_complete_vintage_forecasting.R
Rscript realtime/run_external_automatic_benchmarks.R
```

AutoTheta and the public Structural Theta benchmark depend on the public Sbrana--Silvestrini source. That upstream source is intentionally not redistributed. Its pinned identity and acquisition instructions are in `realtime/THIRD_PARTY_PROVENANCE.md`.

### 6. Tables, figures, and source-data mapping

- `tables/`: validated LaTeX table outputs from the earlier package;
- `figure_table_source_data/`: source data and figure generator for the controlled/analytic figures;
- `w11_scripts/`: ten-method table and Figure 4 generators;
- `w11_source_data/`: frozen source data for external-model selections, target sensitivity, fixed-context replay, and related displays;
- `source_data_mapping.md`: mapping from reported displays to their source files;
- `README_TECHNICAL_DETAIL.md`: detailed reproduction notes and software identities.

## Important scope notes

1. The older January 2018--June 2025 RTDSM results and all M3/controlled/fitting-depth/external-method records are retained exactly from the validated earlier reproducibility package; they are not silently recomputed or rewritten here.
2. The new July 1983--June 2025 analysis is isolated under `long_sample_rtdsm/` and must pass its frozen-overlap validation before its long-sample numerical outputs are treated as final.
3. Raw Philadelphia Fed RTDSM workbooks are public but are not redistributed.
4. Public third-party Structural Theta/AutoTheta source is not redistributed; provenance and acquisition instructions are included.
5. M3 data are obtained through the documented `Mcomp` R package/environment used by the original scripts.

## Recorded software environment

The earlier frozen reproduction records document R 4.3.3, `forecast` 8.24.0, `robets` 1.4, `Mcomp` 2.8, and the additional package versions recorded in the component scripts and lock files. See `environment/`, `controlled/code/renv.lock`, and `README_TECHNICAL_DETAIL.md`.

## Provenance

`PROVENANCE_COMPLETE.md` identifies which directories were copied byte-for-byte from the earlier validated IJF package and which directory contains the new long-sample extension.
