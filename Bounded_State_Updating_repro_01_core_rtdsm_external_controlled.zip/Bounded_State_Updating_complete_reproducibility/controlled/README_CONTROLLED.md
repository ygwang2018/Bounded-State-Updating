# Controlled-study reproduction

This directory contains the frozen controlled-study results used in the manuscript and the corresponding portable execution code under `code/`.

The current manuscript summaries use the 36 frozen design cells and 11 clean/contamination/persistent-shift profiles. Formal execution uses 16,538 paired seeds per cell-profile. The R implementation in `code/` is the same scientific Module B implementation used to produce the frozen publication results.

Run from `controlled/code/`:

```sh
Rscript scripts/run_abc.R --phase formal --module B --output-dir reproduced/MODULE_B
```

The primary frozen output in the submission package is `MODULE_B_CONTRAST_RESULTS.csv`. `controlled_component_cell_results.csv` is the same cell/profile/metric/contrast evidence retained under the publication-facing name used by the manuscript source mapping.