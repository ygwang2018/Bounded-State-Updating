#!/usr/bin/env Rscript

publication_run_root <- function() {
  if (file.exists("run_all.R") && file.exists(file.path("config", "config.R"))) return(".")
  file_argument <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  script <- if (length(file_argument)) sub("^--file=", "", file_argument[[1L]]) else "run_all.R"
  dirname(script)
}

publication_parse_cli <- function(args = commandArgs(trailingOnly = TRUE)) {
  if (length(args) != 2L || !identical(args[[1L]], "--mode") || !args[[2L]] %in% c("test", "reproduce", "full")) {
    stop("Usage: Rscript run_all.R --mode test|reproduce|full", call. = FALSE)
  }
  args[[2L]]
}

root <- publication_run_root()
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
for (file in c("config/config.R", "R/io.R", "R/model.R", "R/evaluation.R", "R/experiments.R")) {
  source(file.path(root, file), local = .GlobalEnv)
}

mode <- publication_parse_cli()
if (identical(mode, "test")) {
  Sys.setenv(RSTO_NO_AUTORUN = "YES")
  source(file.path(root, "tests", "equivalence.R"), local = .GlobalEnv)
  test_result <- publication_equivalence_run(root)
  if (identical(test_result$status, "FAIL")) stop("Differential fixture test failed; see EQUIVALENCE_REPORT.md.", call. = FALSE)
} else if (identical(mode, "reproduce")) {
  output <- publication_reproduce_canonical(root = root)
  rsto_write_session_info(file.path(root, "sessionInfo.txt"))
  message("Reproduced canonical tables and figure data in: ", output$table_dir)
} else {
  output <- publication_run_full()
  rsto_write_session_info(file.path(root, "sessionInfo.txt"))
  message("Completed serial full run in: ", output$summary_dir)
}
