# A/B/C execution runbook

Run from `RST-O` after `./cloud_setup.sh` in the authorized Ubuntu Cloud environment.

## Asset verification and tiny pilot

```bash
Rscript scripts/run_abc.R --phase pilot --verify
Rscript scripts/run_abc.R --phase pilot --module A
Rscript scripts/run_abc.R --phase pilot --module B
Rscript scripts/run_abc.R --phase pilot --module C
Rscript scripts/run_abc.R --phase pilot --summarize
Rscript scripts/audit_abc_pilot.R
Rscript tests/test_abc_execution_assets.R
```

Pilot output is written below `results/abc/pilot/`. It is plumbing evidence only and must not be interpreted scientifically.

## Authorized formal commands

The user directly authorized formal A/B/C execution on 2026-08-12. For Module A, the single formal command runs both A1 (all 3,003 series, draw 1) and A2 (the frozen 1,000-series sample, ten draws); it does not apply the ten-draw loop to all 3,003 series. Run:

```bash
Rscript scripts/run_abc.R --phase formal --module A
Rscript scripts/run_abc.R --phase formal --module B
Rscript scripts/run_abc.R --phase formal --module C
Rscript scripts/run_abc.R --phase formal --summarize
```

Formal outputs are `results/abc/formal/MODULE_A`, `MODULE_B`, and `MODULE_C`. Module A requires Mcomp/ROBETS and the accepted publication method panel; Modules B/C reuse the exact C1 generator and update implementation, with additive HB orchestration isolated in `R/abc_module_b.R`.
Module A retains row-level forecast/loss records. To keep the frozen formal B/C scales bounded in memory, Modules B/C update paired-contrast sufficient statistics online and write `n`, mean, sample variance, MCSE, and the configured normal-approximation interval; pilot mode retains paired-path records and the Module B update trace.
