# A/B/C execution runbook

Run these commands from `controlled/code/` in an R 4.3.3 environment with the package versions recorded in `renv.lock` and `sessionInfo.txt`.

## Pilot / resource checks

```bash
Rscript scripts/run_abc.R --phase pilot --module A --output-dir results/pilot_A
Rscript scripts/run_abc.R --phase pilot --module B --output-dir results/pilot_B
Rscript scripts/run_abc.R --phase pilot --module C --output-dir results/pilot_C
```

Pilot output is for execution checking only and is not a formal scientific result.

## Formal reproduction

```bash
Rscript scripts/run_abc.R --phase formal --module A --output-dir results/formal_A
Rscript scripts/run_abc.R --phase formal --module B --output-dir results/formal_B
Rscript scripts/run_abc.R --phase formal --module C --output-dir results/formal_C
```

Module A uses the M3 data and external comparator environment documented for the publication analysis. Modules B and C reuse the controlled-study generator and update implementations. Formal Module B is the primary controlled reproduction path used for the protection--adaptation analysis.

No `cloud_setup.sh` or separate `tests/` directory is bundled in this public package. The commands above are the supported entry points.
