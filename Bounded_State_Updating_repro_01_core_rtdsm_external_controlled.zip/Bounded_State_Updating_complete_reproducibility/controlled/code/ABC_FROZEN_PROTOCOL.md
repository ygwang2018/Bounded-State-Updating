# Frozen Module A/B/C execution protocol

This execution layer implements the publication protocol without redefining the scientific kernels.

- Module A: M3 amplitudes 2, 4, and 6 with paired signs and positions; draw 1 uses `202607130 + 100*i + 1`; the 1,000-series sample is allocated by frequency and within-frequency training-length quartile using proportional largest remainder, a minimum of five per nonempty stratum, and seed `20260803`; the ten position draws use `202607130 + 100*i + draw_id`.
- Module B: adds only HB with `c=1.345`, bounded mean correction, and Gaussian working-P update on the existing controlled paired path. Direct contrasts are HB-G, MB-HB, and CB-HB, always loss(first) minus loss(second).
- Module C: uses `nu={3,5,8,15}`, `P1={100,10000,1000000}`, and `H=1`; selects 12 of the frozen 36 controlled cells with design-only balance/full-rank/maximin constraints and tie seed `20260803`; formal execution is `N=5000` paired seeds.

The machine-readable execution configuration is `config/abc_config.yml`. Its phase flags distinguish pilot runs from the frozen formal reproduction commands; they do not change equations, DGPs, seed mappings, metrics, or comparator definitions.
