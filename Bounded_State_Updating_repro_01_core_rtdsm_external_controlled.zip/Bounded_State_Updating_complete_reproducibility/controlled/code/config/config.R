# Frozen M3 protocol constants for the publication implementation.
# This file contains no machine-specific paths. Set RSTO_CORE_ARCHIVE before
# running a mode that reads canonical evidence.

rsto_publication_config <- function() {
  list(
    archive_sha256 = "716386a329663877db7a72ae699a47d6fda12caacf53b784f7273101776a20a4",
    archive_root = "RST_O_PROJECT_ARCHIVE_CORE_COMPLETE_20260720",
    runner_archive = file.path(
      "03_FINAL_RUNNER_CHAIN",
      "RST_O_CODE_CHAT17_FINAL_RUNNER_ARCHIVE_RECOVERY_TO_TOTAL_LEAD17_20260720.zip"
    ),
    fix2_archive = "RST_O_M3_CONTAMINATION_FORMAL_RUNNER_PREEXECUTION_FIX2_SUBMISSION_TO_CODE_CHAT17_20260715.zip",
    fix3_archive = "RST_O_M3_CONTAMINATION_FORMAL_RUNNER_PREEXECUTION_FIX3_LITE_SUBMISSION_TO_CODE_CHAT17_20260715.zip",
    c1_archive = file.path(
      "01_C1_CONTROLLED_UNBLINDING",
      "RST_O_C1_CONTROLLED_UNBLINDING_AND_INTERPRETATION_PACKAGE_20260711.zip"
    ),
    m3_archive = file.path(
      "04_M3_FINAL_SALVAGE_RESULTS",
      "RST_O_M3_FINALIZATION_SALVAGE_SUBMISSION_TO_TOTAL_LEAD17_20260718.zip"
    ),
    frozen_runtime_sha256 = c(
      "rst_o_config.R" = "395f4a95afd0dcac3cfcf5d3358a940f079746fc333d812de8c8afd2622da086",
      "rst_o_filters.R" = "672533c90e5e808e0beb7de5d76f99353e7014a664c1919c6f23bff090ae5ad7",
      "rst_o_fit.R" = "279adbc980a01f588f3df1951519664a0e1dcf82afb391b5747009628cf28cee",
      "rst_o_forecast.R" = "6896b0337cc9ad6d4794edaf0e2c81e2190b0d63ffdca28615af03416439fda0",
      "rst_o_metrics.R" = "34be6287c51131a3278d57771d1ca498a884e7e5d2bbf641d662c5582aecc9b5",
      "rst_o_objectives.R" = "84e81149b48cd2b275e77e499f4076a10636de4fa05b37b1b7219e0dcec72248",
      "rst_o_optimizer.R" = "bbeaa0573cfc18a25041f31f7b0c194581332062b99fbd2524d2d11446c4b165",
      "rst_o_v1_7_revised_baselines.R" = "0bb28dd41a6dd64a838fb494a3d96b3f8620885c37d59ad38b59b111fa757278"
    ),
    required_packages = c(
      Mcomp = "2.8",
      robets = "1.4",
      digest = "0.6.37",
      jsonlite = "2.0.0",
      testthat = "3.2.3"
    ),
    expected_counts = list(
      series = 3003L,
      conditions = 5L,
      methods = 4L,
      chunks = 31L,
      chunk_size = 100L,
      forecast_rows = 740280L,
      metric_rows = 60060L,
      bootstrap_rows = 420L,
      frequencies = data.frame(
        period = c("YEARLY", "QUARTERLY", "MONTHLY", "OTHER"),
        n = c(645L, 756L, 1428L, 174L),
        frequency = c(1L, 4L, 12L, 1L),
        horizon = c(6L, 8L, 18L, 8L),
        stringsAsFactors = FALSE
      )
    ),
    conditions = c(
      "clean",
      "primary_AO_positive",
      "primary_AO_negative",
      "last_point_positive",
      "last_point_negative"
    ),
    method_ids = c(
      "STG",
      "IQR_ST",
      "RSTO_NU5_FROZEN_HISTORICAL_FLOW",
      "ROBETS_CREVITS_CROUX_VERSION_1_4"
    ),
    contamination = list(
      p_out = 0.05,
      c_out = 6,
      eligible_start = 5L,
      scale_floor = 1e-6,
      seed_base = 202607130L,
      seed_increment = 100L
    ),
    bootstrap = list(
      B = 5000L,
      seed = 202607131L,
      rng_kind = c("Mersenne-Twister", "Inversion", "Rejection")
    ),
    rsto = list(
      nu = 5,
      kappa = 1e4,
      H_init_floor = 1e-12,
      c_omega = 10,
      q_lower = 1e-8,
      q_upper = 10,
      log_H_window = 8,
      optimizer_outer_cycles = 1L,
      optimizer_optimize_tol = 1e-2,
      optimizer_incumbent_tolerance = sqrt(.Machine$double.eps),
      optimizer_boundary_tol = 1e-7,
      optimizer_max_eval = 5000L
    ),
    run_id = "RSTO_PUBLICATION_CODE_V1_20260730",
    output_schema = list(
      contamination_manifest = c(
        "run_id", "series_id", "series_index", "seed", "condition",
        "contamination_family", "position", "n_train", "eligible_start",
        "eligible_end", "n_selected_positions", "training_reference_scale",
        "original_value", "contaminated_value", "sign", "c_out", "position_set_id"
      ),
      forecast = c(
        "run_id", "chunk_id", "series_id", "series_index", "period",
        "frequency", "n_train", "horizon", "horizon_index", "condition",
        "method_id", "actual", "forecast", "error", "absolute_error",
        "squared_error", "smape_denominator", "smape_contribution",
        "method_success", "fallback_used", "fallback_type", "pipeline_output_available"
      ),
      metrics = c(
        "run_id", "chunk_id", "series_id", "series_index", "period",
        "frequency", "n_train", "horizon", "condition", "method_id", "MASE",
        "RMSSE", "sMAPE", "MASE_denominator", "RMSSE_denominator",
        "scale_failure", "metric_status", "smape_zero_denominator",
        "method_success", "fallback_used", "fallback_type", "pipeline_output_available",
        "warning_observed", "warning_count", "warning_class", "warning_message",
        "error_class", "error_message", "optimizer_status", "q_fit",
        "q_endpoint_status", "adapter_metadata_exposure", "runtime_seconds"
      )
    )
  )
}

rsto_archive_path <- function() {
  path <- Sys.getenv("RSTO_CORE_ARCHIVE", unset = "")
  if (!nzchar(path)) {
    stop("RSTO_CORE_ARCHIVE must name RST_O_PROJECT_ARCHIVE_CORE_COMPLETE_20260720.zip.", call. = FALSE)
  }
  if (!file.exists(path)) stop(sprintf("RSTO_CORE_ARCHIVE does not exist: %s", path), call. = FALSE)
  path
}

rsto_package_root <- function(start = getwd()) {
  configured <- Sys.getenv("RSTO_PUBLICATION_ROOT", unset = "")
  if (nzchar(configured) && file.exists(file.path(configured, "run_all.R"))) {
    return(configured)
  }
  if (file.exists(file.path(start, "run_all.R")) &&
      file.exists(file.path(start, "config", "config.R"))) return(start)
  current <- start
  repeat {
    if (file.exists(file.path(current, "run_all.R")) &&
        file.exists(file.path(current, "config", "config.R"))) {
      return(current)
    }
    parent <- dirname(current)
    if (identical(parent, current)) break
    current <- parent
  }
  stop("Cannot locate the RSTO publication-code root.", call. = FALSE)
}

rsto_output_dir <- function(root = rsto_package_root(), mode) {
  file.path(root, "results", mode)
}

rsto_expected_runtime <- function() {
  rsto_publication_config()$frozen_runtime_sha256
}
