#!/usr/bin/env Rscript
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script <- if (length(script_arg)) sub("^--file=", "", script_arg[[1L]]) else file.path("scripts", "audit_abc_pilot.R")
root <- normalizePath(file.path(dirname(script), ".."), winslash = "/", mustWork = TRUE)
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
source(file.path(root, "R", "abc_orchestration.R"), local = .GlobalEnv)
cfg <- abc_read_config(file.path(root, "config", "abc_config.yml")); abc_set_rng(cfg); abc_source_kernels(root)
for (file in c("R/abc_module_a.R", "R/abc_module_b.R", "R/abc_module_c.R")) source(file.path(root, file), local = .GlobalEnv)

base <- abc_output_dir(cfg, "pilot", root = root)
read_result <- function(module, file) utils::read.csv(file.path(base, cfg$outputs[[paste0("module_", tolower(module))]], file), stringsAsFactors = FALSE, check.names = FALSE)
audit <- list(); add_check <- function(check, condition, detail) {
  audit[[length(audit) + 1L]] <<- data.frame(check = check, status = if (isTRUE(condition)) "PASS" else "FAIL", detail = as.character(detail), stringsAsFactors = FALSE)
}

a <- read_result("A", "MODULE_A_RESULTS.csv"); a_manifest <- read_result("A", "MODULE_A_CONTAMINATION_MANIFEST.csv"); a_sample <- read_result("A", "stratified_series_sample.csv")
a_numeric <- unlist(a[c("MASE", "RMSSE", "sMAPE", "degradation_MASE", "degradation_RMSSE", "degradation_sMAPE")], use.names = FALSE)
forecast_count <- vapply(strsplit(a$forecast_values, ";", fixed = TRUE), length, integer(1L))
actual_count <- vapply(strsplit(a$actual_values, ";", fixed = TRUE), length, integer(1L))
add_check("module_a_components", all(c("CLEAN_REFERENCE", "A1_DRAW1", "A2_POSITION_DRAWS") %in% a$study_component), paste(sort(unique(a$study_component)), collapse = ";"))
add_check("module_a_numeric_finite", all(is.finite(a_numeric)), paste("rows", nrow(a)))
add_check("module_a_forecast_loss_schema", all(forecast_count == a$horizon & actual_count == a$horizon), "actual and forecast vectors match the frozen horizon")
add_check("module_a_sample", nrow(a_sample) == cfg$module_a$sample_size && all(table(a_sample$stratum) >= cfg$module_a$minimum_per_nonempty_stratum), paste("rows", nrow(a_sample), "minimum stratum", min(table(a_sample$stratum))))
positions_by_draw <- aggregate(position_set_id ~ series_index + draw_id, a_manifest, function(value) length(unique(value)))
add_check("module_a_paired_positions", all(positions_by_draw$position_set_id == 1L), "sign and amplitude conditions reuse the paired position set")

b <- read_result("B", "MODULE_B_CONTRAST_RESULTS.csv"); b_trace <- read_result("B", "MODULE_B_UPDATE_TRACE.csv")
b_expected <- length(cfg$module_b$pilot_seeds) * length(cfg$module_b$pilot_cell_rows) * length(cfg$module_b$pilot_profile_ids) * length(cfg$reporting$metrics) * length(cfg$module_b$contrasts)
trace_y <- aggregate(y ~ seed + cell_id + profile_id + t, b_trace, function(value) length(unique(value)))
add_check("module_b_rows", nrow(b) == b_expected, paste("rows", nrow(b)))
add_check("module_b_numeric_finite", all(is.finite(b$first_minus_second)), paste("paths", length(unique(b$path_id))))
add_check("module_b_six_arm_trace", setequal(unique(b_trace$arm), cfg$module_b$methods) && all(trace_y$y == 1L) && all(b_trace$huber_lambda >= 0 & b_trace$huber_lambda <= 1), "six arms share each generated path; Huber lambda is bounded")

c_result <- read_result("C", "MODULE_C_SENSITIVITY_RESULTS.csv"); c_selection <- read_result("C", "sensitivity_cell_selection.csv")
c_expected <- length(cfg$module_c$pilot_seeds) * length(cfg$module_c$pilot_profiles) * length(cfg$module_c$pilot_grid) * length(cfg$reporting$metrics) * length(cfg$module_c$contrasts)
add_check("module_c_rows", nrow(c_result) == c_expected, paste("rows", nrow(c_result)))
add_check("module_c_numeric_finite", all(is.finite(c_result$first_minus_second)), paste("paths", length(unique(c_result$path_id))))
add_check("module_c_design_constraints", abc_c_constraints(c_selection), "12 cells; binary factors 6/6; p_out and c at least 3; full rank")
add_check("module_c_global_maximin", all(c_selection$maximin_global_optimum_verified) && unique(c_selection$strictly_better_graph_coloring_size) == 11L, paste("minimum distance", unique(c_selection$factor_space_min_distance)))

formal_authorized <- tryCatch({ abc_require_phase("formal", cfg); TRUE }, error = function(error) FALSE)
add_check("formal_authorization", formal_authorized && !dir.exists(abc_output_dir(cfg, "formal", root = root)), "user authorization active; formal output directory absent before Cloud execution")

audit <- do.call(rbind, audit)
abc_write_csv(audit, file.path(base, "ABC_PILOT_NUMERIC_AUDIT.csv"))
if (any(audit$status != "PASS")) stop("ABC pilot numeric audit failed.", call. = FALSE)
cat(sprintf("ABC pilot numeric audit: PASS (%d/%d checks)\n", sum(audit$status == "PASS"), nrow(audit)))
