#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly = TRUE)
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", script_arg[[1L]])), ".."), winslash = "/")
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
source(file.path(root, "R", "abc_orchestration.R")); cfg <- abc_read_config(file.path(root, "config", "abc_config.yml")); abc_set_rng(cfg); abc_source_kernels(root)
source(file.path(root, "R", "abc_module_a.R")); source(file.path(root, "R", "abc_module_a_sharded.R"))
value <- function(flag, default = NULL) { i <- match(flag, args); if (is.na(i)) default else args[[i + 1L]] }
command <- value("--command"); asset_dir <- value("--asset-dir", file.path(root, "module_a_sharded_assets"))
if (command == "build") {
  manifest <- abc_a_build_manifest(cfg); profile <- utils::read.csv(file.path(asset_dir, "runtime_profiling_group_summary.csv"), stringsAsFactors = FALSE)
  manifest <- abc_a_add_shards(manifest, profile)
  abc_write_csv(manifest, file.path(asset_dir, "module_A_evaluation_manifest.csv"))
  abc_write_csv(manifest[, c("task_id", "shard_id", "estimated_runtime_weight")], file.path(asset_dir, "module_A_shard_map.csv"))
} else if (command == "run-shard") {
  manifest <- utils::read.csv(file.path(asset_dir, "module_A_evaluation_manifest.csv"), stringsAsFactors = FALSE, colClasses = c(shard_id = "character"))
  abc_a_run_shard(manifest, value("--shard-id"), cfg, file.path(asset_dir, "results", "module_A", "shards"))
} else if (command == "aggregate") {
  manifest <- utils::read.csv(file.path(asset_dir, "module_A_evaluation_manifest.csv"), stringsAsFactors = FALSE, colClasses = c(shard_id = "character"))
  abc_a_aggregate_shards(manifest, file.path(asset_dir, "results", "module_A", "shards"), file.path(asset_dir, "results", "module_A", "MODULE_A_RESULTS.csv"))
} else stop("Use --command build|run-shard|aggregate", call. = FALSE)
