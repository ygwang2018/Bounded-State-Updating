#!/usr/bin/env Rscript
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", script_arg[[1L]])), ".."), winslash = "/")
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
source(file.path(root, "R", "abc_orchestration.R")); cfg <- abc_read_config(file.path(root, "config", "abc_config.yml")); abc_set_rng(cfg); abc_source_kernels(root)
source(file.path(root, "R", "abc_module_a.R")); source(file.path(root, "R", "abc_module_a_sharded.R"))
args <- commandArgs(trailingOnly = TRUE); i <- match("--output-dir", args)
output_dir <- if (is.na(i)) file.path(root, "module_a_sharded_assets") else args[[i + 1L]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
m3 <- publication_load_m3(); strata <- abc_a_strata(m3); strata$frequency_group <- abc_a_frequency_label(strata$frequency)
selected <- unlist(lapply(c("Yearly", "Quarterly", "Monthly", "Other"), function(group) head(strata$series_index[strata$frequency_group == group], 5L)))
methods <- names(publication_method_panel())
conditions <- data.frame(profile_condition = c("P0", "P1", "P2", "P3"), stage = c("clean", "A1", "A1", "A2"),
  draw_id = c(0L, 1L, 1L, 1L), amplitude = c(0, 2, 6, 4), sign = c(0L, 1L, -1L, 1L), stringsAsFactors = FALSE)
plan <- merge(expand.grid(series_index = selected, method = methods, KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE), conditions, by = NULL)
rows <- vector("list", nrow(plan))
for (j in seq_len(nrow(plan))) {
  p <- plan[j, ]; item <- m3[[p$series_index]]; series_id <- names(m3)[[p$series_index]]
  task <- data.frame(task_id = sprintf("PROFILE%03d", j), stage = p$stage, series_id = series_id,
    series_index = p$series_index, method = p$method, amplitude = p$amplitude, sign = p$sign, draw_id = p$draw_id,
    scientific_seed = if (p$stage == "clean") NA_integer_ else abc_a_seed(p$series_index, p$draw_id, cfg),
    contamination_position = if (p$stage == "clean") NA_character_ else paste(abc_a_positions(length(item$x), p$series_index, p$draw_id, cfg), collapse = ";"),
    expected_output_identity = paste("profile", j, sep = "::"), stringsAsFactors = FALSE)
  timing <- system.time(result <- abc_a_run_task(task, cfg, m3))
  rows[[j]] <- data.frame(profile_condition = p$profile_condition, wall_time_sec = unname(timing[["elapsed"]]),
    CPU_time_sec = unname(timing[["user.self"]] + timing[["sys.self"]]), method = p$method,
    frequency = as.integer(stats::frequency(item$x)), frequency_group = abc_a_frequency_label(as.integer(stats::frequency(item$x))),
    stage = p$stage, series_id = series_id, condition_id = if (p$stage == "clean") "clean" else sprintf("%s:+%s", p$stage, p$amplitude * p$sign),
    fit_status = if (result$method_success) "SUCCESS" else "FAILURE",
    warning_status = if (result$warning_observed) "WARNING" else "NONE", optimizer_status = result$optimizer_status,
    stringsAsFactors = FALSE)
  if (j %% 10L == 0L) { abc_write_csv(do.call(rbind, rows[seq_len(j)]), file.path(output_dir, "runtime_profiling.partial.csv")); cat(j, "/", nrow(plan), "\n") }
}
profiling <- do.call(rbind, rows); abc_write_csv(profiling, file.path(output_dir, "runtime_profiling.csv"))
q90 <- function(x) unname(stats::quantile(x, 0.9, type = 7))
groups <- split(profiling, paste(profiling$method, profiling$frequency_group, sep = "::"))
summary <- do.call(rbind, lapply(groups, function(x) data.frame(method = x$method[[1L]], frequency_group = x$frequency_group[[1L]],
  n_profile_fits = nrow(x), median_wall_sec = stats::median(x$wall_time_sec), p90_wall_sec = q90(x$wall_time_sec),
  mean_wall_sec = mean(x$wall_time_sec), failure_count = sum(x$fit_status != "SUCCESS"), warning_count = sum(x$warning_status == "WARNING"))))
rownames(summary) <- NULL; abc_write_csv(summary, file.path(output_dir, "runtime_profiling_group_summary.csv"))
unlink(file.path(output_dir, "runtime_profiling.partial.csv"))
