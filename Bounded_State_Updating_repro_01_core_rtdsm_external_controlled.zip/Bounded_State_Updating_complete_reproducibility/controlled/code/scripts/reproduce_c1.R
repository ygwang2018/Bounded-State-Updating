#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly = TRUE)
value <- function(flag, default) { i <- match(flag, args); if (is.na(i)) default else args[[i + 1L]] }
root <- normalizePath(file.path(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1L])), ".."))
source(file.path(root, "R", "c1_simulation.R"))
source(file.path(root, "R", "c1_publication.R"))
n <- as.integer(value("--n", "16538")); output <- value("--output-dir", file.path(root, "results", "c1"))
dir.create(output, recursive = TRUE, showWarnings = FALSE)
result <- run_c1(n, file.path(root, "config", "c1_config.yml"))
utils::write.csv(result$cell_results, file.path(output, "C1_UNBLINDED_CELL_LEVEL_RESULTS.csv"), row.names = FALSE, na = "NA", quote = TRUE)
utils::write.csv(result$family_summaries, file.path(output, "C1_UNBLINDED_FAMILY_DESCRIPTIVE_SUMMARIES_CORRECTED.csv"), row.names = FALSE, na = "NA", quote = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output, "sessionInfo.txt"))
