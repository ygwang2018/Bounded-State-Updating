#!/usr/bin/env Rscript
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
root <- normalizePath(file.path(dirname(sub("^--file=", "", script_arg[[1L]])), ".."), winslash = "/")
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
source(file.path(root, "R", "abc_orchestration.R")); cfg <- abc_read_config(file.path(root, "config", "abc_config.yml")); abc_set_rng(cfg); abc_source_kernels(root)
source(file.path(root, "R", "abc_module_a.R")); source(file.path(root, "R", "abc_module_a_sharded.R"))
args <- commandArgs(trailingOnly = TRUE); i <- match("--output-dir", args)
output_dir <- if (is.na(i)) file.path(root, "module_a_sharded_assets", "tiny_equivalence_pilot") else args[[i + 1L]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
m3 <- publication_load_m3(); methods <- publication_method_panel(); series_index <- abc_a_select_series(m3, cfg)$series_index[[1L]]; item <- m3[[series_index]]; series_id <- names(m3)[[series_index]]
clean <- abc_a_clean_reference(item, series_id, series_index, methods)
old_parts <- list(clean)
for (condition in list(c("A1_DRAW1", 1, 2, 1), c("A1_DRAW1", 1, 6, -1), c("A2_POSITION_DRAWS", 1, 4, 1))) {
  old_parts[[length(old_parts) + 1L]] <- abc_a_output_row(item, series_id, series_index, condition[[1]], as.integer(condition[[2]]),
    as.numeric(condition[[3]]), as.integer(condition[[4]]), methods, cfg, clean)$results
}
old <- do.call(rbind, old_parts)
manifest <- abc_a_build_manifest(cfg, m3)
take <- manifest$series_index == series_index & (manifest$stage == "clean" |
  (manifest$stage == "A1" & manifest$draw_id == 1 & ((manifest$amplitude == 2 & manifest$sign == 1) | (manifest$amplitude == 6 & manifest$sign == -1))) |
  (manifest$stage == "A2" & manifest$draw_id == 1 & manifest$amplitude == 4 & manifest$sign == 1))
tiny <- manifest[take, , drop = FALSE]
new <- do.call(rbind, lapply(seq_len(nrow(tiny)), function(j) abc_a_run_task(tiny[j, , drop = FALSE], cfg, m3)))
clean_new <- new[new$study_component == "CLEAN_REFERENCE", ]
for (metric in c("MASE", "RMSSE", "sMAPE")) {
  ref <- clean_new[[metric]][match(new$method_id, clean_new$method_id)]
  new[[paste0("clean_", metric)]] <- ref; new[[paste0("degradation_", metric)]] <- new[[metric]] - ref
}
keys <- c("study_component", "series_index", "draw_id", "amplitude", "sign", "method_id")
old <- old[do.call(order, old[keys]), ]; new <- new[do.call(order, new[keys]), ]
compare_columns <- intersect(names(old), names(new)); compare_columns <- setdiff(compare_columns, c("task_id", "expected_output_identity"))
comparison <- data.frame(column = compare_columns, identical = vapply(compare_columns, function(column) {
  isTRUE(all.equal(old[[column]], new[[column]], tolerance = 0, check.attributes = FALSE))
}, logical(1L)), stringsAsFactors = FALSE)
identity <- data.frame(task_id = new$task_id, expected_output_identity = new$expected_output_identity,
  contamination_positions_old = old$contamination_positions, contamination_positions_new = new$contamination_positions,
  seed_old = old$seed, seed_new = new$seed, forecast_old = old$forecast_values, forecast_new = new$forecast_values,
  method_success_old = old$method_success, method_success_new = new$method_success, stringsAsFactors = FALSE)
abc_write_csv(old, file.path(output_dir, "old_serial_results.csv")); abc_write_csv(new, file.path(output_dir, "new_sharded_results.csv"))
abc_write_csv(identity, file.path(output_dir, "scientific_identity_comparison.csv")); abc_write_csv(comparison, file.path(output_dir, "column_equivalence.csv"))
abc_assert(all(comparison$identical), paste("Orchestration equivalence mismatch:", paste(comparison$column[!comparison$identical], collapse = ", ")))
writeLines(c("ORCHESTRATION_EQUIVALENCE_PILOT=PASS", paste0("TASKS_COMPARED=", nrow(new)),
  "TOLERANCE=0", "FORMAL_MODULE_A_RESTARTED=NO"), file.path(output_dir, "STATUS.txt"))
cat("ORCHESTRATION_EQUIVALENCE_PILOT=PASS\n")
