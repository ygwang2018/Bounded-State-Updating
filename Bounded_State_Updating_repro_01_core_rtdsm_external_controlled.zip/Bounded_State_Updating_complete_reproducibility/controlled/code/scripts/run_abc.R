#!/usr/bin/env Rscript
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script <- if (length(script_arg)) sub("^--file=", "", script_arg[[1L]]) else file.path("scripts", "run_abc.R")
root <- normalizePath(file.path(dirname(script), ".."), winslash = "/", mustWork = TRUE)
Sys.setenv(RSTO_PUBLICATION_ROOT = root)
source(file.path(root, "R", "abc_orchestration.R"), local = .GlobalEnv)
cfg <- abc_read_config(file.path(root, "config", "abc_config.yml")); abc_set_rng(cfg); abc_source_kernels(root)
for (file in c("R/abc_module_a.R", "R/abc_module_b.R", "R/abc_module_c.R")) source(file.path(root, file), local = .GlobalEnv)
args <- abc_parse_cli(); abc_require_phase(args$phase, cfg)
if (isTRUE(args$verify)) {
  print(abc_verify_assets(cfg, root))
} else if (isTRUE(args$summarize)) {
  print(abc_summarize(cfg, args$phase, root, args$output_dir))
} else {
  abc_run_module(args$module, args$phase, cfg, root, args$output_dir)
  message("Completed ABC ", args$phase, " Module ", args$module, ".")
}
