# Bounded State Updating publication code

This is the compact Linux-compatible scientific implementation used to reproduce the paper's frozen C1 simulation and M3 experiment. RST-O is evaluated narrowly for random, isolated observation contamination in the training sample; the evidence does not establish universal robustness, robustness to state-level shocks, or real-data superiority.

## Environment

Use R 4.3.3 and the direct-package versions recorded in `renv.lock`. Install or restore those dependencies in the R 4.3.3 environment before running the scripts below. No setup-shell wrapper is bundled in this public archive.

C1 execution has no external scientific-code dependency. The historical M3 differential runner in this directory refers to a separate legacy execution archive and is retained for provenance; use the package-level portable M3 runners documented in the root README for public reproduction.

## Commands

Run commands from this directory.

```bash
# Resource/smoke check for the controlled Module B path
Rscript scripts/run_abc.R --phase pilot --module B --output-dir results/pilot_B

# C1 full: fixed 36 cells, 11 profiles, and seeds 1:16538
Rscript scripts/reproduce_c1.R --n 16538 --output-dir results/c1

# Formal Module B reproduction used by the protection--adaptation analysis
Rscript scripts/run_abc.R --phase formal --module B --output-dir results/module_B
```

For a resource check only, pass a smaller `--n` to `reproduce_c1.R`; such output is not a formal C1 result.

## Scientific implementation

- `R/c1_simulation.R` is a focused extraction of the frozen authority's exact C1 path generation, five coded state updates, forecasts, losses, paired contrasts, and online aggregation.
- `R/c1_publication.R` maps coded results to publication method names and reconstructs the frozen cell and family descriptive tables.
- `R/model.R`, `R/experiments.R`, `R/evaluation.R`, and `R/io.R` implement the M3 publication pipeline.
- `config/c1_config.yml` fixes the C1 design, profiles, RNG, and estimands; `config/config.R` fixes M3.

C1 writes `C1_UNBLINDED_CELL_LEVEL_RESULTS.csv` and `C1_UNBLINDED_FAMILY_DESCRIPTIVE_SUMMARIES_CORRECTED.csv`. M3 writes a serial full-run result under `results/full/`. Runtime output, the private frozen oracle, and historical Windows recovery/orchestration are excluded from the release.

## Verification policy

Scientific equations, DGPs, seed mapping, metrics, oracle values, and comparator tolerances are immutable. Changes require deterministic equivalence plus frozen-oracle parity. The accepted negative DGP4-main RST-O-versus-IQR MASE result must remain visible rather than being generalized away.
