# RST-O publication code

This is the compact Linux-compatible scientific implementation used to reproduce the paper's frozen C1 simulation and M3 experiment. RST-O is evaluated narrowly for random, isolated observation contamination in the training sample; the evidence does not establish universal robustness, robustness to state-level shocks, or real-data superiority.

## Environment

Use R 4.3.3 and the exact direct-package versions in `renv.lock`. From a clean clone, the setup script installs `renv` when needed, restores the lock, and verifies the recorded direct-package versions:

```bash
./cloud_setup.sh
```

The external legacy archive is needed only for M3 differential verification/reproduction input. Set `RSTO_CORE_ARCHIVE` to `RST_O_PROJECT_ARCHIVE_CORE_COMPLETE_20260720.zip` (SHA-256 `716386a329663877db7a72ae699a47d6fda12caacf53b784f7273101776a20a4`). C1 execution has no external scientific-code dependency.

## Commands

Run commands from this directory.

```bash
# Fast deterministic C1 scientific-core check
Rscript tests/test_c1_equivalence.R

# Frozen M3 differential fixture test
RSTO_CORE_ARCHIVE=/path/to/RST_O_PROJECT_ARCHIVE_CORE_COMPLETE_20260720.zip \
  Rscript run_all.R --mode test

# C1 full: fixed 36 cells, 11 profiles, and seeds 1:16538
Rscript scripts/reproduce_c1.R --n 16538 --output-dir results/c1

# M3 full publication reproduction
RSTO_CORE_ARCHIVE=/path/to/RST_O_PROJECT_ARCHIVE_CORE_COMPLETE_20260720.zip \
  Rscript run_all.R --mode full
```

For a resource check only, pass a smaller `--n`; such output is not a formal C1 result. `run_all.R --mode reproduce` reconstructs paper data from already accepted canonical C1/M3 objects and does not rerun C1.

## Scientific implementation

- `R/c1_simulation.R` is a focused extraction of the frozen authority's exact C1 path generation, five coded state updates, forecasts, losses, paired contrasts, and online aggregation.
- `R/c1_publication.R` maps coded results to publication method names and reconstructs the frozen cell and family descriptive tables.
- `R/model.R`, `R/experiments.R`, `R/evaluation.R`, and `R/io.R` implement the M3 publication pipeline.
- `config/c1_config.yml` fixes the C1 design, profiles, RNG, and estimands; `config/config.R` fixes M3.

C1 writes `C1_UNBLINDED_CELL_LEVEL_RESULTS.csv` and `C1_UNBLINDED_FAMILY_DESCRIPTIVE_SUMMARIES_CORRECTED.csv`. M3 writes a serial full-run result under `results/full/`. Runtime output, the private frozen oracle, and historical Windows recovery/orchestration are excluded from the release.

## Verification policy

Scientific equations, DGPs, seed mapping, metrics, oracle values, and comparator tolerances are immutable. Changes require deterministic equivalence plus frozen-oracle parity. The accepted negative DGP4-main RST-O-versus-IQR MASE result must remain visible rather than being generalized away.

## License

This publication code is licensed under GPL-3.0-only. See `LICENSE`.
