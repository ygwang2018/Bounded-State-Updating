publication_metric_scales <- function(y_train, frequency) {
  y_train <- as.numeric(y_train)
  frequency <- as.integer(frequency)
  rsto_assert(length(y_train) >= 2L && all(is.finite(y_train)), "Metric scaling requires finite clean training data.")
  lag_value <- if (frequency > 1L) frequency else 1L
  rsto_assert(length(y_train) > lag_value, "Training length is too short for the frozen metric lag.")
  differences <- y_train[(lag_value + 1L):length(y_train)] - y_train[seq_len(length(y_train) - lag_value)]
  list(lag = lag_value, MASE_denominator = mean(abs(differences)), RMSSE_denominator = mean(differences^2))
}

publication_compute_metrics <- function(y_train, y_test, forecast, frequency) {
  y_test <- as.numeric(y_test)
  forecast <- as.numeric(forecast)
  rsto_assert(length(y_test) >= 1L && length(y_test) == length(forecast), "Forecast length must equal the official horizon.")
  rsto_assert(all(is.finite(y_test)) && all(is.finite(forecast)), "Test and forecast values must be finite.")
  scales <- publication_metric_scales(y_train, frequency)
  scale_failure <- !is.finite(scales$MASE_denominator) || !is.finite(scales$RMSSE_denominator) ||
    scales$MASE_denominator <= 0 || scales$RMSSE_denominator <= 0
  error <- y_test - forecast
  smape_denominator <- abs(y_test) + abs(forecast)
  smape_zero_denominator <- any(!is.finite(smape_denominator) | smape_denominator == 0)
  smape <- if (smape_zero_denominator) NA_real_ else mean(200 * abs(error) / smape_denominator)
  metric_status <- if (scale_failure) "SCALE_FAILURE" else if (smape_zero_denominator) "SMAPE_ZERO_DENOMINATOR" else "OK"
  list(
    MASE = if (scale_failure) NA_real_ else mean(abs(error)) / scales$MASE_denominator,
    RMSSE = if (scale_failure) NA_real_ else sqrt(mean(error^2) / scales$RMSSE_denominator),
    sMAPE = smape, MASE_denominator = scales$MASE_denominator,
    RMSSE_denominator = scales$RMSSE_denominator, scale_failure = scale_failure,
    metric_status = metric_status, smape_zero_denominator = smape_zero_denominator,
    smape_denominator = smape_denominator, error = error
  )
}

publication_metrics_to_long <- function(metrics) {
  required <- c("series_id", "series_index", "period", "frequency", "condition", "method_id", "MASE", "RMSSE", "sMAPE", "scale_failure", "smape_zero_denominator", "method_success")
  rsto_assert(all(required %in% names(metrics)), "Metrics do not expose the frozen schema.")
  do.call(rbind, lapply(c("MASE", "RMSSE", "sMAPE"), function(metric_name) {
    data.frame(
      series_id = metrics$series_id, series_index = as.integer(metrics$series_index),
      period = as.character(metrics$period), frequency = as.integer(metrics$frequency),
      condition = as.character(metrics$condition), method_id = as.character(metrics$method_id),
      metric = metric_name, value = as.numeric(metrics[[metric_name]]),
      scale_failure = as.logical(metrics$scale_failure),
      smape_zero_denominator = as.logical(metrics$smape_zero_denominator),
      method_success = as.logical(metrics$method_success), stringsAsFactors = FALSE
    )
  }))
}

publication_condition_family <- function(family) {
  switch(family,
    PRIMARY_AO = c("clean", "primary_AO_positive", "primary_AO_negative"),
    LAST_POINT = c("clean", "last_point_positive", "last_point_negative"),
    stop(sprintf("Unknown frozen contamination family: %s", family), call. = FALSE)
  )
}

publication_series_estimands <- function(metric_long, family, analysis_population) {
  conditions <- publication_condition_family(family)
  keys <- unique(metric_long[, c("series_id", "series_index", "period", "frequency", "method_id", "metric"), drop = FALSE])
  rows <- vector("list", nrow(keys))
  for (index in seq_len(nrow(keys))) {
    key <- keys[index, , drop = FALSE]
    piece <- metric_long[
      metric_long$series_index == key$series_index & metric_long$method_id == key$method_id & metric_long$metric == key$metric,
      , drop = FALSE
    ]
    matched <- lapply(conditions, function(condition) piece[piece$condition == condition, , drop = FALSE])
    has_one <- all(vapply(matched, nrow, integer(1L)) == 1L)
    values <- if (has_one) vapply(matched, function(row) as.numeric(row$value[[1L]]), numeric(1L)) else rep(NA_real_, length(conditions))
    success <- if (has_one) vapply(matched, function(row) isTRUE(row$method_success[[1L]]), logical(1L)) else rep(FALSE, length(conditions))
    scale_failure <- if (has_one) any(vapply(matched, function(row) isTRUE(row$scale_failure[[1L]]), logical(1L))) else TRUE
    smape_zero <- if (has_one) any(vapply(matched, function(row) isTRUE(row$smape_zero_denominator[[1L]]), logical(1L))) else FALSE
    pipeline_valid <- has_one && all(is.finite(values))
    success_valid <- pipeline_valid && all(success)
    valid <- if (identical(analysis_population, "PIPELINE_LEVEL")) pipeline_valid else success_valid
    rows[[index]] <- data.frame(
      key, family = family, analysis_population = analysis_population,
      clean_loss = values[[1L]], positive_loss = values[[2L]], negative_loss = values[[3L]],
      contaminated_mean_loss = mean(values[2:3]), degradation = mean(values[2:3]) - values[[1L]],
      valid = valid, pipeline_valid = pipeline_valid, all_required_method_success = all(success),
      scale_failure = scale_failure, smape_zero_denominator = smape_zero, stringsAsFactors = FALSE
    )
  }
  do.call(rbind, rows)
}

publication_build_estimand_panel <- function(metrics) {
  long <- publication_metrics_to_long(metrics)
  do.call(rbind, unlist(lapply(c("PRIMARY_AO", "LAST_POINT"), function(family) {
    lapply(c("PIPELINE_LEVEL", "METHOD_SUCCESS_ONLY"), function(population) {
      publication_series_estimands(long, family, population)
    })
  }), recursive = FALSE))
}

publication_pair_method_id <- function(label) {
  switch(label,
    STG = "STG", IQR_ST = "IQR_ST",
    RSTO_NU5 = "RSTO_NU5_FROZEN_HISTORICAL_FLOW",
    ROBETS = "ROBETS_CREVITS_CROUX_VERSION_1_4",
    stop(sprintf("Unknown frozen pairwise label: %s", label), call. = FALSE)
  )
}

publication_pairwise_degradation_contrasts <- function(estimands, pairs, family = "PRIMARY_AO") {
  source <- estimands[estimands$family == family, , drop = FALSE]
  rows <- list()
  for (pair in pairs) {
    parts <- strsplit(pair, "_vs_", fixed = TRUE)[[1L]]
    rsto_assert(length(parts) == 2L, sprintf("Invalid frozen pairwise contrast: %s", pair))
    method_a <- publication_pair_method_id(parts[[1L]])
    method_b <- publication_pair_method_id(parts[[2L]])
    a <- source[source$method_id == method_a, , drop = FALSE]
    b <- source[source$method_id == method_b, , drop = FALSE]
    joined <- merge(a, b, by = c("series_id", "series_index", "period", "frequency", "metric", "family", "analysis_population"), suffixes = c("_a", "_b"), all = FALSE)
    rows[[length(rows) + 1L]] <- data.frame(
      series_id = joined$series_id, series_index = joined$series_index,
      period = joined$period, frequency = joined$frequency, metric = joined$metric,
      family = joined$family, analysis_population = joined$analysis_population,
      contrast_id = pair, method_a = method_a, method_b = method_b,
      contrast = ifelse(joined$valid_a & joined$valid_b, joined$degradation_a - joined$degradation_b, NA_real_),
      valid = joined$valid_a & joined$valid_b, stringsAsFactors = FALSE
    )
  }
  do.call(rbind, rows)
}

publication_group_subset <- function(data, group) {
  if (identical(group, "OVERALL")) data else data[data$period == group, , drop = FALSE]
}

publication_mean_or_na <- function(values) {
  values <- values[is.finite(values)]
  if (!length(values)) NA_real_ else mean(values)
}

publication_summarize_estimands <- function(estimands, family) {
  source <- estimands[estimands$family == family, , drop = FALSE]
  groups <- c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")
  rows <- list()
  for (group in groups) {
    group_data <- publication_group_subset(source, group)
    for (population in unique(group_data$analysis_population)) {
      for (metric in unique(group_data$metric)) {
        for (method in unique(group_data$method_id)) {
          piece <- group_data[group_data$analysis_population == population & group_data$metric == metric & group_data$method_id == method, , drop = FALSE]
          valid <- piece[piece$valid, , drop = FALSE]
          rows[[length(rows) + 1L]] <- data.frame(
            group = group, family = family, analysis_population = population, metric = metric, method_id = method,
            clean_loss = publication_mean_or_na(valid$clean_loss), positive_loss = publication_mean_or_na(valid$positive_loss),
            negative_loss = publication_mean_or_na(valid$negative_loss),
            contaminated_mean_loss = publication_mean_or_na(valid$contaminated_mean_loss),
            aggregate_degradation = publication_mean_or_na(valid$degradation), recovery_ratio = NA_real_,
            recovery_ratio_defined = FALSE, n_total_series = nrow(piece), n_valid_series = nrow(valid),
            n_scale_failure = sum(piece$scale_failure, na.rm = TRUE),
            n_smape_zero_denominator = sum(piece$smape_zero_denominator, na.rm = TRUE), stringsAsFactors = FALSE
          )
        }
      }
    }
  }
  out <- do.call(rbind, rows)
  for (group in unique(out$group)) for (population in unique(out$analysis_population)) for (metric in unique(out$metric)) {
    where <- out$group == group & out$analysis_population == population & out$metric == metric
    stg <- out$aggregate_degradation[where & out$method_id == "STG"]
    if (length(stg) == 1L && is.finite(stg) && stg > 0) {
      out$recovery_ratio[where] <- 1 - out$aggregate_degradation[where] / stg
      out$recovery_ratio_defined[where] <- is.finite(out$aggregate_degradation[where])
    }
  }
  out
}

publication_summarize_pairwise <- function(contrasts) {
  groups <- c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")
  rows <- list()
  for (group in groups) {
    group_data <- publication_group_subset(contrasts, group)
    keys <- unique(group_data[, c("metric", "family", "analysis_population", "contrast_id", "method_a", "method_b"), drop = FALSE])
    for (index in seq_len(nrow(keys))) {
      key <- keys[index, , drop = FALSE]
      piece <- group_data[group_data$metric == key$metric & group_data$family == key$family &
                            group_data$analysis_population == key$analysis_population &
                            group_data$contrast_id == key$contrast_id, , drop = FALSE]
      valid <- piece$contrast[is.finite(piece$contrast)]
      rows[[length(rows) + 1L]] <- data.frame(
        group = group, metric = key$metric, family = key$family,
        analysis_population = key$analysis_population, contrast_id = key$contrast_id,
        method_a = key$method_a, method_b = key$method_b,
        aggregate_contrast = publication_mean_or_na(valid), n_total_series = nrow(piece),
        n_valid_series = length(valid), strict_win_rate = if (length(valid)) mean(valid < 0) else NA_real_,
        tie_rate = if (length(valid)) mean(valid == 0) else NA_real_,
        strict_loss_rate = if (length(valid)) mean(valid > 0) else NA_real_, stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

publication_clean_performance_boundary <- function(metrics) {
  long <- publication_metrics_to_long(metrics)
  clean <- long[long$condition == "clean", , drop = FALSE]
  groups <- c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")
  rows <- list()
  for (group in groups) {
    group_data <- publication_group_subset(clean, group)
    for (population in c("PIPELINE_LEVEL", "METHOD_SUCCESS_ONLY")) for (metric in unique(group_data$metric)) for (method in unique(group_data$method_id)) {
      piece <- group_data[group_data$metric == metric & group_data$method_id == method, , drop = FALSE]
      eligible <- if (identical(population, "PIPELINE_LEVEL")) piece else piece[piece$method_success, , drop = FALSE]
      valid <- eligible$value[is.finite(eligible$value)]
      rows[[length(rows) + 1L]] <- data.frame(
        group = group, analysis_population = population, metric = metric, method_id = method,
        clean_loss = publication_mean_or_na(valid), n_total_series = nrow(piece), n_valid_series = length(valid), stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

publication_failure_fallback_summary <- function(metrics) {
  groups <- c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")
  rows <- list()
  for (group in groups) {
    group_data <- publication_group_subset(metrics, group)
    for (condition in unique(group_data$condition)) for (method in unique(group_data$method_id)) {
      piece <- group_data[group_data$condition == condition & group_data$method_id == method, , drop = FALSE]
      rows[[length(rows) + 1L]] <- data.frame(
        group = group, condition = condition, method_id = method, n_calls = nrow(piece),
        failure_rate = mean(!piece$method_success), fallback_rate = mean(piece$fallback_used), stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

publication_runtime_summary <- function(runtime_log) {
  groups <- c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")
  rows <- list()
  for (group in groups) {
    group_data <- publication_group_subset(runtime_log, group)
    for (method in unique(group_data$method_id)) {
      piece <- group_data[group_data$method_id == method, , drop = FALSE]
      rows[[length(rows) + 1L]] <- data.frame(
        group = group, method_id = method, n_calls = nrow(piece),
        mean_runtime_seconds = publication_mean_or_na(piece$runtime_seconds),
        total_runtime_seconds = sum(piece$runtime_seconds, na.rm = TRUE), stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

publication_q_endpoint_summary <- function(q_log) {
  keys <- unique(q_log[, c("method_id", "q_endpoint_status", "adapter_metadata_exposure", "optimizer_status"), drop = FALSE])
  do.call(rbind, lapply(seq_len(nrow(keys)), function(index) {
    key <- keys[index, , drop = FALSE]
    piece <- q_log[q_log$method_id == key$method_id & q_log$q_endpoint_status == key$q_endpoint_status &
                     q_log$adapter_metadata_exposure == key$adapter_metadata_exposure & q_log$optimizer_status == key$optimizer_status, , drop = FALSE]
    data.frame(method_id = key$method_id, q_endpoint_status = key$q_endpoint_status,
               adapter_metadata_exposure = key$adapter_metadata_exposure, optimizer_status = key$optimizer_status,
               n_calls = nrow(piece), n_finite_q_fit = sum(is.finite(piece$q_fit)), stringsAsFactors = FALSE)
  }))
}

publication_bootstrap_groups <- function() c("OVERALL", "YEARLY", "QUARTERLY", "MONTHLY", "OTHER")

publication_bootstrap_draw_matrix_internal <- function(series_count, B, seed) {
  rsto_assert(series_count >= 1L && B >= 1L, "Bootstrap dimensions must be positive.")
  previous_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(previous_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(as.integer(seed))
  matrix(
    sample.int(as.integer(series_count), size = as.integer(B) * as.integer(series_count), replace = TRUE),
    nrow = as.integer(B), ncol = as.integer(series_count)
  )
}

publication_bootstrap_draw_matrix <- function(series_count, B = 5000L, seed = 202607131L) {
  rsto_assert(identical(as.integer(series_count), 3003L), "Formal paired bootstrap requires all 3003 M3 series.")
  rsto_assert(identical(as.integer(B), 5000L) && identical(as.integer(seed), 202607131L), "Bootstrap parameters differ from the frozen protocol.")
  publication_bootstrap_draw_matrix_internal(series_count, B, seed)
}

publication_sha256_object <- function(object) {
  rsto_require_namespace("digest")
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

publication_bootstrap_group_draw <- function(group_indices, B, seed, formal = FALSE) {
  group_indices <- as.integer(sort(unique(group_indices)))
  rsto_assert(length(group_indices) >= 1L && all(group_indices >= 1L), "Bootstrap group universe is invalid.")
  draw_matrix <- if (isTRUE(formal) && identical(group_indices, seq_len(3003L))) {
    publication_bootstrap_draw_matrix(3003L, B, seed)
  } else {
    publication_bootstrap_draw_matrix_internal(length(group_indices), B, seed)
  }
  list(
    group_indices = group_indices, draw_matrix = draw_matrix,
    draw_matrix_sha256 = publication_sha256_object(draw_matrix),
    group_draw_matrix_sha256 = publication_sha256_object(list(group_indices = group_indices, draw_matrix = draw_matrix))
  )
}

publication_percentile_interval <- function(values) {
  values <- values[is.finite(values)]
  if (!length(values)) return(c(lower = NA_real_, upper = NA_real_))
  stats::quantile(values, probs = c(0.025, 0.975), names = FALSE, type = 7)
}

publication_bootstrap_mean <- function(series_values, draw_matrix) {
  rsto_assert(is.numeric(series_values) && length(series_values) == ncol(draw_matrix), "Bootstrap values do not align to the group universe.")
  vapply(seq_len(nrow(draw_matrix)), function(index) publication_mean_or_na(series_values[draw_matrix[index, ]]), numeric(1L))
}

publication_bootstrap_group_series_vector <- function(data, value_column, group_indices) {
  rsto_assert(!anyDuplicated(data$series_index), "Bootstrap input has duplicate series estimands.")
  observed <- sort(as.integer(data$series_index))
  rsto_assert(identical(observed, as.integer(group_indices)), "Bootstrap input does not cover its exact group universe.")
  ordered <- data[match(as.integer(group_indices), as.integer(data$series_index)), , drop = FALSE]
  values <- as.numeric(ordered[[value_column]])
  values[!as.logical(ordered$valid)] <- NA_real_
  values
}

publication_bootstrap_row <- function(group, metric, analysis_population, estimand_type, method_id,
                                      contrast_id, point_estimate, values, draw, seed,
                                      recovery_na_rate = NA_real_) {
  replicates <- publication_bootstrap_mean(values, draw$draw_matrix)
  interval <- publication_percentile_interval(replicates)
  data.frame(
    group = group, family = "PRIMARY_AO", analysis_population = analysis_population,
    metric = metric, estimand_type = estimand_type, method_id = method_id,
    contrast_id = contrast_id, point_estimate = point_estimate, ci_lower = interval[[1L]],
    ci_upper = interval[[2L]], n_total_series = length(draw$group_indices),
    n_valid_series = sum(is.finite(values)), bootstrap_B = nrow(draw$draw_matrix),
    bootstrap_seed = as.integer(seed), rng_kind = "Mersenne-Twister/Inversion/Rejection",
    draw_matrix_sha256 = draw$draw_matrix_sha256,
    group_draw_matrix_sha256 = draw$group_draw_matrix_sha256,
    recovery_ratio_na_replicate_rate = recovery_na_rate, stringsAsFactors = FALSE
  )
}

publication_bootstrap_recovery_ratio <- function(method_values, stg_values, draw_matrix) {
  rsto_assert(length(method_values) == ncol(draw_matrix) && length(stg_values) == ncol(draw_matrix), "Recovery vectors do not align to the paired draw matrix.")
  vapply(seq_len(nrow(draw_matrix)), function(index) {
    draw <- draw_matrix[index, ]
    denominator <- publication_mean_or_na(stg_values[draw])
    numerator <- publication_mean_or_na(method_values[draw])
    if (!is.finite(denominator) || denominator <= 0 || !is.finite(numerator)) NA_real_ else 1 - numerator / denominator
  }, numeric(1L))
}

publication_bootstrap_primary_ci_core <- function(estimands, contrasts, B, seed, formal = FALSE) {
  source <- estimands[estimands$family == "PRIMARY_AO", , drop = FALSE]
  rsto_assert(nrow(source) > 0L, "Primary bootstrap source is empty.")
  populations <- c("PIPELINE_LEVEL", "METHOD_SUCCESS_ONLY")
  metrics <- c("MASE", "RMSSE", "sMAPE")
  methods <- c("STG", "IQR_ST", "RSTO_NU5_FROZEN_HISTORICAL_FLOW", "ROBETS_CREVITS_CROUX_VERSION_1_4")
  rows <- list()
  for (group in publication_bootstrap_groups()) {
    group_data <- publication_group_subset(source, group)
    group_indices <- sort(unique(as.integer(group_data$series_index)))
    rsto_assert(length(group_indices) > 0L, sprintf("Bootstrap group %s is empty.", group))
    draw <- publication_bootstrap_group_draw(group_indices, as.integer(B), as.integer(seed), formal = isTRUE(formal) && identical(group, "OVERALL"))
    for (population in populations) for (metric in metrics) {
      metric_data <- group_data[group_data$analysis_population == population & group_data$metric == metric, , drop = FALSE]
      rsto_assert(identical(sort(unique(metric_data$method_id)), sort(methods)), sprintf("Bootstrap method panel differs in group %s.", group))
      for (method in methods) {
        piece <- metric_data[metric_data$method_id == method, , drop = FALSE]
        values <- publication_bootstrap_group_series_vector(piece, "degradation", group_indices)
        rows[[length(rows) + 1L]] <- publication_bootstrap_row(
          group, metric, population, "aggregate_degradation", method, NA_character_,
          publication_mean_or_na(values), values, draw, seed
        )
      }
      stg_values <- publication_bootstrap_group_series_vector(metric_data[metric_data$method_id == "STG", , drop = FALSE], "degradation", group_indices)
      for (method in methods) {
        values <- publication_bootstrap_group_series_vector(metric_data[metric_data$method_id == method, , drop = FALSE], "degradation", group_indices)
        recovery <- publication_bootstrap_recovery_ratio(values, stg_values, draw$draw_matrix)
        denominator <- publication_mean_or_na(stg_values)
        numerator <- publication_mean_or_na(values)
        point <- if (is.finite(denominator) && denominator > 0 && is.finite(numerator)) 1 - numerator / denominator else NA_real_
        rows[[length(rows) + 1L]] <- publication_bootstrap_row(
          group, metric, population, "recovery_ratio", method, NA_character_, point,
          values, draw, seed, mean(!is.finite(recovery))
        )
        rows[[length(rows)]]$ci_lower <- publication_percentile_interval(recovery)[[1L]]
        rows[[length(rows)]]$ci_upper <- publication_percentile_interval(recovery)[[2L]]
      }
      contrast_data <- publication_group_subset(
        contrasts[contrasts$analysis_population == population & contrasts$metric == metric & contrasts$family == "PRIMARY_AO", , drop = FALSE], group
      )
      expected_pairs <- sort(unique(contrast_data$contrast_id))
      rsto_assert(length(expected_pairs) == 6L, sprintf("Bootstrap pairwise panel differs in group %s.", group))
      for (contrast_id in expected_pairs) {
        piece <- contrast_data[contrast_data$contrast_id == contrast_id, , drop = FALSE]
        values <- publication_bootstrap_group_series_vector(piece, "contrast", group_indices)
        rows[[length(rows) + 1L]] <- publication_bootstrap_row(
          group, metric, population, "pairwise_delta_degradation", NA_character_, contrast_id,
          publication_mean_or_na(values), values, draw, seed
        )
      }
    }
  }
  out <- do.call(rbind, rows)
  rsto_assert(nrow(out) == 420L, "Bootstrap panel must contain 420 frozen rows.")
  out
}

publication_bootstrap_primary_ci <- function(estimands, contrasts, config = rsto_publication_config()) {
  B <- config$bootstrap$B
  seed <- config$bootstrap$seed
  rsto_assert(identical(as.integer(B), 5000L) && identical(as.integer(seed), 202607131L), "Frozen bootstrap guard rejected the config.")
  publication_bootstrap_primary_ci_core(estimands, contrasts, B, seed, formal = TRUE)
}

publication_bootstrap_primary_ci_synthetic <- function(estimands, contrasts, B = 80L, seed = 202607131L) {
  publication_bootstrap_primary_ci_core(estimands, contrasts, as.integer(B), as.integer(seed), formal = FALSE)
}

publication_build_summary_outputs <- function(metrics, config = rsto_publication_config(), bootstrap = TRUE) {
  estimands <- publication_build_estimand_panel(metrics)
  pairs <- c("IQR_ST_vs_STG", "RSTO_NU5_vs_STG", "ROBETS_vs_STG", "RSTO_NU5_vs_IQR_ST", "RSTO_NU5_vs_ROBETS", "IQR_ST_vs_ROBETS")
  contrasts <- publication_pairwise_degradation_contrasts(estimands, pairs)
  primary <- publication_summarize_estimands(estimands, "PRIMARY_AO")
  last_point <- publication_summarize_estimands(estimands, "LAST_POINT")
  out <- list(
    CLEAN_PERFORMANCE_BOUNDARY = publication_clean_performance_boundary(metrics),
    FAILURE_FALLBACK_SUMMARY = publication_failure_fallback_summary(metrics),
    LAST_POINT_BY_FREQUENCY = last_point[last_point$group != "OVERALL", , drop = FALSE],
    LAST_POINT_OVERALL = last_point[last_point$group == "OVERALL", , drop = FALSE],
    PRIMARY_AO_BY_FREQUENCY = primary[primary$group != "OVERALL", , drop = FALSE],
    PRIMARY_AO_OVERALL = primary[primary$group == "OVERALL", , drop = FALSE],
    PRIMARY_PAIRWISE_CONTRASTS = publication_summarize_pairwise(contrasts),
    Q_ENDPOINT_SUMMARY = NULL,
    ESTIMANDS = estimands,
    CONTRASTS = contrasts
  )
  if (isTRUE(bootstrap)) out$PRIMARY_BOOTSTRAP_CI <- publication_bootstrap_primary_ci(estimands, contrasts, config)
  out
}

publication_recovery_figure_data <- function(primary_overall, last_point_overall) {
  methods <- c("IQR_ST", "RSTO_NU5_FROZEN_HISTORICAL_FLOW", "ROBETS_CREVITS_CROUX_VERSION_1_4")
  rbind(
    transform(primary_overall[primary_overall$method_id %in% methods, c("metric", "method_id", "recovery_ratio")], contamination_family = "PRIMARY_AO"),
    transform(last_point_overall[last_point_overall$method_id %in% methods, c("metric", "method_id", "recovery_ratio")], contamination_family = "LAST_POINT")
  )
}
