# Publication implementation of the frozen M3 method panel.
# The functions below are self-contained implementations. Frozen source is
# loaded only by tests/equivalence.R as an oracle.

rsto_model_config <- function() {
  protocol <- rsto_publication_config()$rsto
  list(
    nu_grid = c(3, 5, 8, 15, Inf),
    primary_finite_nu_branch = protocol$nu,
    kappa = protocol$kappa,
    H_init_floor = protocol$H_init_floor,
    c_omega = protocol$c_omega,
    q_lower = protocol$q_lower,
    q_upper = protocol$q_upper,
    log_H_window = protocol$log_H_window,
    optimizer_outer_cycles = protocol$optimizer_outer_cycles,
    optimizer_optimize_tol = protocol$optimizer_optimize_tol,
    optimizer_incumbent_tolerance = protocol$optimizer_incumbent_tolerance,
    optimizer_boundary_tol = protocol$optimizer_boundary_tol,
    optimizer_max_eval = protocol$optimizer_max_eval
  )
}

rsto_validate_y_train <- function(y_train) {
  if (!is.numeric(y_train) || length(y_train) < 1L || any(!is.finite(y_train))) {
    stop("y_train must be a non-empty finite numeric vector.", call. = FALSE)
  }
  as.numeric(y_train)
}

rsto_validate_scalar <- function(x, name, lower = -Inf, allow_equal_lower = TRUE) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x)) {
    stop(sprintf("%s must be a finite numeric scalar.", name), call. = FALSE)
  }
  ok <- if (allow_equal_lower) x >= lower else x > lower
  if (!ok) stop(sprintf("%s is outside the allowed range.", name), call. = FALSE)
  as.numeric(x)
}

rsto_validate_q <- function(q, config = rsto_model_config()) {
  q <- rsto_validate_scalar(q, "q")
  if (q < config$q_lower || q > config$q_upper) {
    stop("q must satisfy q_lower <= q <= q_upper.", call. = FALSE)
  }
  q
}

rsto_train_scale <- function(y_train) {
  y_train <- rsto_validate_y_train(y_train)
  max(stats::sd(y_train), stats::IQR(y_train) / 1.349, sqrt(1e-12), na.rm = TRUE)
}

rsto_omega_bound <- function(y_train, config = rsto_model_config()) {
  config$c_omega * rsto_train_scale(y_train) / length(y_train)
}

rsto_validate_omega_bound <- function(omega, y_train, config = rsto_model_config()) {
  omega <- rsto_validate_scalar(omega, "omega")
  bound <- rsto_omega_bound(y_train, config)
  if (abs(omega) > bound) stop("omega is outside the training-only omega bound.", call. = FALSE)
  list(omega = omega, omega_bound = bound)
}

rsto_validate_nu <- function(nu, config = rsto_model_config(), enforce_grid = TRUE) {
  if (!is.numeric(nu) || length(nu) != 1L) stop("nu must be a numeric scalar.", call. = FALSE)
  if (is.infinite(nu)) return(Inf)
  if (!is.finite(nu) || nu <= 2) stop("finite nu must be greater than 2.", call. = FALSE)
  if (isTRUE(enforce_grid) && !nu %in% config$nu_grid[is.finite(config$nu_grid)]) {
    stop("nu is not in the frozen nu_grid.", call. = FALSE)
  }
  as.numeric(nu)
}

rsto_positive_finite_or_na <- function(x) {
  if (length(x) != 1L || !is.finite(x) || x <= 0) NA_real_ else as.numeric(x)
}

rsto_preliminary_estimates <- function(y_train, config = rsto_model_config()) {
  y_train <- rsto_validate_y_train(y_train)
  n_train <- length(y_train)
  diff_y <- diff(y_train)
  median_diff <- if (length(diff_y) >= 1L) stats::median(diff_y^2) / 2 else NA_real_
  y_variance <- if (n_train >= 2L) stats::var(y_train) else NA_real_
  scale_candidate <- rsto_positive_finite_or_na(median_diff)
  if (!is.finite(scale_candidate)) scale_candidate <- rsto_positive_finite_or_na(y_variance)
  if (!is.finite(scale_candidate)) scale_candidate <- config$H_init_floor
  omega_hat <- if (n_train >= 2L) (y_train[n_train] - y_train[1L]) / (n_train - 1L) else 0
  omega_bound <- rsto_omega_bound(y_train, config)
  omega_hat <- max(-omega_bound, min(omega_bound, omega_hat))
  q_hat <- rsto_validate_q(min(config$q_upper, max(config$q_lower, scale_candidate / config$c_omega)), config)
  list(omega = omega_hat, q = q_hat, H = max(scale_candidate, config$H_init_floor), omega_bound = omega_bound)
}

rsto_H_init_fallback_cascade <- function(y_train, config = rsto_model_config(),
                                          matched_gaussian_H_hat_G = NULL) {
  y_train <- rsto_validate_y_train(y_train)
  diff_y <- diff(y_train)
  matched_candidate <- if (is.null(matched_gaussian_H_hat_G)) NA_real_ else
    rsto_positive_finite_or_na(matched_gaussian_H_hat_G)
  candidates <- c(
    matched_gaussian_H_hat_G = matched_candidate,
    median_diff_squared_half = if (length(diff_y) >= 1L) stats::median(diff_y^2) / 2 else NA_real_,
    y_variance = if (length(y_train) >= 2L) stats::var(y_train) else NA_real_,
    H_init_floor = config$H_init_floor
  )
  valid <- vapply(candidates, rsto_positive_finite_or_na, numeric(1L))
  selected <- which(is.finite(valid))[1L]
  list(H = unname(valid[selected]), H_init_source = names(candidates)[selected])
}

rsto_filter_gaussian <- function(y_train, omega, q, kappa = rsto_model_config()$kappa) {
  y_train <- rsto_validate_y_train(y_train)
  omega <- rsto_validate_scalar(omega, "omega")
  q <- rsto_validate_q(q)
  kappa <- rsto_validate_scalar(kappa, "kappa", lower = 0, allow_equal_lower = FALSE)
  n_train <- length(y_train)
  a_pred <- P_pred <- v <- F_value <- K <- a_filt <- P_filt <- numeric(n_train)
  a_pred[1L] <- y_train[1L]
  P_pred[1L] <- kappa
  for (t in seq_len(n_train)) {
    v[t] <- y_train[t] - a_pred[t]
    F_value[t] <- P_pred[t] + 1
    K[t] <- P_pred[t] / F_value[t]
    a_filt[t] <- a_pred[t] + K[t] * v[t]
    P_filt[t] <- P_pred[t] - K[t] * F_value[t] * K[t]
    if (P_filt[t] < -sqrt(.Machine$double.eps)) stop("Gaussian filter produced negative P_filt.", call. = FALSE)
    if (t < n_train) {
      a_pred[t + 1L] <- a_filt[t] + omega
      P_pred[t + 1L] <- P_filt[t] + q
    }
  }
  structure(list(
    branch = "gaussian_structural_theta", nu = Inf, kappa = kappa,
    omega_hat = omega, q_hat = q, y_train = y_train, a_pred = a_pred,
    P_pred = P_pred, v = v, F = F_value, K = K, a_filt = a_filt,
    P_filt = pmax(P_filt, 0), a_next_after_train = a_filt[n_train] + omega,
    weight_path = NULL, w_raw = NULL, w_tilde = NULL, s2_nu = NULL
  ), class = c("rsto_publication_fit", "list"))
}

rsto_filter_finite_nu <- function(y_train, omega, q, H, nu,
                                   kappa = rsto_model_config()$kappa) {
  config <- rsto_model_config()
  y_train <- rsto_validate_y_train(y_train)
  omega <- rsto_validate_scalar(omega, "omega")
  q <- rsto_validate_q(q)
  H <- rsto_validate_scalar(H, "H", lower = 0, allow_equal_lower = FALSE)
  nu <- rsto_validate_nu(nu, config, enforce_grid = FALSE)
  if (is.infinite(nu)) stop("finite-nu filter received nu = Inf; use Gaussian dispatch.", call. = FALSE)
  kappa <- rsto_validate_scalar(kappa, "kappa", lower = 0, allow_equal_lower = FALSE)
  n_train <- length(y_train)
  s2_nu <- H * (nu - 2) / nu
  a_pred <- P_pred <- v <- F_value <- K <- r2 <- w_raw <- w_tilde <- a_filt <- P_filt <- numeric(n_train)
  a_pred[1L] <- y_train[1L]
  P_pred[1L] <- kappa
  for (t in seq_len(n_train)) {
    v[t] <- y_train[t] - a_pred[t]
    F_value[t] <- P_pred[t] + 1
    K[t] <- P_pred[t] / F_value[t]
    r2[t] <- v[t]^2 / (s2_nu * F_value[t])
    w_raw[t] <- (nu + 1) / (nu + r2[t])
    w_tilde[t] <- min(1, w_raw[t])
    a_filt[t] <- a_pred[t] + w_tilde[t] * K[t] * v[t]
    P_filt[t] <- P_pred[t] - w_tilde[t] * K[t] * F_value[t] * K[t]
    if (P_filt[t] < -sqrt(.Machine$double.eps)) stop("finite-nu information recursion produced negative P_filt.", call. = FALSE)
    if (t < n_train) {
      a_pred[t + 1L] <- a_filt[t] + omega
      P_pred[t + 1L] <- P_filt[t] + q
    }
  }
  structure(list(
    branch = "finite_nu_rst_o", nu = nu, kappa = kappa, omega_hat = omega,
    q_hat = q, H_hat = H, y_train = y_train, a_pred = a_pred, P_pred = P_pred,
    v = v, F = F_value, K = K, r2 = r2, w_raw = w_raw, w_tilde = w_tilde,
    weight_path = w_tilde, a_filt = a_filt, P_filt = pmax(P_filt, 0),
    a_next_after_train = a_filt[n_train] + omega, s2_nu = s2_nu
  ), class = c("rsto_publication_fit", "list"))
}

rsto_score_indices <- function(n_train) {
  if (!is.numeric(n_train) || length(n_train) != 1L || !is.finite(n_train) ||
      n_train != as.integer(n_train) || n_train < 2L) {
    stop("n_train must be an integer >= 2 for objective scoring.", call. = FALSE)
  }
  2L:as.integer(n_train)
}

rsto_gaussian_concentrated_objective <- function(y_train, q, omega, config = rsto_model_config()) {
  fit <- rsto_filter_gaussian(y_train, omega, q, config$kappa)
  score_indices <- rsto_score_indices(length(y_train))
  H_hat_G <- mean(fit$v[score_indices]^2 / fit$F[score_indices])
  objective <- if (is.finite(H_hat_G) && H_hat_G > 0) {
    sum(log(fit$F[score_indices])) + length(score_indices) * log(H_hat_G)
  } else Inf
  list(objective = objective, H_hat_G = H_hat_G, score_indices = score_indices,
       objective_ok = is.finite(objective), filter = fit)
}

rsto_finite_nu_quasi_objective <- function(y_train, q, omega, logH, nu,
                                             config = rsto_model_config()) {
  H <- exp(logH)
  fit <- rsto_filter_finite_nu(y_train, omega, q, H, nu, config$kappa)
  score_indices <- rsto_score_indices(length(y_train))
  objective <- sum(
    0.5 * log(fit$s2_nu * fit$F[score_indices]) +
      0.5 * (nu + 1) * log1p(fit$v[score_indices]^2 / (nu * fit$s2_nu * fit$F[score_indices]))
  )
  list(objective = objective, H = H, logH = logH, score_indices = score_indices,
       objective_ok = is.finite(objective), filter = fit)
}

rsto_safe_objective <- function(expr) {
  value <- try(expr, silent = TRUE)
  if (inherits(value, "try-error") || !is.numeric(value) || length(value) != 1L || !is.finite(value)) {
    return(.Machine$double.xmax / 1e100)
  }
  value
}

rsto_preserve_incumbent <- function(candidate, incumbent,
                                    tolerance = sqrt(.Machine$double.eps)) {
  candidate_ok <- is.numeric(candidate) && length(candidate) == 1L && is.finite(candidate)
  incumbent_ok <- is.numeric(incumbent) && length(incumbent) == 1L && is.finite(incumbent)
  preserve <- isTRUE(incumbent_ok && (!candidate_ok || candidate > incumbent + tolerance))
  list(selected = if (preserve) incumbent else candidate, preserved = preserve)
}

rsto_optimizer_starts <- function(y_train, config = rsto_model_config(), q = NULL, omega = NULL) {
  preliminary <- rsto_preliminary_estimates(y_train, config)
  omega_info <- if (is.null(omega)) list(omega = preliminary$omega, omega_bound = preliminary$omega_bound) else
    rsto_validate_omega_bound(omega, y_train, config)
  list(q = if (is.null(q)) preliminary$q else rsto_validate_q(q, config),
       omega = omega_info$omega, omega_bound = omega_info$omega_bound)
}

rsto_optimize_gaussian <- function(y_train, config = rsto_model_config(), q = NULL, omega = NULL) {
  y_train <- rsto_validate_y_train(y_train)
  starts <- rsto_optimizer_starts(y_train, config, q, omega)
  q_current <- starts$q
  omega_current <- starts$omega
  q_start <- q_current
  omega_start <- omega_current
  omega_bound <- starts$omega_bound
  eval_count <- 0L
  counted_objective <- function(q_value, omega_value) {
    eval_count <<- eval_count + 1L
    rsto_safe_objective(rsto_gaussian_concentrated_objective(y_train, q_value, omega_value, config)$objective)
  }
  objective_start <- counted_objective(q_current, omega_current)
  after_q <- after_omega <- NA_real_
  for (cycle in seq_len(config$optimizer_outer_cycles)) {
    q_opt <- stats::optimize(
      f = function(q_value) counted_objective(q_value, omega_current),
      interval = c(config$q_lower, config$q_upper), tol = config$optimizer_optimize_tol
    )
    q_current <- q_opt$minimum
    after_q <- q_opt$objective
    omega_opt <- stats::optimize(
      f = function(omega_value) counted_objective(q_current, omega_value),
      interval = c(-omega_bound, omega_bound), tol = config$optimizer_optimize_tol
    )
    omega_current <- omega_opt$minimum
    after_omega <- omega_opt$objective
  }
  candidate <- rsto_gaussian_concentrated_objective(y_train, q_current, omega_current, config)
  eval_count <- eval_count + 1L
  preservation <- rsto_preserve_incumbent(candidate$objective, objective_start, config$optimizer_incumbent_tolerance)
  if (isTRUE(preservation$preserved)) {
    q_current <- q_start
    omega_current <- omega_start
    final <- rsto_gaussian_concentrated_objective(y_train, q_current, omega_current, config)
    eval_count <- eval_count + 1L
  } else {
    final <- candidate
  }
  q_lower <- isTRUE(q_current <= config$q_lower + config$optimizer_boundary_tol)
  q_upper <- isTRUE(q_current >= config$q_upper - config$optimizer_boundary_tol)
  warning <- !isTRUE(final$objective_ok) || eval_count > config$optimizer_max_eval ||
    !isTRUE(final$objective <= objective_start + config$optimizer_incumbent_tolerance)
  fit <- final$filter
  fit$H_hat <- final$H_hat_G
  fit$fit_inputs <- list(
    nu = Inf, q = q_current, omega = omega_current, H = final$H_hat_G,
    q_fit = q_current, omega_fit = omega_current, H_fit = final$H_hat_G,
    logH_fit = log(final$H_hat_G), H_init = final$H_hat_G,
    score_indices = final$score_indices, omega_bound = omega_bound
  )
  fit$optimizer <- list(
    optimizer_status = if (warning) "bounded_coordinate_search_warning" else "bounded_coordinate_search_converged",
    optimizer_convergence_code = if (warning) 1L else 0L,
    q_lower_flag = q_lower, q_upper_flag = q_upper,
    objective_eval_count = eval_count, objective_value_start = objective_start,
    objective_value_after_q_step = after_q, objective_value_after_omega_step = after_omega,
    objective_value_final = final$objective, incumbent_preserved = preservation$preserved
  )
  fit
}

rsto_H_init_from_matched_gaussian <- function(y_train, config = rsto_model_config(), H = NULL,
                                               matched_gaussian_fit = NULL) {
  if (!is.null(H)) {
    return(list(H = rsto_validate_scalar(H, "H", lower = 0, allow_equal_lower = FALSE),
                H_init_source = "user_supplied"))
  }
  if (!is.null(matched_gaussian_fit)) {
    return(rsto_H_init_fallback_cascade(y_train, config, matched_gaussian_fit$fit_inputs$H))
  }
  matched <- try(rsto_optimize_gaussian(y_train, config), silent = TRUE)
  candidate <- if (inherits(matched, "try-error")) NA_real_ else matched$fit_inputs$H
  rsto_H_init_fallback_cascade(y_train, config, candidate)
}

rsto_optimize_finite_nu <- function(y_train, nu, config = rsto_model_config(), q = NULL,
                                     omega = NULL, H = NULL, matched_gaussian_fit = NULL) {
  y_train <- rsto_validate_y_train(y_train)
  nu <- rsto_validate_nu(nu, config)
  if (is.infinite(nu)) stop("finite-nu optimizer received nu = Inf; use Gaussian optimizer.", call. = FALSE)
  starts <- rsto_optimizer_starts(y_train, config, q, omega)
  H_info <- rsto_H_init_from_matched_gaussian(y_train, config, H, matched_gaussian_fit)
  H_init <- max(H_info$H, config$H_init_floor)
  logH_lower <- log(H_init) - config$log_H_window
  logH_upper <- log(H_init) + config$log_H_window
  q_current <- starts$q
  omega_current <- starts$omega
  q_start <- q_current
  omega_start <- omega_current
  logH_start <- log(H_init)
  omega_bound <- starts$omega_bound
  inner_eval_count <- 0L
  outer_eval_count <- 0L
  objective_start <- rsto_safe_objective(
    rsto_finite_nu_quasi_objective(y_train, q_current, omega_current, logH_start, nu, config)$objective
  )
  after_q <- after_omega <- NA_real_
  inner_objective <- function(q_value, omega_value) {
    outer_eval_count <<- outer_eval_count + 1L
    opt <- stats::optimize(
      f = function(logH_value) {
        inner_eval_count <<- inner_eval_count + 1L
        rsto_safe_objective(
          rsto_finite_nu_quasi_objective(y_train, q_value, omega_value, logH_value, nu, config)$objective
        )
      },
      interval = c(logH_lower, logH_upper), tol = config$optimizer_optimize_tol
    )
    opt$objective
  }
  for (cycle in seq_len(config$optimizer_outer_cycles)) {
    q_opt <- stats::optimize(
      f = function(q_value) inner_objective(q_value, omega_current),
      interval = c(config$q_lower, config$q_upper), tol = config$optimizer_optimize_tol
    )
    q_current <- q_opt$minimum
    after_q <- q_opt$objective
    omega_opt <- stats::optimize(
      f = function(omega_value) inner_objective(q_current, omega_value),
      interval = c(-omega_bound, omega_bound), tol = config$optimizer_optimize_tol
    )
    omega_current <- omega_opt$minimum
    after_omega <- omega_opt$objective
  }
  final_logH <- stats::optimize(
    f = function(logH_value) {
      inner_eval_count <<- inner_eval_count + 1L
      rsto_safe_objective(
        rsto_finite_nu_quasi_objective(y_train, q_current, omega_current, logH_value, nu, config)$objective
      )
    },
    interval = c(logH_lower, logH_upper), tol = config$optimizer_optimize_tol
  )$minimum
  candidate <- rsto_finite_nu_quasi_objective(y_train, q_current, omega_current, final_logH, nu, config)
  inner_eval_count <- inner_eval_count + 1L
  preservation <- rsto_preserve_incumbent(candidate$objective, objective_start, config$optimizer_incumbent_tolerance)
  if (isTRUE(preservation$preserved)) {
    q_current <- q_start
    omega_current <- omega_start
    final_logH <- logH_start
    final <- rsto_finite_nu_quasi_objective(y_train, q_current, omega_current, final_logH, nu, config)
    inner_eval_count <- inner_eval_count + 1L
  } else {
    final <- candidate
  }
  q_lower <- isTRUE(q_current <= config$q_lower + config$optimizer_boundary_tol)
  q_upper <- isTRUE(q_current >= config$q_upper - config$optimizer_boundary_tol)
  H_lower <- isTRUE(final_logH <= logH_lower + config$optimizer_boundary_tol)
  H_upper <- isTRUE(final_logH >= logH_upper - config$optimizer_boundary_tol)
  warning <- !isTRUE(final$objective_ok) || inner_eval_count > config$optimizer_max_eval ||
    !isTRUE(final$objective <= objective_start + config$optimizer_incumbent_tolerance)
  fit <- final$filter
  fit$fit_inputs <- list(
    nu = nu, q = q_current, omega = omega_current, H = final$H,
    q_fit = q_current, omega_fit = omega_current, H_fit = final$H,
    logH_fit = final$logH, H_init = H_init, H_init_source = H_info$H_init_source,
    score_indices = final$score_indices, omega_bound = omega_bound
  )
  fit$optimizer <- list(
    optimizer_status = if (warning) "bounded_coordinate_search_warning" else "bounded_coordinate_search_converged",
    optimizer_convergence_code = if (warning) 1L else 0L,
    q_lower_flag = q_lower, q_upper_flag = q_upper,
    H_lower_flag = H_lower, H_upper_flag = H_upper,
    objective_eval_count = inner_eval_count, inner_eval_count = inner_eval_count,
    outer_eval_count = outer_eval_count, objective_value_start = objective_start,
    objective_value_after_q_step = after_q, objective_value_after_omega_step = after_omega,
    objective_value_final = final$objective, incumbent_preserved = preservation$preserved
  )
  fit
}

rsto_fit <- function(y_train, nu, config = rsto_model_config(), omega = NULL, q = NULL, H = NULL,
                     matched_gaussian_fit = NULL) {
  y_train <- rsto_validate_y_train(y_train)
  nu <- rsto_validate_nu(nu, config)
  if (is.infinite(nu)) {
    rsto_optimize_gaussian(y_train, config, q, omega)
  } else {
    rsto_optimize_finite_nu(y_train, nu, config, q, omega, H, matched_gaussian_fit)
  }
}

rsto_forecast <- function(fit, horizon) {
  if (!inherits(fit, "rsto_publication_fit") || is.null(fit$a_next_after_train) || is.null(fit$omega_hat)) {
    stop("fit must be an rsto_publication_fit object.", call. = FALSE)
  }
  if (!is.numeric(horizon) || length(horizon) != 1L || !is.finite(horizon) ||
      horizon < 1L || horizon != as.integer(horizon)) {
    stop("horizon must be a positive integer scalar.", call. = FALSE)
  }
  j <- seq_len(as.integer(horizon))
  fit$a_next_after_train + (j - 1L) * fit$omega_hat
}

publication_author_likelihood <- function(y, q, co) {
  y <- rsto_validate_y_train(y)
  q <- abs(q)
  co <- abs(co)
  state <- p <- rep(0, length(y) + 1L)
  state[1L] <- y[1L]
  p[1L] <- 10000
  k <- inn <- rep(0, length(y))
  k[1L] <- p[1L] / (p[1L] + 1)
  sigmae <- 0
  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- co + state[1L] + k[1L] * inn[1L]
  for (t in 2:length(y)) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- co + state[t] + k[t] * inn[t]
  }
  sum(log(p + 1)) + length(y) * log(sigmae / length(y))
}

publication_author_nonseasonal <- function(y, steps) {
  y <- rsto_validate_y_train(y)
  if (!is.numeric(steps) || length(steps) != 1L || !is.finite(steps) ||
      steps < 1L || steps != as.integer(steps)) {
    stop("steps must be a positive integer scalar.", call. = FALSE)
  }
  steps <- as.integer(steps)
  likelihood <- function(parameters) publication_author_likelihood(y, parameters[1L], parameters[2L])
  results <- stats::optim(c(.01, .001), likelihood)
  q <- abs(results[[1L]][1L])
  co <- abs(results[[1L]][2L])
  state <- p <- rep(0, length(y) + 1L)
  state[1L] <- y[1L]
  p[1L] <- 10000
  k <- inn <- rep(0, length(y))
  k[1L] <- p[1L] / (p[1L] + 1)
  sigmae <- 0
  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- co + state[1L] + k[1L] * inn[1L]
  for (t in 2:length(y)) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- co + state[t] + k[t] * inn[t]
  }
  point_forecast <- rep(0, steps)
  point_forecast[1L] <- state[length(y) + 1L]
  if (steps >= 2L) {
    for (t in 2:steps) point_forecast[t] <- co * (t - 1L) + state[length(y) + 1L]
  }
  list(
    mean = point_forecast, q_fit = q, omega_fit = co,
    H_fit = sigmae / (length(y) - 1L), state = state, p = p,
    K = k, innovation = inn, yhat_one_step = state[seq_along(y)], optim = results
  )
}

publication_author_seasonal_bundle <- function(y_train, horizon, frequency) {
  y_train <- as.numeric(y_train)
  frequency <- as.integer(frequency)
  horizon <- as.integer(horizon)
  if (frequency <= 1L) return(list(y_sa = y_train, sfactors = 1, sfactout = rep(1, horizon)))
  for (t in seq_along(y_train)) {
    if (y_train[[t]] != 0) {
      y_train <- y_train[t:length(y_train)]
      break
    }
  }
  s <- frequency
  if (length(y_train) <= s) stop("training series is too short for author seasonal factors", call. = FALSE)
  w <- rep(1 / (2 * s), s + 1L)
  w[2:s] <- 1 / s
  cma <- matrix(NA_real_, length(y_train), 1L)
  for (g in seq_len(length(y_train) - s)) cma[g + s / 2] <- sum(w * y_train[g:(g + s)])
  residuals <- y_train / cma
  sfactors <- numeric(s)
  for (seas in seq_len(s)) {
    sfactors[[seas]] <- mean(stats::na.omit(residuals[seq(seas, length(y_train) - s + seas, by = s)]))
  }
  sfactors <- sfactors * s / sum(sfactors)
  list(
    y_sa = y_train / rep(sfactors, ceiling(length(y_train) / s))[seq_along(y_train)],
    sfactors = sfactors,
    sfactout = rep(sfactors, length(y_train) + horizon)[(length(y_train) + 1L):(length(y_train) + horizon)]
  )
}

publication_stg_author_kernel <- function(y, steps, freq) {
  # Literal M3 author-kernel arithmetic. The richer return exposes paths for
  # the fixture harness but does not alter the point-forecast calculation.
  if (freq != 1) {
    s <- freq
    for (t in 1:length(y)) if (y[t] != 0) {
      y <- y[t:length(y)]
      break
    }
    w <- rep(1 / (2 * s), s + 1)
    w[2:s] <- 1 / s
    cma <- matrix(NA, length(y), 1)
    for (g in 1:(length(y) - s)) cma[g + s / 2] <- sum(w * y[g:(g + s)])
    residuals <- y / cma
    sfactors <- c()
    for (seas in 1:s) sfactors[seas] <- mean(stats::na.omit(residuals[seq(seas, length(y) - s + seas, by = s)]))
    sfactors <- sfactors * s / sum(sfactors)
    sfactout <- rep(sfactors, length(y) + steps)[(length(y) + 1):(length(y) + steps)]
    y <- y / rep(sfactors, ceiling(length(y) / s))[1:length(y)]
  } else {
    sfactout <- rep(1, steps)
  }
  likelihood <- function(parameters) {
    q <- abs(parameters[1])
    co <- abs(parameters[2])
    state <- p <- rep(0, length(y) + 1)
    state[1] <- y[1]
    p[1] <- 10000
    k <- inn <- rep(0, length(y))
    k[1] <- p[1] / (p[1] + 1)
    sigmae <- 0
    p[2] <- p[1] - p[1] * k[1] + q
    state[2] <- co + state[1] + k[1] * inn[1]
    for (t in 2:length(y)) {
      k[t] <- p[t] / (p[t] + 1)
      inn[t] <- y[t] - state[t]
      sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
      p[t + 1] <- p[t] - p[t] * k[t] + q
      state[t + 1] <- co + state[t] + k[t] * inn[t]
    }
    sum(log(p + 1)) + length(y) * log(sigmae / length(y))
  }
  results <- stats::optim(c(.01, 1), likelihood)
  q <- abs(results[[1]][1])
  co <- abs(results[[1]][2])
  state <- p <- rep(0, length(y) + 1)
  state[1] <- y[1]
  p[1] <- 10000
  k <- inn <- rep(0, length(y))
  k[1] <- p[1] / (p[1] + 1)
  sigmae <- 0
  p[2] <- p[1] - p[1] * k[1] + q
  state[2] <- co + state[1] + k[1] * inn[1]
  for (t in 2:length(y)) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
    p[t + 1] <- p[t] - p[t] * k[t] + q
    state[t + 1] <- co + state[t] + k[t] * inn[t]
  }
  point_forecast <- rep(0, steps)
  point_forecast[1] <- state[length(y) + 1]
  for (t in 2:steps) point_forecast[t] <- co * (t - 1) + state[length(y) + 1]
  point_forecast <- point_forecast * sfactout
  list(forecast = as.numeric(point_forecast), q_fit = q, omega_fit = co,
       state = state, p = p, K = k, innovation = inn, optim = results)
}

publication_iqr_winsorize <- function(y_train, first_fit, k = 1.5) {
  y_train <- rsto_validate_y_train(y_train)
  residual <- as.numeric(first_fit$innovation)
  yhat <- as.numeric(first_fit$yhat_one_step)
  if (length(residual) != length(y_train) || length(yhat) != length(y_train)) {
    stop("author fit path length mismatch.", call. = FALSE)
  }
  q1 <- as.numeric(stats::quantile(residual, 0.25, type = 7, names = FALSE))
  q3 <- as.numeric(stats::quantile(residual, 0.75, type = 7, names = FALSE))
  iqr <- q3 - q1
  if (!is.finite(iqr) || iqr <= 0) {
    return(list(y_winsorized = y_train, residual = residual, residual_winsorized = residual,
                yhat_one_step = yhat, q1 = q1, q3 = q3, iqr = iqr,
                lower_fence = NA_real_, upper_fence = NA_real_, fallback_used = TRUE,
                warning_type = "iqr_zero_no_winsorization_fallback"))
  }
  lower <- q1 - k * iqr
  upper <- q3 + k * iqr
  residual_w <- pmin(pmax(residual, lower), upper)
  list(y_winsorized = yhat + residual_w, residual = residual,
       residual_winsorized = residual_w, yhat_one_step = yhat, q1 = q1, q3 = q3,
       iqr = iqr, lower_fence = lower, upper_fence = upper, fallback_used = FALSE,
       warning_type = NA_character_)
}

publication_method_stg <- function(y_train, horizon, frequency) {
  list(forecast = publication_stg_author_kernel(as.numeric(y_train), as.integer(horizon), as.integer(frequency))$forecast)
}

publication_method_iqr <- function(y_train, horizon, frequency) {
  seasonal <- publication_author_seasonal_bundle(y_train, horizon, frequency)
  first_fit <- publication_author_nonseasonal(seasonal$y_sa, horizon)
  winsorized <- publication_iqr_winsorize(seasonal$y_sa, first_fit, k = 1.5)
  second_fit <- publication_author_nonseasonal(winsorized$y_winsorized, horizon)
  list(
    forecast = as.numeric(second_fit$mean) * seasonal$sfactout,
    iqr_warning = if (isTRUE(winsorized$fallback_used)) winsorized$warning_type else NULL
  )
}

publication_method_rsto <- function(y_train, horizon, frequency) {
  seasonal <- publication_author_seasonal_bundle(y_train, horizon, frequency)
  config <- rsto_model_config()
  fit <- rsto_fit(seasonal$y_sa, nu = config$primary_finite_nu_branch, config = config)
  q_fit <- as.numeric(fit$q)
  lower_hit <- is.finite(q_fit) && q_fit <= config$q_lower + config$optimizer_boundary_tol
  upper_hit <- is.finite(q_fit) && q_fit >= config$q_upper - config$optimizer_boundary_tol
  q_endpoint_status <- if (!is.finite(q_fit)) {
    "Q_NONFINITE"
  } else if (lower_hit && upper_hit) {
    "Q_BOTH_ENDPOINT_FLAGS"
  } else if (lower_hit) {
    "Q_LOWER_ENDPOINT"
  } else if (upper_hit) {
    "Q_UPPER_ENDPOINT"
  } else {
    "Q_INTERIOR"
  }
  list(forecast = as.numeric(rsto_forecast(fit, horizon)) * seasonal$sfactout,
       q_endpoint_status = q_endpoint_status)
}

publication_method_robets <- function(y_train, horizon, frequency) {
  if (!requireNamespace("robets", quietly = TRUE)) stop("robets is unavailable", call. = FALSE)
  y <- stats::ts(as.numeric(y_train), frequency = as.integer(frequency))
  training_domain_requires_additive <- any(as.numeric(y) <= 0)
  fit <- robets::robets(
    y, model = "ZZZ", damped = NULL, additive.only = training_domain_requires_additive,
    lambda = NULL, opt.crit = "roblik", bounds = "both", ic = "robaicc",
    use.initial.values = TRUE, opt.initial.values = FALSE,
    rob.start.initial.values = TRUE, opt.sigma0 = FALSE, k = 3, nmse = 1
  )
  forecast <- robets::forecast.robets(fit, h = as.integer(horizon), PI = FALSE)
  list(forecast = as.numeric(forecast$mean), training_domain_requires_additive = training_domain_requires_additive)
}

publication_uniform_fallback <- function(y_train, horizon, frequency) {
  if (frequency > 1L && length(y_train) >= 2L * frequency) {
    list(forecast = rep(utils::tail(y_train, frequency), length.out = horizon), type = "SEASONAL_NAIVE")
  } else {
    list(forecast = rep(utils::tail(y_train, 1L), horizon), type = "LAST_OBSERVATION_NAIVE")
  }
}

publication_run_method <- function(method_function, y_train, horizon, frequency) {
  warnings <- character()
  warning_classes <- character()
  failure <- NULL
  returned <- tryCatch(
    withCallingHandlers(
      method_function(y_train = y_train, horizon = horizon, frequency = frequency),
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        warning_classes <<- c(warning_classes, class(w)[[1L]])
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      failure <<- e
      NULL
    }
  )
  forecast <- if (is.list(returned) && "forecast" %in% names(returned)) returned$forecast else NULL
  valid <- is.null(failure) && is.numeric(forecast) && length(forecast) == as.integer(horizon) && all(is.finite(forecast))
  if (valid) {
    iqr_warning <- returned$iqr_warning %||% NULL
    iqr_present <- !is.null(iqr_warning) && length(iqr_warning) > 0L && !all(is.na(iqr_warning)) && !identical(iqr_warning, FALSE)
    messages <- c(warnings, if (iqr_present) paste(as.character(iqr_warning), collapse = " | ") else character())
    classes <- c(warning_classes, if (iqr_present) "IQR_INTERNAL_WARNING" else character())
    return(list(
      forecast = as.numeric(forecast), method_success = TRUE, pipeline_output_available = TRUE,
      fallback_used = FALSE, fallback_type = NA_character_, warning_observed = length(messages) > 0L,
      warning_count = length(messages), warning_class = if (length(classes)) paste(unique(classes), collapse = " | ") else NA_character_,
      warning_message = if (length(messages)) paste(messages, collapse = " | ") else NA_character_,
      error_class = NA_character_, error_message = NA_character_,
      optimizer_status = if (!is.null(returned$optimizer_status)) as.character(returned$optimizer_status) else "NOT_EXPOSED_BY_FROZEN_ADAPTER",
      q_fit = if (!is.null(returned$q_fit)) as.numeric(returned$q_fit) else NA_real_,
      q_endpoint_status = if (!is.null(returned$q_endpoint_status)) as.character(returned$q_endpoint_status) else "NOT_EXPOSED_BY_FROZEN_ADAPTER",
      adapter_metadata_exposure = if (!is.null(returned$q_fit) || !is.null(returned$q_endpoint_status) || !is.null(returned$optimizer_status)) "EXPOSED" else "NOT_EXPOSED"
    ))
  }
  fallback <- publication_uniform_fallback(y_train, horizon, frequency)
  list(
    forecast = fallback$forecast, method_success = FALSE, pipeline_output_available = TRUE,
    fallback_used = TRUE, fallback_type = fallback$type, warning_observed = length(warnings) > 0L,
    warning_count = length(warnings), warning_class = if (length(warning_classes)) paste(unique(warning_classes), collapse = " | ") else NA_character_,
    warning_message = paste(warnings, collapse = " | "),
    error_class = if (is.null(failure)) "INVALID_FROZEN_OUTPUT" else class(failure)[[1L]],
    error_message = if (is.null(failure)) "frozen method returned an invalid forecast" else conditionMessage(failure),
    optimizer_status = "NOT_EXPOSED_BY_FROZEN_ADAPTER", q_fit = NA_real_,
    q_endpoint_status = "NOT_EXPOSED_BY_FROZEN_ADAPTER", adapter_metadata_exposure = "NOT_EXPOSED"
  )
}

`%||%` <- function(lhs, rhs) if (is.null(lhs) || !length(lhs)) rhs else lhs

publication_method_panel <- function() {
  list(
    STG = publication_method_stg,
    IQR_ST = publication_method_iqr,
    RSTO_NU5_FROZEN_HISTORICAL_FLOW = publication_method_rsto,
    ROBETS_CREVITS_CROUX_VERSION_1_4 = publication_method_robets
  )
}

publication_method_trace <- function(method_id, y_train, horizon, frequency) {
  if (identical(method_id, "STG")) {
    return(list(
      parameters = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
      innovation_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
      weight_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
      state_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER"
    ))
  }
  if (identical(method_id, "IQR_ST")) {
    seasonal <- publication_author_seasonal_bundle(y_train, horizon, frequency)
    first <- publication_author_nonseasonal(seasonal$y_sa, horizon)
    win <- publication_iqr_winsorize(seasonal$y_sa, first)
    second <- publication_author_nonseasonal(win$y_winsorized, horizon)
    return(list(parameters = c(q = second$q_fit, omega = second$omega_fit, H = second$H_fit),
                innovation_path = second$innovation, weight_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
                state_path = second$state, forecast = as.numeric(second$mean) * seasonal$sfactout,
                iqr = win))
  }
  if (identical(method_id, "RSTO_NU5_FROZEN_HISTORICAL_FLOW")) {
    seasonal <- publication_author_seasonal_bundle(y_train, horizon, frequency)
    fit <- rsto_fit(seasonal$y_sa, nu = rsto_model_config()$primary_finite_nu_branch)
    return(list(parameters = c(q = fit$fit_inputs$q_fit, omega = fit$fit_inputs$omega_fit, H = fit$fit_inputs$H_fit),
                innovation_path = fit$v, weight_path = fit$weight_path, state_path = fit$a_filt,
                forecast = as.numeric(rsto_forecast(fit, horizon)) * seasonal$sfactout))
  }
  list(
    parameters = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
    innovation_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
    weight_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER",
    state_path = "NOT_EXPOSED_BY_FROZEN_ADAPTER"
  )
}
