publication_training_reference_scale <- function(y_train, config = rsto_publication_config()) {
  contamination <- config$contamination
  rsto_assert(is.numeric(y_train) && length(y_train) >= 1L && all(is.finite(y_train)), "Training input must be finite numeric data.")
  max(stats::sd(y_train), stats::IQR(y_train, type = 7) / 1.349, contamination$scale_floor)
}

publication_seed_for_series <- function(series_index, config = rsto_publication_config()) {
  contamination <- config$contamination
  as.integer(contamination$seed_base + contamination$seed_increment * as.integer(series_index) + 1L)
}

publication_primary_positions <- function(n_train, series_index, config = rsto_publication_config()) {
  contamination <- config$contamination
  rsto_assert(n_train >= contamination$eligible_start, "Primary AO requires at least five training observations.")
  eligible <- seq.int(contamination$eligible_start, as.integer(n_train))
  n_selected <- max(1L, ceiling(contamination$p_out * length(eligible)))
  set.seed(publication_seed_for_series(series_index, config))
  sort(sample(eligible, size = n_selected, replace = FALSE))
}

publication_inject_condition <- function(y_clean, positions, sign, scale, condition,
                                         series_id, series_index, family,
                                         config = rsto_publication_config()) {
  contamination <- config$contamination
  y_contaminated <- as.numeric(y_clean)
  original <- y_contaminated[positions]
  y_contaminated[positions] <- original + sign * contamination$c_out * scale
  manifest <- data.frame(
    run_id = NA_character_, series_id = as.character(series_id), series_index = as.integer(series_index),
    seed = publication_seed_for_series(series_index, config), condition = condition,
    contamination_family = family, position = as.integer(positions), n_train = as.integer(length(y_clean)),
    eligible_start = if (identical(family, "primary_dispersed_AO")) contamination$eligible_start else as.integer(length(y_clean)),
    eligible_end = as.integer(length(y_clean)), n_selected_positions = as.integer(length(positions)),
    training_reference_scale = as.numeric(scale), original_value = as.numeric(original),
    contaminated_value = as.numeric(y_contaminated[positions]), sign = as.integer(sign),
    c_out = contamination$c_out, position_set_id = paste(series_index, family, paste(positions, collapse = "-"), sep = "::"),
    stringsAsFactors = FALSE
  )
  list(y = y_contaminated, manifest = manifest)
}

publication_build_conditions <- function(y_clean, series_id, series_index, config = rsto_publication_config()) {
  y_clean <- as.numeric(y_clean)
  rsto_assert(length(y_clean) >= 5L && all(is.finite(y_clean)), "Clean training data are outside the frozen condition domain.")
  scale <- publication_training_reference_scale(y_clean, config)
  primary_positions <- publication_primary_positions(length(y_clean), series_index, config)
  primary_positive <- publication_inject_condition(y_clean, primary_positions, 1L, scale, "primary_AO_positive", series_id, series_index, "primary_dispersed_AO", config)
  primary_negative <- publication_inject_condition(y_clean, primary_positions, -1L, scale, "primary_AO_negative", series_id, series_index, "primary_dispersed_AO", config)
  last_position <- as.integer(length(y_clean))
  last_positive <- publication_inject_condition(y_clean, last_position, 1L, scale, "last_point_positive", series_id, series_index, "last_point", config)
  last_negative <- publication_inject_condition(y_clean, last_position, -1L, scale, "last_point_negative", series_id, series_index, "last_point", config)
  list(
    conditions = list(
      clean = y_clean, primary_AO_positive = primary_positive$y,
      primary_AO_negative = primary_negative$y, last_point_positive = last_positive$y,
      last_point_negative = last_negative$y
    ),
    manifest = rbind(primary_positive$manifest, primary_negative$manifest, last_positive$manifest, last_negative$manifest),
    training_reference_scale = scale, primary_positions = primary_positions
  )
}

publication_output_schemas <- function() {
  list(
    logs = c("run_id", "chunk_id", "series_id", "series_index", "condition", "method_id",
             "method_success", "fallback_used", "fallback_type", "warning_observed", "warning_count",
             "warning_class", "warning_message", "error_class", "error_message", "optimizer_status", "runtime_seconds"),
    runtime = c("run_id", "chunk_id", "series_id", "series_index", "period", "frequency", "condition",
                "method_id", "runtime_seconds", "method_success", "fallback_used", "pipeline_output_available"),
    q_endpoint = c("run_id", "chunk_id", "series_id", "series_index", "condition", "method_id", "q_fit",
                   "q_endpoint_status", "adapter_metadata_exposure", "optimizer_status", "method_success", "fallback_used")
  )
}

publication_build_series_outputs <- function(item, series_id, series_index, methods = publication_method_panel(),
                                             run_id = rsto_publication_config()$run_id,
                                             config = rsto_publication_config()) {
  frequency <- as.integer(stats::frequency(item$x))
  horizon <- as.integer(item$h)
  y_clean <- as.numeric(item$x)
  y_test <- as.numeric(item$xx)
  conditions <- publication_build_conditions(y_clean, series_id, series_index, config)
  conditions$manifest$run_id <- run_id
  forecast_rows <- list()
  metric_rows <- list()
  log_rows <- list()
  runtime_rows <- list()
  q_rows <- list()
  row_index <- 0L
  for (condition_name in names(conditions$conditions)) {
    y_input <- conditions$conditions[[condition_name]]
    for (method_id in names(methods)) {
      started <- proc.time()[["elapsed"]]
      fit <- publication_run_method(methods[[method_id]], y_input, horizon, frequency)
      runtime_seconds <- proc.time()[["elapsed"]] - started
      metrics <- publication_compute_metrics(y_clean, y_test, fit$forecast, frequency)
      horizon_index <- seq_len(horizon)
      row_index <- row_index + 1L
      forecast_rows[[row_index]] <- data.frame(
        run_id = run_id, chunk_id = NA_integer_, series_id = series_id, series_index = series_index,
        period = as.character(item$period), frequency = frequency, n_train = length(y_clean), horizon = horizon,
        horizon_index = horizon_index, condition = condition_name, method_id = method_id,
        actual = y_test, forecast = fit$forecast, error = metrics$error, absolute_error = abs(metrics$error),
        squared_error = metrics$error^2, smape_denominator = metrics$smape_denominator,
        smape_contribution = ifelse(metrics$smape_denominator == 0, NA_real_, 200 * abs(metrics$error) / metrics$smape_denominator),
        method_success = fit$method_success, fallback_used = fit$fallback_used, fallback_type = fit$fallback_type,
        pipeline_output_available = fit$pipeline_output_available, stringsAsFactors = FALSE
      )
      metric_rows[[row_index]] <- data.frame(
        run_id = run_id, chunk_id = NA_integer_, series_id = series_id, series_index = series_index,
        period = as.character(item$period), frequency = frequency, n_train = length(y_clean), horizon = horizon,
        condition = condition_name, method_id = method_id, MASE = metrics$MASE, RMSSE = metrics$RMSSE,
        sMAPE = metrics$sMAPE, MASE_denominator = metrics$MASE_denominator,
        RMSSE_denominator = metrics$RMSSE_denominator, scale_failure = metrics$scale_failure,
        metric_status = metrics$metric_status, smape_zero_denominator = metrics$smape_zero_denominator,
        method_success = fit$method_success, fallback_used = fit$fallback_used, fallback_type = fit$fallback_type,
        pipeline_output_available = fit$pipeline_output_available, warning_observed = fit$warning_observed,
        warning_count = fit$warning_count, warning_class = fit$warning_class, warning_message = fit$warning_message,
        error_class = fit$error_class, error_message = fit$error_message, optimizer_status = fit$optimizer_status,
        q_fit = fit$q_fit, q_endpoint_status = fit$q_endpoint_status,
        adapter_metadata_exposure = fit$adapter_metadata_exposure, runtime_seconds = runtime_seconds,
        stringsAsFactors = FALSE
      )
      schemas <- publication_output_schemas()
      log_rows[[row_index]] <- metric_rows[[row_index]][, schemas$logs, drop = FALSE]
      runtime_rows[[row_index]] <- metric_rows[[row_index]][, schemas$runtime, drop = FALSE]
      q_rows[[row_index]] <- metric_rows[[row_index]][, schemas$q_endpoint, drop = FALSE]
    }
  }
  list(
    contamination_manifest = conditions$manifest, forecast = do.call(rbind, forecast_rows),
    metrics = do.call(rbind, metric_rows), logs = do.call(rbind, log_rows),
    runtime = do.call(rbind, runtime_rows), q_endpoint = do.call(rbind, q_rows)
  )
}

publication_combine_chunk_outputs <- function(outputs) {
  list(
    contamination_manifest = do.call(rbind, lapply(outputs, `[[`, "contamination_manifest")),
    forecast = do.call(rbind, lapply(outputs, `[[`, "forecast")),
    metrics = do.call(rbind, lapply(outputs, `[[`, "metrics")),
    logs = do.call(rbind, lapply(outputs, `[[`, "logs")),
    runtime = do.call(rbind, lapply(outputs, `[[`, "runtime")),
    q_endpoint = do.call(rbind, lapply(outputs, `[[`, "q_endpoint"))
  )
}

publication_assign_chunk_id <- function(outputs, chunk_id) {
  for (name in c("forecast", "metrics", "logs", "runtime", "q_endpoint")) outputs[[name]]$chunk_id <- as.integer(chunk_id)
  outputs
}

publication_load_m3 <- function(config = rsto_publication_config()) {
  rsto_require_namespace("Mcomp")
  m3 <- Mcomp::M3
  rsto_assert(length(m3) == config$expected_counts$series, "M3 source identity differs from the frozen series count.")
  m3
}

publication_run_indices <- function(indices, m3 = publication_load_m3(),
                                    run_id = rsto_publication_config()$run_id,
                                    config = rsto_publication_config()) {
  indices <- as.integer(indices)
  rsto_assert(length(indices) >= 1L && all(indices >= 1L) && all(indices <= length(m3)), "Requested M3 indices are invalid.")
  combined <- publication_combine_chunk_outputs(lapply(indices, function(series_index) {
    publication_build_series_outputs(m3[[series_index]], names(m3)[[series_index]], series_index,
                                     run_id = run_id, config = config)
  }))
  publication_assign_chunk_id(combined, 1L)
}

publication_write_chunk <- function(outputs, raw_dir, append = FALSE) {
  mapping <- c(
    contamination_manifest = "CONTAMINATION_MANIFEST.csv",
    forecast = "FORECAST_LEVEL_RESULTS.csv",
    metrics = "SERIES_METHOD_CONDITION_METRICS.csv",
    logs = "METHOD_FAILURE_WARNING_LOG.csv",
    runtime = "RUNTIME_LOG.csv",
    q_endpoint = "Q_ENDPOINT_LOG.csv"
  )
  for (name in names(mapping)) {
    path <- file.path(raw_dir, mapping[[name]])
    if (isTRUE(append)) rsto_append_csv(outputs[[name]], path) else rsto_write_csv(outputs[[name]], path)
  }
  invisible(raw_dir)
}

publication_validate_full_outputs <- function(raw_dir, config = rsto_publication_config()) {
  forecast <- rsto_read_csv(file.path(raw_dir, "FORECAST_LEVEL_RESULTS.csv"))
  metrics <- rsto_read_csv(file.path(raw_dir, "SERIES_METHOD_CONDITION_METRICS.csv"))
  rsto_assert(nrow(forecast) == config$expected_counts$forecast_rows, "Forecast-row count differs from the frozen protocol.")
  rsto_assert(nrow(metrics) == config$expected_counts$metric_rows, "Metric-row count differs from the frozen protocol.")
  forecast_key <- forecast[, c("series_index", "condition", "method_id", "horizon_index"), drop = FALSE]
  metrics_key <- metrics[, c("series_index", "condition", "method_id"), drop = FALSE]
  rsto_assert(!anyDuplicated(forecast_key), "Forecast primary-key duplicates detected.")
  rsto_assert(!anyDuplicated(metrics_key), "Metric primary-key duplicates detected.")
  invisible(list(forecast = forecast, metrics = metrics))
}

publication_write_summary_outputs <- function(outputs, raw_dir, summary_dir, config = rsto_publication_config()) {
  dir.create(summary_dir, recursive = TRUE, showWarnings = FALSE)
  outputs$Q_ENDPOINT_SUMMARY <- publication_q_endpoint_summary(rsto_read_csv(file.path(raw_dir, "Q_ENDPOINT_LOG.csv")))
  for (name in c("CLEAN_PERFORMANCE_BOUNDARY", "FAILURE_FALLBACK_SUMMARY", "LAST_POINT_BY_FREQUENCY",
                 "LAST_POINT_OVERALL", "PRIMARY_AO_BY_FREQUENCY", "PRIMARY_AO_OVERALL",
                 "PRIMARY_BOOTSTRAP_CI", "PRIMARY_PAIRWISE_CONTRASTS", "Q_ENDPOINT_SUMMARY")) {
    rsto_write_csv(outputs[[name]], file.path(summary_dir, paste0(name, ".csv")))
  }
  runtime <- rsto_read_csv(file.path(raw_dir, "RUNTIME_LOG.csv"))
  rsto_write_csv(publication_runtime_summary(runtime), file.path(summary_dir, "RUNTIME_SUMMARY.csv"))
  invisible(summary_dir)
}

publication_run_full <- function(output_dir = rsto_output_dir(mode = "full"),
                                 config = rsto_publication_config()) {
  m3 <- publication_load_m3(config)
  raw_dir <- file.path(output_dir, "raw")
  summary_dir <- file.path(output_dir, "summary")
  dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
  n <- length(m3)
  starts <- seq.int(1L, n, by = config$expected_counts$chunk_size)
  for (chunk_id in seq_along(starts)) {
    indices <- seq.int(starts[[chunk_id]], min(n, starts[[chunk_id]] + config$expected_counts$chunk_size - 1L))
    outputs <- publication_combine_chunk_outputs(lapply(indices, function(series_index) {
      publication_build_series_outputs(m3[[series_index]], names(m3)[[series_index]], series_index,
                                       run_id = config$run_id, config = config)
    }))
    outputs <- publication_assign_chunk_id(outputs, chunk_id)
    publication_write_chunk(outputs, raw_dir, append = chunk_id > 1L)
  }
  validated <- publication_validate_full_outputs(raw_dir, config)
  summaries <- publication_build_summary_outputs(validated$metrics, config, bootstrap = TRUE)
  publication_write_summary_outputs(summaries, raw_dir, summary_dir, config)
  list(raw_dir = raw_dir, summary_dir = summary_dir, metrics = validated$metrics)
}

publication_reproduce_canonical <- function(output_dir = rsto_output_dir(mode = "reproduce"),
                                            root = rsto_package_root(), config = rsto_publication_config()) {
  stage <- rsto_stage_frozen_oracle(root, c("c1", "m3"), config = config)
  summary_dir <- file.path(output_dir, "summary")
  table_dir <- file.path(output_dir, "paper_data")
  dir.create(summary_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
  summary_files <- c(
    "CLEAN_PERFORMANCE_BOUNDARY.csv", "FAILURE_FALLBACK_SUMMARY.csv",
    "LAST_POINT_BY_FREQUENCY.csv", "LAST_POINT_OVERALL.csv",
    "PRIMARY_AO_BY_FREQUENCY.csv", "PRIMARY_AO_OVERALL.csv",
    "PRIMARY_BOOTSTRAP_CI.csv", "PRIMARY_PAIRWISE_CONTRASTS.csv",
    "Q_ENDPOINT_SUMMARY.csv", "RUNTIME_SUMMARY.csv"
  )
  summaries <- setNames(lapply(summary_files, function(file) {
    value <- rsto_read_canonical_m3(stage, file, kind = "summary")
    rsto_write_csv(value, file.path(summary_dir, file))
    value
  }), sub("\\.csv$", "", summary_files))
  c1_cells <- rsto_read_canonical_c1(stage, "C1_UNBLINDED_CELL_LEVEL_RESULTS.csv")
  c1_family <- rsto_read_canonical_c1(stage, "C1_UNBLINDED_FAMILY_DESCRIPTIVE_SUMMARIES.csv")
  rsto_write_csv(c1_family, file.path(table_dir, "C1_FAMILY_SUMMARIES.csv"))
  rsto_write_csv(c1_cells[c1_cells$metric == "MASE" & c1_cells$contrast %in% c("C1", "C2", "C3", "C4", "C5"), , drop = FALSE],
                 file.path(table_dir, "C1_MASE_CONTRASTS.csv"))
  rsto_write_csv(summaries$CLEAN_PERFORMANCE_BOUNDARY[summaries$CLEAN_PERFORMANCE_BOUNDARY$group == "OVERALL", , drop = FALSE],
                 file.path(table_dir, "M3_HEADLINE_CLEAN.csv"))
  rsto_write_csv(summaries$PRIMARY_PAIRWISE_CONTRASTS[
    summaries$PRIMARY_PAIRWISE_CONTRASTS$group == "OVERALL" &
      summaries$PRIMARY_PAIRWISE_CONTRASTS$contrast_id %in% c("RSTO_NU5_vs_IQR_ST", "RSTO_NU5_vs_ROBETS"), , drop = FALSE],
    file.path(table_dir, "M3_HEADLINE_CONTRASTS.csv")
  )
  rsto_write_csv(publication_recovery_figure_data(summaries$PRIMARY_AO_OVERALL, summaries$LAST_POINT_OVERALL),
                 file.path(table_dir, "M3_RECOVERY_FIGURE_DATA.csv"))
  list(stage = stage, summary_dir = summary_dir, table_dir = table_dir)
}
