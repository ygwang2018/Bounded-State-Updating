abc_run_six_arms <- function(path, parameters, huber_c, trace = FALSE) {
  y_train <- as.numeric(path$y_train); h <- as.integer(parameters$h); omega <- as.numeric(parameters$omega)
  q <- as.numeric(parameters$q); H <- as.numeric(parameters$H); nu <- as.numeric(parameters$nu); P1 <- as.numeric(parameters$P1)
  arms <- c("G", "MB", "CB", "VI", "US", "HB")
  a <- rep(y_train[[1L]], length(arms)); P <- rep(P1, length(arms)); s2 <- H * (nu - 2) / nu
  trace_rows <- if (trace) vector("list", length(y_train)) else NULL
  for (t in seq_along(y_train)) {
    yt <- y_train[[t]]; a_prior <- a; P_prior <- P; v <- yt - a; Fv <- P + 1; K <- P / Fv
    r2 <- (v^2) / (s2 * Fv); w <- (nu + 1) / (nu + r2); wt <- pmin.int(1, w)
    u <- v / sqrt(H * Fv); lambda_h <- ifelse(u == 0, 1, pmin(1, as.numeric(huber_c) / abs(u)))
    a_post <- P_post <- numeric(length(arms))
    a_post[[1L]] <- a[[1L]] + K[[1L]] * v[[1L]]; P_post[[1L]] <- P[[1L]] / (P[[1L]] + 1)
    a_post[[2L]] <- a[[2L]] + K[[2L]] * wt[[2L]] * v[[2L]]; P_post[[2L]] <- P[[2L]] / (P[[2L]] + 1)
    a_post[[3L]] <- a[[3L]] + K[[3L]] * wt[[3L]] * v[[3L]]; P_post[[3L]] <- P[[3L]] - wt[[3L]] * P[[3L]]^2 / (P[[3L]] + 1)
    k_infl <- wt[[4L]] * P[[4L]] / (1 + wt[[4L]] * P[[4L]])
    a_post[[4L]] <- a[[4L]] + k_infl * v[[4L]]; P_post[[4L]] <- P[[4L]] / (1 + wt[[4L]] * P[[4L]])
    a_post[[5L]] <- a[[5L]] + K[[5L]] * w[[5L]] * v[[5L]]; P_post[[5L]] <- P[[5L]] / (P[[5L]] + 1)
    a_post[[6L]] <- a[[6L]] + lambda_h[[6L]] * K[[6L]] * v[[6L]]; P_post[[6L]] <- P[[6L]] / (P[[6L]] + 1)
    abc_assert(all(is.finite(c(a_post, P_post))) && all(P_post >= 0), "Nonfinite or negative state update in six-arm runner.")
    a <- a_post + omega; P <- P_post + q
    if (trace) trace_rows[[t]] <- data.frame(t = t, arm = arms, y = yt, a_prior = a_prior, P_prior = P_prior, innovation = v, F = Fv, K = K, student_w = w, capped_w = wt, huber_lambda = lambda_h, a_post = a_post, P_post = P_post, a_next = a, P_next = P, stringsAsFactors = FALSE)
  }
  names(a_post) <- names(P_post) <- arms
  forecasts <- matrix(rep(a_post, each = h), nrow = h) + seq_len(h) * omega; colnames(forecasts) <- arms
  list(forecasts = forecasts, final_a_post = a_post, final_P_post = P_post, trace = if (trace) do.call(rbind, trace_rows) else NULL)
}

abc_b_contrasts <- function(losses) {
  out <- rbind("HB-G" = losses["HB", ] - losses["G", ], "MB-HB" = losses["MB", ] - losses["HB", ], "CB-HB" = losses["CB", ] - losses["HB", ])
  out
}

abc_b_new_aggregates <- function(c1_cfg) {
  dimensions <- c(nrow(c1_cfg$design), nrow(c1_cfg$profiles_df), length(c1_cfg$metrics), 3L)
  state <- new.env(parent = emptyenv())
  state$n <- matrix(0L, nrow(c1_cfg$design), nrow(c1_cfg$profiles_df))
  state$mean <- array(0, dim = dimensions)
  state$M2 <- array(0, dim = dimensions)
  state
}

abc_b_update_aggregates <- function(state, cell_index, profile_index, contrast_values) {
  values <- t(contrast_values)
  n1 <- state$n[cell_index, profile_index] + 1L
  old_mean <- state$mean[cell_index, profile_index, , ]
  delta <- values - old_mean
  new_mean <- old_mean + delta / n1
  state$mean[cell_index, profile_index, , ] <- new_mean
  state$M2[cell_index, profile_index, , ] <- state$M2[cell_index, profile_index, , ] + delta * (values - new_mean)
  state$n[cell_index, profile_index] <- n1
  invisible(state)
}

abc_b_finalize_aggregates <- function(state, c1_cfg, cell_rows, profile_ids, cfg) {
  rows <- list(); k <- 0L
  critical <- stats::qnorm(0.5 + as.numeric(cfg$reporting$interval_level) / 2)
  for (ci in cell_rows) for (profile_id in profile_ids) {
    pi <- match(profile_id, c1_cfg$profiles_df$profile_id); n <- state$n[ci, pi]
    for (mi in seq_along(c1_cfg$metrics)) for (ki in seq_along(cfg$module_b$contrasts)) {
      k <- k + 1L
      variance <- if (n > 1L) state$M2[ci, pi, mi, ki] / (n - 1L) else NA_real_
      mcse <- sqrt(variance / n); mean <- state$mean[ci, pi, mi, ki]
      rows[[k]] <- data.frame(
        result_level = "ONLINE_SUFFICIENT_STATISTICS", cell_id = c1_cfg$design$cell_id[[ci]], profile_id = profile_id,
        metric = c1_cfg$metrics[[mi]], contrast = cfg$module_b$contrasts[[ki]], n = n, mean = mean,
        variance = variance, mcse = mcse, lower_95 = mean - critical * mcse, upper_95 = mean + critical * mcse,
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

abc_b_rows <- function(cfg, c1_cfg, cell_rows, profile_ids, seeds, aggregate = FALSE) {
  rows <- list(); traces <- list(); k <- 0L
  state <- if (aggregate) abc_b_new_aggregates(c1_cfg) else NULL
  for (seed in seeds) for (ci in cell_rows) for (profile_id in profile_ids) {
    cell <- c1_cfg$design[ci, , drop = FALSE]; pi <- match(profile_id, c1_cfg$profiles_df$profile_id)
    abc_assert(!is.na(pi), paste("Unknown Module B profile:", profile_id))
    profile <- c1_cfg$profiles_df[pi, , drop = FALSE]
    path <- generate_path(seed, cell, profile, c1_cfg$model$mu0)
    fit <- abc_run_six_arms(path, c(as.list(cell), c1_cfg$model), cfg$module_b$huber_c, trace = !aggregate)
    losses <- score_forecasts(path$y_test, fit$forecasts, path$y_train); contrasts <- abc_b_contrasts(losses)
    if (aggregate) {
      abc_b_update_aggregates(state, ci, pi, contrasts)
    } else {
      for (contrast in rownames(contrasts)) for (metric in colnames(contrasts)) {
        k <- k + 1L
        rows[[k]] <- data.frame(result_level = "PAIRED_PATH", seed = seed, cell_id = cell$cell_id, profile_id = profile_id, metric = metric, contrast = contrast,
                                first_minus_second = contrasts[contrast, metric], path_id = paste(seed, cell$cell_id, profile_id, sep = "::"), stringsAsFactors = FALSE)
      }
      trace <- fit$trace; trace$seed <- seed; trace$cell_id <- cell$cell_id; trace$profile_id <- profile_id
      traces[[length(traces) + 1L]] <- trace
    }
  }
  if (aggregate) {
    list(results = abc_b_finalize_aggregates(state, c1_cfg, cell_rows, profile_ids, cfg),
         trace = data.frame(status = "NOT_RETAINED", reason = "Formal mode uses online sufficient statistics", stringsAsFactors = FALSE))
  } else {
    list(results = do.call(rbind, rows), trace = do.call(rbind, traces))
  }
}

abc_run_module_b <- function(cfg, phase, output_dir) {
  abc_require_phase(phase, cfg)
  c1_cfg <- load_config(cfg$data$c1_config); abc_set_rng(cfg)
  if (identical(phase, "pilot")) {
    cell_rows <- as.integer(unlist(cfg$module_b$pilot_cell_rows)); profile_ids <- unlist(cfg$module_b$pilot_profile_ids); seeds <- as.integer(unlist(cfg$module_b$pilot_seeds))
  } else {
    cell_rows <- seq_len(nrow(c1_cfg$design)); profile_ids <- c1_cfg$profiles_df$profile_id; seeds <- seq_len(as.integer(cfg$module_b$formal_N))
  }
  out <- abc_b_rows(cfg, c1_cfg, cell_rows, profile_ids, seeds, aggregate = identical(phase, "formal"))
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  abc_write_csv(out$results, file.path(output_dir, "MODULE_B_CONTRAST_RESULTS.csv"))
  abc_write_csv(out$trace, file.path(output_dir, "MODULE_B_UPDATE_TRACE.csv"))
  abc_write_csv(data.frame(status = "PASS", message = paste("All requested", phase, "paths completed"), stringsAsFactors = FALSE), file.path(output_dir, "MODULE_B_FAILURE_LOG.csv"))
  invisible(out)
}
