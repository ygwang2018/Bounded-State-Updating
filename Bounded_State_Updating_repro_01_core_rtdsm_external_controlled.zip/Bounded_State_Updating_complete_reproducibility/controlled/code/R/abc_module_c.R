abc_c_factor_matrix <- function(design) {
  factors <- c("n_train", "h", "q", "omega", "p_out", "c")
  matrix <- do.call(cbind, lapply(factors, function(name) {
    values <- sort(unique(design[[name]])); match(design[[name]], values) - 1L
  }))
  colnames(matrix) <- factors
  matrix
}

abc_c_full_rank <- function(design) {
  matrix <- stats::model.matrix(~ factor(n_train) + factor(h) + factor(q) + factor(omega) + factor(p_out) + factor(c), data = design)
  qr(matrix)$rank == ncol(matrix)
}

abc_c_constraints <- function(design) {
  nrow(design) == 12L && all(table(design$n_train) == 6L) && all(table(design$h) == 6L) &&
    all(table(design$q) == 6L) && all(table(design$omega) == 6L) &&
    all(table(factor(design$p_out, levels = c(0.02, 0.05, 0.10))) >= 3L) &&
    all(table(factor(design$c, levels = c(4, 6, 8))) >= 3L) && abc_c_full_rank(design)
}

abc_c_min_distance <- function(indices, factor_matrix) {
  min(stats::dist(factor_matrix[indices, , drop = FALSE], method = "euclidean"))
}

abc_c_tie_order <- function(n, seed) {
  set.seed(as.integer(seed)); sample.int(n)
}

abc_c_strict_improvement_coloring <- function(design, factor_matrix, threshold_squared = 2) {
  certificate <- c(
    `2` = 7, `5` = 11, `17` = 8, `19` = 7, `20` = 7, `22` = 10, `29` = 7, `32` = 8, `34` = 5,
    `36` = 8, `44` = 11, `48` = 3, `50` = 11, `51` = 4, `52` = 5, `54` = 9, `57` = 3, `61` = 5,
    `76` = 1, `79` = 1, `87` = 4, `91` = 10, `92` = 6, `93` = 6, `94` = 1, `107` = 8, `113` = 11,
    `114` = 4, `117` = 9, `118` = 2, `121` = 2, `125` = 9, `129` = 6, `136` = 2, `141` = 4, `144` = 9
  )
  colors <- unname(certificate[as.character(design$cell_id)])
  abc_assert(!anyNA(colors), "Module C maximin upper-bound certificate does not cover the frozen 36 cells.")
  distance_squared <- as.matrix(stats::dist(factor_matrix))^2
  edges <- which(upper.tri(distance_squared) & distance_squared > threshold_squared, arr.ind = TRUE)
  abc_assert(!nrow(edges) || all(colors[edges[, 1L]] != colors[edges[, 2L]]), "Module C maximin upper-bound coloring certificate is invalid.")
  colors
}

abc_c_select_cells <- function(design, cfg, starts = 16L, exchanges = 30L) {
  abc_assert(nrow(design) == 36L, "Module C requires the frozen 36-cell C1 design.")
  x <- abc_c_factor_matrix(design); tie_rank <- order(abc_c_tie_order(nrow(design), cfg$module_c$selection_seed))
  score <- function(index) abc_c_min_distance(index, x)
  better_tie <- function(candidate, incumbent) {
    a <- sort(tie_rank[candidate]); b <- sort(tie_rank[incumbent]); which(a != b)[1L] %||% Inf
    if (identical(a, b)) FALSE else a[which(a != b)[1L]] < b[which(a != b)[1L]]
  }
  best <- NULL; best_score <- -Inf
  set.seed(as.integer(cfg$module_c$selection_seed))
  seeds <- replicate(starts, sample.int(nrow(design), as.integer(cfg$module_c$selection_size)), simplify = FALSE)
  for (initial in seeds) {
    current <- sort(initial)
    for (iteration in seq_len(exchanges)) {
      improved <- FALSE
      for (out in current) for (incoming in setdiff(seq_len(nrow(design)), current)) {
        candidate <- sort(c(setdiff(current, out), incoming)); if (!abc_c_constraints(design[candidate, , drop = FALSE])) next
        candidate_score <- score(candidate); current_score <- if (abc_c_constraints(design[current, , drop = FALSE])) score(current) else -Inf
        if (candidate_score > current_score || (isTRUE(all.equal(candidate_score, current_score, tolerance = 0)) && better_tie(candidate, current))) {
          current <- candidate; improved <- TRUE
        }
      }
      if (!improved) break
    }
    if (!abc_c_constraints(design[current, , drop = FALSE])) next
    current_score <- score(current)
    if (current_score > best_score || (isTRUE(all.equal(current_score, best_score, tolerance = 0)) && (is.null(best) || better_tie(current, best)))) {
      best <- current; best_score <- current_score
    }
  }
  abc_assert(!is.null(best), "Module C deterministic maximin search found no subset satisfying TL28 constraints.")
  strict_improvement_colors <- abc_c_strict_improvement_coloring(design, x, threshold_squared = best_score^2)
  abc_assert(length(unique(strict_improvement_colors)) < as.integer(cfg$module_c$selection_size), "Module C maximin global-optimum upper bound was not established.")
  out <- design[best, , drop = FALSE]
  out$selection_seed <- as.integer(cfg$module_c$selection_seed)
  out$factor_space_min_distance <- best_score
  out$selection_rank <- match(out$cell_id, sort(out$cell_id))
  out$factor_n_train <- x[best, "n_train"]
  out$factor_h <- x[best, "h"]
  out$factor_q <- x[best, "q"]
  out$factor_omega <- x[best, "omega"]
  out$factor_p_out <- x[best, "p_out"]
  out$factor_c <- x[best, "c"]
  out$selection_algorithm <- "DETERMINISTIC_MULTISTART_MAXIMIN_EXCHANGE_WITH_COLORING_UPPER_BOUND"
  out$strictly_better_graph_coloring_size <- length(unique(strict_improvement_colors))
  out$maximin_global_optimum_verified <- TRUE
  out[order(out$cell_id), , drop = FALSE]
}

abc_c_cell_selection <- function(design, cfg, path = NULL) {
  if (!is.null(path) && file.exists(path)) {
    existing <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
    expected <- abc_c_select_cells(design, cfg)
    abc_assert(isTRUE(all.equal(existing, expected, check.attributes = FALSE, tolerance = 1e-14)), "Existing Module C cell selection differs from the deterministic TL28 maximin selection.")
    return(existing)
  }
  abc_c_select_cells(design, cfg)
}

abc_c_three_arm_contrasts <- function(path, parameters) {
  five <- run_five_arms(path, parameters); forecasts <- five$forecasts[, 1:3, drop = FALSE]; colnames(forecasts) <- c("G", "MB", "CB")
  losses <- score_forecasts(path$y_test, forecasts, path$y_train)
  contrasts <- rbind("MB-G" = losses["MB", ] - losses["G", ], "CB-MB" = losses["CB", ] - losses["MB", ], "CB-G" = losses["CB", ] - losses["G", ])
  list(losses = losses, contrasts = contrasts)
}

abc_c_new_aggregates <- function(n_cells, n_profiles, n_grid) {
  dimensions <- c(n_cells, n_profiles, n_grid, 3L, 3L)
  state <- new.env(parent = emptyenv())
  state$n <- array(0L, dim = dimensions[1:3])
  state$mean <- array(0, dim = dimensions)
  state$M2 <- array(0, dim = dimensions)
  state
}

abc_c_update_aggregates <- function(state, cell_index, profile_index, grid_index, contrast_values) {
  values <- t(contrast_values)
  n1 <- state$n[cell_index, profile_index, grid_index] + 1L
  old_mean <- state$mean[cell_index, profile_index, grid_index, , ]
  delta <- values - old_mean
  new_mean <- old_mean + delta / n1
  state$mean[cell_index, profile_index, grid_index, , ] <- new_mean
  state$M2[cell_index, profile_index, grid_index, , ] <- state$M2[cell_index, profile_index, grid_index, , ] + delta * (values - new_mean)
  state$n[cell_index, profile_index, grid_index] <- n1
  invisible(state)
}

abc_c_finalize_aggregates <- function(state, cells, profiles, grid, cfg) {
  metrics <- unlist(cfg$reporting$metrics); contrasts <- unlist(cfg$module_c$contrasts)
  critical <- stats::qnorm(0.5 + as.numeric(cfg$reporting$interval_level) / 2)
  rows <- list(); k <- 0L
  for (ci in seq_len(nrow(cells))) for (pi in seq_along(profiles)) for (gi in seq_len(nrow(grid))) {
    n <- state$n[ci, pi, gi]
    for (mi in seq_along(metrics)) for (ki in seq_along(contrasts)) {
      k <- k + 1L
      variance <- if (n > 1L) state$M2[ci, pi, gi, mi, ki] / (n - 1L) else NA_real_
      mcse <- sqrt(variance / n); mean <- state$mean[ci, pi, gi, mi, ki]
      rows[[k]] <- data.frame(
        result_level = "ONLINE_SUFFICIENT_STATISTICS", cell_id = cells$cell_id[[ci]], profile_id = profiles[[pi]],
        nu = grid$nu[[gi]], P1 = grid$P1[[gi]], H = as.numeric(cfg$module_c$H), metric = metrics[[mi]], contrast = contrasts[[ki]],
        n = n, mean = mean, variance = variance, mcse = mcse, lower_95 = mean - critical * mcse, upper_95 = mean + critical * mcse,
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

abc_run_module_c <- function(cfg, phase, output_dir) {
  abc_require_phase(phase, cfg); c1_cfg <- load_config(cfg$data$c1_config); abc_set_rng(cfg)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  selection_path <- file.path(output_dir, "sensitivity_cell_selection.csv")
  selection <- abc_c_cell_selection(c1_cfg$design, cfg, selection_path)
  if (!file.exists(selection_path)) abc_write_csv(selection, selection_path)
  if (identical(phase, "pilot")) {
    cells <- selection[1L, , drop = FALSE]; profiles <- unlist(cfg$module_c$pilot_profiles); seeds <- as.integer(unlist(cfg$module_c$pilot_seeds)); grid <- do.call(rbind, lapply(cfg$module_c$pilot_grid, as.data.frame))
  } else {
    cells <- selection; profiles <- c1_cfg$profiles_df$profile_id; seeds <- seq_len(as.integer(cfg$module_c$formal_N)); grid <- expand.grid(nu = as.numeric(unlist(cfg$module_c$nu_grid)), P1 = as.numeric(unlist(cfg$module_c$P1_grid)))
  }
  aggregate <- identical(phase, "formal"); rows <- list(); k <- 0L
  state <- if (aggregate) abc_c_new_aggregates(nrow(cells), length(profiles), nrow(grid)) else NULL
  for (seed in seeds) for (ci in seq_len(nrow(cells))) for (pi in seq_along(profiles)) {
    profile_id <- profiles[[pi]]
    cell <- cells[ci, , drop = FALSE]; profile <- c1_cfg$profiles_df[match(profile_id, c1_cfg$profiles_df$profile_id), , drop = FALSE]
    path <- generate_path(seed, cell, profile, c1_cfg$model$mu0)
    for (gi in seq_len(nrow(grid))) {
      parameters <- c(as.list(cell), c1_cfg$model); parameters$nu <- as.numeric(grid$nu[[gi]]); parameters$P1 <- as.numeric(grid$P1[[gi]]); parameters$H <- as.numeric(cfg$module_c$H)
      result <- abc_c_three_arm_contrasts(path, parameters)
      if (aggregate) {
        abc_c_update_aggregates(state, ci, pi, gi, result$contrasts)
      } else {
        for (contrast in rownames(result$contrasts)) for (metric in colnames(result$contrasts)) {
          k <- k + 1L; rows[[k]] <- data.frame(result_level = "PAIRED_PATH", seed = seed, cell_id = cell$cell_id, profile_id = profile_id, nu = parameters$nu, P1 = parameters$P1, H = parameters$H,
            metric = metric, contrast = contrast, first_minus_second = result$contrasts[contrast, metric], path_id = paste(seed, cell$cell_id, profile_id, sep = "::"), stringsAsFactors = FALSE)
        }
      }
    }
  }
  result <- if (aggregate) abc_c_finalize_aggregates(state, cells, profiles, grid, cfg) else do.call(rbind, rows)
  abc_write_csv(result, file.path(output_dir, "MODULE_C_SENSITIVITY_RESULTS.csv"))
  abc_write_csv(data.frame(status = "PASS", message = paste("All requested", phase, "paths completed"), stringsAsFactors = FALSE), file.path(output_dir, "MODULE_C_FAILURE_LOG.csv"))
  invisible(list(results = result, selection = selection))
}
