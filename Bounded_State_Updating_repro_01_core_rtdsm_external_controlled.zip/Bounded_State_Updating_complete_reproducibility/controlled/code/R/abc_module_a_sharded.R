# Deterministic, restartable execution layer for the frozen Module A design.
# Scientific fitting, contamination, metrics, and RNG functions remain in
# abc_module_a.R; this file only schedules those calls and validates coverage.

abc_a_frequency_label <- function(frequency) {
  ifelse(frequency == 1L, "Yearly", ifelse(frequency == 4L, "Quarterly", ifelse(frequency == 12L, "Monthly", "Other")))
}

abc_a_build_manifest <- function(cfg, m3 = publication_load_m3(), sample_table = abc_a_select_series(m3, cfg)) {
  methods <- names(publication_method_panel())
  series <- data.frame(series_index = seq_along(m3), series_id = names(m3),
    frequency = vapply(m3, function(x) as.integer(stats::frequency(x$x)), integer(1L)), stringsAsFactors = FALSE)
  expand_tasks <- function(stage, indices, draws, amplitudes, signs) {
    grid <- expand.grid(series_index = as.integer(indices), draw_id = as.integer(draws),
      amplitude = as.numeric(amplitudes), sign = as.integer(signs), method = methods,
      KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
    grid$stage <- stage
    grid
  }
  clean <- expand_tasks("clean", seq_along(m3), 0L, 0, 0L)
  a1 <- expand_tasks("A1", seq_along(m3), as.integer(cfg$module_a$draw1_id),
    unlist(cfg$module_a$amplitudes), unlist(cfg$module_a$signs))
  a2 <- expand_tasks("A2", sample_table$series_index, unlist(cfg$module_a$resample_draw_ids),
    unlist(cfg$module_a$amplitudes), unlist(cfg$module_a$signs))
  out <- rbind(clean, a1, a2)
  out <- out[order(match(out$stage, c("clean", "A1", "A2")), out$series_index,
    out$draw_id, out$amplitude, out$sign, match(out$method, methods)), , drop = FALSE]
  out <- merge(out, series, by = "series_index", all.x = TRUE, sort = FALSE)
  out <- out[order(match(out$stage, c("clean", "A1", "A2")), out$series_index,
    out$draw_id, out$amplitude, out$sign, match(out$method, methods)), , drop = FALSE]
  out$frequency_group <- abc_a_frequency_label(out$frequency)
  contaminated <- out$stage != "clean"
  out$scientific_seed <- NA_integer_
  out$scientific_seed[contaminated] <- mapply(abc_a_seed, out$series_index[contaminated], out$draw_id[contaminated], MoreArgs = list(cfg = cfg))
  out$contamination_position <- NA_character_
  keys <- unique(out[contaminated, c("series_index", "draw_id")])
  position_map <- setNames(vapply(seq_len(nrow(keys)), function(i) {
    paste(abc_a_positions(length(m3[[keys$series_index[[i]]]]$x), keys$series_index[[i]], keys$draw_id[[i]], cfg), collapse = ";")
  }, character(1L)), paste(keys$series_index, keys$draw_id, sep = "::"))
  out$contamination_position[contaminated] <- position_map[paste(out$series_index[contaminated], out$draw_id[contaminated], sep = "::")]
  out$condition_id <- ifelse(contaminated,
    sprintf("%s:draw%s:a%s:s%s", out$stage, out$draw_id, out$amplitude, out$sign), "clean")
  out$expected_output_identity <- paste(out$stage, out$series_id, out$draw_id, out$amplitude, out$sign, out$method, sep = "::")
  out$task_id <- sprintf("A%06d", seq_len(nrow(out)))
  out <- out[, c("task_id", "stage", "series_id", "series_index", "frequency", "frequency_group", "method",
    "amplitude", "sign", "draw_id", "contamination_position", "scientific_seed", "condition_id", "expected_output_identity")]
  counts <- table(out$stage)
  abc_assert(nrow(out) == 324084L && counts[["clean"]] == 12012L && counts[["A1"]] == 72072L && counts[["A2"]] == 240000L,
    "Module A manifest does not match frozen 12,012/72,072/240,000 counts.")
  out
}

abc_a_add_shards <- function(manifest, profile_summary, target_minutes = 60) {
  key <- paste(profile_summary$method, profile_summary$frequency_group, sep = "::")
  weights <- setNames(profile_summary$median_wall_sec, key)
  global <- stats::median(profile_summary$median_wall_sec[is.finite(profile_summary$median_wall_sec) & profile_summary$median_wall_sec > 0])
  manifest$estimated_runtime_weight <- weights[paste(manifest$method, manifest$frequency_group, sep = "::")]
  manifest$estimated_runtime_weight[!is.finite(manifest$estimated_runtime_weight) | manifest$estimated_runtime_weight <= 0] <- global
  n_shards <- max(1L, as.integer(ceiling(sum(manifest$estimated_runtime_weight) / (60 * target_minutes))))
  load <- numeric(n_shards); assignment <- integer(nrow(manifest))
  # Stable longest-processing-time allocation, with task_id as the tie breaker.
  ordering <- order(-manifest$estimated_runtime_weight, manifest$task_id)
  for (i in ordering) {
    shard <- which.min(load)
    assignment[[i]] <- shard
    load[[shard]] <- load[[shard]] + manifest$estimated_runtime_weight[[i]]
  }
  manifest$shard_id <- sprintf("%05d", assignment)
  manifest
}

abc_a_run_task <- function(task, cfg, m3, methods = publication_method_panel()) {
  i <- as.integer(task$series_index); item <- m3[[i]]
  if (identical(as.character(task$stage), "clean")) {
    metadata <- list(study_component = "CLEAN_REFERENCE", draw_id = 0L, seed = NA_integer_, amplitude = 0,
      sign = 0L, condition = "clean", position_set_id = NA_character_, contamination_positions = NA_character_)
    y <- as.numeric(item$x)
  } else {
    contamination <- abc_a_condition(as.numeric(item$x), task$series_id, i, as.integer(task$draw_id),
      as.numeric(task$amplitude), as.integer(task$sign), cfg)
    expected <- paste(contamination$positions, collapse = ";")
    abc_assert(identical(expected, as.character(task$contamination_position)), paste("Frozen position mismatch for", task$task_id))
    y <- contamination$y
    metadata <- list(study_component = if (task$stage == "A1") "A1_DRAW1" else "A2_POSITION_DRAWS",
      draw_id = as.integer(task$draw_id), seed = as.integer(task$scientific_seed), amplitude = as.numeric(task$amplitude),
      sign = as.integer(task$sign), condition = sprintf("dispersed_%s_a%s", if (task$sign > 0) "positive" else "negative", task$amplitude),
      position_set_id = contamination$manifest$position_set_id[[1L]], contamination_positions = expected)
  }
  row <- abc_a_method_rows(item, task$series_id, i, y, methods[as.character(task$method)], metadata, clean_reference = NULL)
  row$task_id <- task$task_id
  row$expected_output_identity <- task$expected_output_identity
  row[, c("task_id", "expected_output_identity", setdiff(names(row), c("task_id", "expected_output_identity")))]
}

abc_a_run_shard <- function(manifest, shard_id, cfg, output_dir, m3 = publication_load_m3()) {
  shard_id <- sprintf("%05d", as.integer(shard_id)); tasks <- manifest[manifest$shard_id == shard_id, , drop = FALSE]
  abc_assert(nrow(tasks) > 0L, paste("Unknown/empty shard", shard_id))
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  final <- file.path(output_dir, sprintf("A_%s.csv", shard_id))
  if (file.exists(final)) return(invisible(list(status = "SKIPPED_COMPLETE", path = final)))
  temporary <- paste0(final, ".tmp")
  if (file.exists(temporary)) unlink(temporary)
  result <- do.call(rbind, lapply(seq_len(nrow(tasks)), function(i) abc_a_run_task(tasks[i, , drop = FALSE], cfg, m3)))
  abc_write_csv(result, temporary)
  abc_assert(file.rename(temporary, final), paste("Atomic finalize failed for", final))
  invisible(list(status = "COMPLETED", path = final, rows = nrow(result)))
}

abc_a_validate_coverage <- function(manifest, results) {
  expected <- manifest$task_id; observed <- results$task_id
  missing <- setdiff(expected, observed); unexpected <- setdiff(observed, expected)
  duplicates <- unique(observed[duplicated(observed)])
  matched_stage <- manifest$stage[match(observed, expected)]
  stage_counts <- table(factor(matched_stage, levels = c("clean", "A1", "A2")))
  pass <- !length(missing) && !length(unexpected) && !length(duplicates) && length(observed) == 324084L &&
    identical(as.integer(stage_counts), c(12012L, 72072L, 240000L))
  list(status = if (pass) "PASS" else "DO_NOT_AGGREGATE", expected_total_task_id = length(expected),
    observed_total_task_id = length(observed), missing_task_id = missing, duplicate_task_id = duplicates,
    unexpected_task_id = unexpected, stage_counts = stage_counts)
}

abc_a_aggregate_shards <- function(manifest, shard_dir, output_path) {
  files <- sort(list.files(shard_dir, pattern = "^A_[0-9]+\\.csv$", full.names = TRUE))
  abc_assert(length(files) > 0L, "No completed Module A shard files found.")
  results <- do.call(rbind, lapply(files, utils::read.csv, stringsAsFactors = FALSE, check.names = FALSE))
  coverage <- abc_a_validate_coverage(manifest, results)
  abc_assert(identical(coverage$status, "PASS"), sprintf("DO_NOT_AGGREGATE: missing=%d duplicate=%d unexpected=%d",
    length(coverage$missing_task_id), length(coverage$duplicate_task_id), length(coverage$unexpected_task_id)))
  clean <- results[results$study_component == "CLEAN_REFERENCE", c("series_index", "method_id", "MASE", "RMSSE", "sMAPE")]
  names(clean)[3:5] <- paste0("reference_", names(clean)[3:5])
  index <- match(paste(results$series_index, results$method_id), paste(clean$series_index, clean$method_id))
  for (metric in c("MASE", "RMSSE", "sMAPE")) {
    reference <- clean[[paste0("reference_", metric)]][index]
    results[[paste0("clean_", metric)]] <- reference
    results[[paste0("degradation_", metric)]] <- results[[metric]] - reference
  }
  results <- results[match(manifest$task_id, results$task_id), , drop = FALSE]
  abc_write_csv(results, output_path)
  invisible(list(results = results, coverage = coverage))
}
