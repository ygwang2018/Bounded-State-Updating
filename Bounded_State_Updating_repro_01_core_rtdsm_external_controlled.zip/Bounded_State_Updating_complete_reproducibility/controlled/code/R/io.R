rsto_assert <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
  invisible(TRUE)
}

rsto_require_namespace <- function(package) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop(sprintf("Required package is unavailable: %s", package), call. = FALSE)
  }
  invisible(TRUE)
}

rsto_sha256_file <- function(path) {
  rsto_require_namespace("digest")
  rsto_assert(file.exists(path), sprintf("Missing file: %s", path))
  tolower(digest::digest(file = path, algo = "sha256", serialize = FALSE))
}

rsto_verify_core_archive <- function(path = rsto_archive_path(), config = rsto_publication_config()) {
  observed <- rsto_sha256_file(path)
  rsto_assert(
    identical(observed, config$archive_sha256),
    sprintf("Core archive hash mismatch: observed %s", observed)
  )
  invisible(observed)
}

rsto_normalize_csv_text <- function(value) {
  value <- as.character(value)
  missing <- is.na(value)
  out <- value
  present <- !missing
  out[present] <- gsub("\\", "\\\\", out[present], fixed = TRUE)
  out[present] <- gsub("\r\n", "\\n", out[present], fixed = TRUE)
  out[present] <- gsub("\n", "\\n", out[present], fixed = TRUE)
  out[present] <- gsub("\r", "\\n", out[present], fixed = TRUE)
  out[present] <- gsub("\t", "\\t", out[present], fixed = TRUE)
  out[missing] <- NA_character_
  out
}

rsto_normalize_csv_frame <- function(data) {
  out <- data
  for (name in names(out)) {
    if (is.factor(out[[name]])) out[[name]] <- as.character(out[[name]])
    if (is.character(out[[name]])) out[[name]] <- rsto_normalize_csv_text(out[[name]])
  }
  out
}

rsto_write_csv <- function(data, path, row.names = FALSE, normalize_text = TRUE) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  payload <- if (isTRUE(normalize_text)) rsto_normalize_csv_frame(data) else data
  utils::write.csv(payload, path, row.names = row.names, na = "", fileEncoding = "UTF-8")
  invisible(path)
}

rsto_append_csv <- function(data, path, normalize_text = TRUE) {
  payload <- if (isTRUE(normalize_text)) rsto_normalize_csv_frame(data) else data
  utils::write.table(
    payload, path, append = TRUE, sep = ",", row.names = FALSE, col.names = FALSE,
    na = "", qmethod = "double", fileEncoding = "UTF-8"
  )
  invisible(path)
}

rsto_read_csv <- function(path) {
  utils::read.csv(
    path, check.names = FALSE, stringsAsFactors = FALSE,
    fileEncoding = "UTF-8", na.strings = ""
  )
}

rsto_copy_tree <- function(source, destination) {
  files <- list.files(source, recursive = TRUE, full.names = TRUE, include.dirs = FALSE)
  rsto_assert(dir.exists(source), sprintf("Missing staging source: %s", source))
  for (file in files) {
    relative <- substring(file, nchar(source) + 2L)
    target <- file.path(destination, relative)
    dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
    rsto_assert(file.copy(file, target, overwrite = TRUE), sprintf("Cannot stage %s", relative))
  }
  invisible(destination)
}

rsto_extract_nested_zip <- function(outer_dir, relative_zip, destination) {
  archive <- file.path(outer_dir, relative_zip)
  rsto_assert(file.exists(archive), sprintf("Nested archive is missing: %s", relative_zip))
  dir.create(destination, recursive = TRUE, showWarnings = FALSE)
  utils::unzip(archive, exdir = destination)
  invisible(destination)
}

rsto_stage_frozen_oracle <- function(root = rsto_package_root(), need = c("runner"),
                                     archive_path = rsto_archive_path(),
                                     config = rsto_publication_config()) {
  need <- unique(match.arg(need, c("runner", "c1", "m3"), several.ok = TRUE))
  rsto_verify_core_archive(archive_path, config)
  stage <- file.path(root, ".work", "frozen_oracle")
  outer <- file.path(stage, "core")
  if (!dir.exists(outer)) {
    dir.create(outer, recursive = TRUE, showWarnings = FALSE)
    utils::unzip(archive_path, exdir = outer)
  }
  core <- file.path(outer, config$archive_root)
  rsto_assert(dir.exists(core), "Core archive layout differs from the frozen authority.")
  result <- list(root = stage, core = core)

  if ("runner" %in% need) {
    runner <- file.path(stage, "runner")
    if (!dir.exists(runner)) {
      runner_unpack <- file.path(stage, "runner_unpack")
      rsto_extract_nested_zip(core, config$runner_archive, runner_unpack)
      runner_root <- file.path(runner_unpack, "RST_O_CODE_CHAT17_FINAL_RUNNER_ARCHIVE_RECOVERY_TO_TOTAL_LEAD17_20260720")
      fix2 <- list.files(runner_root, pattern = paste0("^", config$fix2_archive, "$"), full.names = TRUE)
      fix3 <- list.files(runner_root, pattern = paste0("^", config$fix3_archive, "$"), full.names = TRUE)
      rsto_assert(length(fix2) == 1L && length(fix3) == 1L, "Fix2/Fix3-lite archives are not uniquely available.")
      fix2_dir <- file.path(stage, "fix2")
      fix3_dir <- file.path(stage, "fix3")
      utils::unzip(fix2, exdir = fix2_dir)
      utils::unzip(fix3, exdir = fix3_dir)
      dir.create(runner, recursive = TRUE, showWarnings = FALSE)
      rsto_copy_tree(fix2_dir, runner)
      rsto_copy_tree(fix3_dir, runner)
      files <- list.files(runner, recursive = TRUE, full.names = TRUE, include.dirs = FALSE)
      suppressWarnings(Sys.chmod(files, mode = "0444"))
    }
    result$runner <- runner
  }
  if ("c1" %in% need) {
    c1 <- file.path(stage, "c1")
    if (!dir.exists(c1)) rsto_extract_nested_zip(core, config$c1_archive, c1)
    result$c1 <- c1
  }
  if ("m3" %in% need) {
    m3 <- file.path(stage, "m3")
    if (!dir.exists(m3)) rsto_extract_nested_zip(core, config$m3_archive, m3)
    result$m3 <- m3
  }
  result
}

rsto_load_frozen_oracle <- function(stage) {
  code <- file.path(stage$runner, "formal", "code")
  env <- new.env(parent = baseenv())
  for (file in c(
    "formal_utils.R", "formal_condition_generator.R", "compute_frozen_metrics.R",
    "formal_method_interface.R", "aggregate_frozen_estimands.R",
    "bootstrap_frozen_estimands.R"
  )) {
    sys.source(file.path(code, file), envir = env)
  }
  # The frozen adapter normalizes its runtime root before sourcing it.  On this
  # Windows R build, resolving a subst path expands it to an unrepresentable
  # Unicode physical path.  This loader shim preserves the supplied stage path
  # (which has already been existence-checked) and changes no frozen method,
  # parameter, calculation, or result object.
  env$formal_load_frozen_methods <- function(stage_root) {
    authority_dir <- file.path(stage_root, "formal", "authority")
    adapter_path <- file.path(authority_dir, "n1_method_adapters.R")
    stg_path <- file.path(authority_dir, "stg_author_isolated.R")
    formal_assert(file.exists(adapter_path) && file.exists(stg_path), "frozen adapter authority is incomplete")
    adapter_env <- new.env(parent = baseenv())
    adapter_env$sys.source <- sys.source
    adapter_env$file.exists <- file.exists
    adapter_env$normalizePath <- function(path, winslash = "/", mustWork = FALSE) {
      if (isTRUE(mustWork) && !file.exists(path)) stop("path does not exist", call. = FALSE)
      as.character(path)
    }
    adapter_env$dirname <- dirname
    adapter_env$file.path <- file.path
    adapter_env$new.env <- new.env
    adapter_env$exists <- exists
    adapter_env$get <- get
    adapter_env$list <- list
    adapter_env$as.numeric <- as.numeric
    adapter_env$as.integer <- as.integer
    adapter_env$requireNamespace <- requireNamespace
    adapter_env$withCallingHandlers <- withCallingHandlers
    adapter_env$tryCatch <- tryCatch
    adapter_env$conditionMessage <- conditionMessage
    adapter_env$warning <- warning
    adapter_env$stop <- stop
    sys.source(adapter_path, envir = adapter_env)
    formal_assert(exists("n1_make_method_adapters", envir = adapter_env, inherits = FALSE), "frozen adapter does not expose n1_make_method_adapters")
    methods <- get("n1_make_method_adapters", envir = adapter_env, inherits = FALSE)(file.path(authority_dir, "frozen_runtime"), stg_path)
    expected <- c("STG", "IQR_ST", "RSTO_NU5", "ROBETS")
    formal_assert(identical(names(methods), expected), "frozen adapter exposes an unexpected method panel")
    methods
  }
  environment(env$formal_load_frozen_methods) <- env
  env
}

rsto_canonical_m3_paths <- function(stage) {
  root <- file.path(stage$m3, "canonical")
  list(raw = file.path(root, "raw"), summary = file.path(root, "summary"))
}

rsto_read_canonical_m3 <- function(stage, file, kind = c("raw", "summary")) {
  kind <- match.arg(kind)
  paths <- rsto_canonical_m3_paths(stage)
  rsto_read_csv(file.path(paths[[kind]], file))
}

rsto_read_canonical_c1 <- function(stage, file) {
  rsto_read_csv(file.path(stage$c1, file))
}

rsto_write_session_info <- function(path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  con <- file(path, open = "wt", encoding = "UTF-8")
  on.exit(close(con), add = TRUE)
  writeLines(capture.output(sessionInfo()), con = con, useBytes = TRUE)
  invisible(path)
}
