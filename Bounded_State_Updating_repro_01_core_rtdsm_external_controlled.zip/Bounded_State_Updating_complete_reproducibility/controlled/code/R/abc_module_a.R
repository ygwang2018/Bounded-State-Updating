abc_a_seed <- function(series_index, draw_id, cfg) {
  as.integer(cfg$module_a$seed_base + cfg$module_a$seed_increment * as.integer(series_index) + as.integer(draw_id))
}

abc_a_positions <- function(n_train, series_index, draw_id, cfg) {
  eligible <- seq.int(as.integer(cfg$module_a$eligible_start), as.integer(n_train))
  abc_assert(length(eligible) >= 1L, "Module A training series has no eligible contamination position.")
  n_selected <- max(1L, ceiling(as.numeric(cfg$module_a$p_out) * length(eligible)))
  set.seed(abc_a_seed(series_index, draw_id, cfg))
  sort(sample(eligible, n_selected, replace = FALSE))
}

abc_a_condition <- function(y_clean, series_id, series_index, draw_id, amplitude, sign, cfg) {
  scale <- max(stats::sd(y_clean), stats::IQR(y_clean, type = 7) / 1.349, as.numeric(cfg$module_a$scale_floor), na.rm = TRUE)
  positions <- abc_a_positions(length(y_clean), series_index, draw_id, cfg)
  y <- as.numeric(y_clean)
  original <- y[positions]
  y[positions] <- original + as.numeric(sign) * as.numeric(amplitude) * scale
  condition <- sprintf("dispersed_%s_a%s", if (sign > 0) "positive" else "negative", amplitude)
  manifest <- data.frame(
    series_id = as.character(series_id), series_index = as.integer(series_index), draw_id = as.integer(draw_id),
    seed = abc_a_seed(series_index, draw_id, cfg), amplitude = as.numeric(amplitude), sign = as.integer(sign),
    condition = condition, position = as.integer(positions), n_train = length(y_clean), training_reference_scale = scale,
    original_value = original, contaminated_value = y[positions],
    position_set_id = paste(series_index, draw_id, paste(positions, collapse = "-"), sep = "::"), stringsAsFactors = FALSE
  )
  list(y = y, manifest = manifest, raw_domain_crossing = any(y <= 0), scale = scale, positions = positions)
}

abc_a_strata <- function(m3) {
  frequency <- vapply(m3, function(item) as.integer(stats::frequency(item$x)), integer(1L))
  n_train <- vapply(m3, function(item) length(item$x), integer(1L))
  quartile <- integer(length(m3))
  for (f in unique(frequency)) {
    index <- which(frequency == f)
    ranked <- rank(n_train[index], ties.method = "first")
    quartile[index] <- pmin(4L, floor((ranked - 1L) * 4L / length(index)) + 1L)
  }
  data.frame(series_index = seq_along(m3), series_id = names(m3), frequency = frequency, n_train = n_train,
             length_quartile = quartile, stratum = paste(frequency, quartile, sep = "::"), stringsAsFactors = FALSE)
}

abc_largest_remainder_allocation <- function(counts, total, minimum) {
  abc_assert(total <= sum(counts), "Requested Module A sample exceeds the M3 population.")
  strata <- names(counts)
  allocation <- pmin(as.integer(counts), as.integer(minimum))
  remaining <- as.integer(total - sum(allocation))
  abc_assert(remaining >= 0L, "Minimum Module A stratum allocation exceeds the target sample size.")
  capacity <- as.integer(counts) - allocation
  if (remaining > 0L) {
    weights <- as.numeric(counts) / sum(counts)
    quota <- remaining * weights
    base <- pmin(floor(quota), capacity)
    allocation <- allocation + base
    remaining <- as.integer(total - sum(allocation))
    remainders <- quota - floor(quota)
    while (remaining > 0L) {
      eligible <- which(allocation < counts)
      order_index <- eligible[order(-remainders[eligible], strata[eligible])]
      take <- head(order_index, remaining)
      allocation[take] <- allocation[take] + 1L
      remaining <- as.integer(total - sum(allocation))
      remainders[take] <- -Inf
      if (!length(take)) stop("Cannot complete Module A largest-remainder allocation.", call. = FALSE)
    }
  }
  stats::setNames(as.integer(allocation), strata)
}

abc_a_select_series <- function(m3, cfg) {
  strata <- abc_a_strata(m3)
  counts <- table(strata$stratum)
  allocation <- abc_largest_remainder_allocation(counts, as.integer(cfg$module_a$sample_size), as.integer(cfg$module_a$minimum_per_nonempty_stratum))
  set.seed(as.integer(cfg$module_a$sample_seed))
  selected <- unlist(lapply(names(allocation), function(stratum) {
    candidates <- strata$series_index[strata$stratum == stratum]
    sample(candidates, allocation[[stratum]], replace = FALSE)
  }), use.names = FALSE)
  out <- strata[match(sort(selected), strata$series_index), , drop = FALSE]
  out$selection_seed <- as.integer(cfg$module_a$sample_seed)
  out
}

abc_a_series_sample <- function(m3, cfg, path = NULL) {
  if (!is.null(path) && file.exists(path)) {
    existing <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
    expected <- abc_a_select_series(m3, cfg)
    abc_assert(isTRUE(all.equal(existing, expected, check.attributes = FALSE, tolerance = 1e-14)), "Existing Module A stratified sample differs from the deterministic TL28 selection.")
    return(existing)
  }
  abc_a_select_series(m3, cfg)
}

abc_a_transformed_crossing <- function(y, horizon, frequency) {
  tryCatch(any(publication_author_seasonal_bundle(y, horizon, frequency)$y_sa <= 0), error = function(e) NA)
}

abc_a_method_rows <- function(item, series_id, series_index, y_input, methods, metadata, clean_reference = NULL) {
  frequency <- as.integer(stats::frequency(item$x))
  horizon <- as.integer(item$h)
  y_clean <- as.numeric(item$x)
  y_test <- as.numeric(item$xx)
  transformed_crossing <- abc_a_transformed_crossing(y_input, horizon, frequency)
  rows <- lapply(names(methods), function(method_id) {
    fit <- publication_run_method(methods[[method_id]], y_input, horizon, frequency)
    metrics <- publication_compute_metrics(y_clean, y_test, fit$forecast, frequency)
    clean <- if (is.null(clean_reference)) NULL else clean_reference[clean_reference$method_id == method_id, , drop = FALSE]
    data.frame(
      series_id = series_id, series_index = series_index, frequency = frequency, n_train = length(y_clean), horizon = horizon,
      study_component = metadata$study_component, draw_id = metadata$draw_id, seed = metadata$seed,
      amplitude = metadata$amplitude, sign = metadata$sign, condition = metadata$condition,
      position_set_id = metadata$position_set_id, contamination_positions = metadata$contamination_positions,
      raw_domain_crossing = any(y_input <= 0), transformed_domain_crossing = transformed_crossing, method_id = method_id,
      MASE = metrics$MASE, RMSSE = metrics$RMSSE, sMAPE = metrics$sMAPE,
      clean_MASE = if (is.null(clean)) metrics$MASE else clean$MASE,
      clean_RMSSE = if (is.null(clean)) metrics$RMSSE else clean$RMSSE,
      clean_sMAPE = if (is.null(clean)) metrics$sMAPE else clean$sMAPE,
      degradation_MASE = if (is.null(clean)) 0 else metrics$MASE - clean$MASE,
      degradation_RMSSE = if (is.null(clean)) 0 else metrics$RMSSE - clean$RMSSE,
      degradation_sMAPE = if (is.null(clean)) 0 else metrics$sMAPE - clean$sMAPE,
      MASE_denominator = metrics$MASE_denominator, RMSSE_denominator = metrics$RMSSE_denominator,
      actual_values = paste(format(y_test, digits = 17, scientific = FALSE, trim = TRUE), collapse = ";"),
      forecast_values = paste(format(as.numeric(fit$forecast), digits = 17, scientific = FALSE, trim = TRUE), collapse = ";"),
      forecast_length = length(fit$forecast),
      forecast_finite = all(is.finite(fit$forecast)), method_success = fit$method_success, fallback_used = fit$fallback_used,
      fallback_type = fit$fallback_type, warning_observed = fit$warning_observed, warning_class = fit$warning_class,
      warning_message = fit$warning_message, error_class = fit$error_class, error_message = fit$error_message,
      optimizer_status = fit$optimizer_status, q_endpoint_status = fit$q_endpoint_status,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

abc_a_clean_reference <- function(item, series_id, series_index, methods) {
  metadata <- list(study_component = "CLEAN_REFERENCE", draw_id = 0L, seed = NA_integer_, amplitude = 0, sign = 0L,
                   condition = "clean", position_set_id = NA_character_, contamination_positions = NA_character_)
  abc_a_method_rows(item, series_id, series_index, as.numeric(item$x), methods, metadata)
}

abc_a_output_row <- function(item, series_id, series_index, study_component, draw_id, amplitude, sign, methods, cfg, clean_reference) {
  y_clean <- as.numeric(item$x)
  contamination <- abc_a_condition(y_clean, series_id, series_index, draw_id, amplitude, sign, cfg)
  contamination$manifest$study_component <- study_component
  metadata <- list(
    study_component = study_component, draw_id = as.integer(draw_id), seed = abc_a_seed(series_index, draw_id, cfg),
    amplitude = as.numeric(amplitude), sign = as.integer(sign),
    condition = sprintf("dispersed_%s_a%s", if (sign > 0) "positive" else "negative", amplitude),
    position_set_id = contamination$manifest$position_set_id[[1L]], contamination_positions = paste(contamination$positions, collapse = ";")
  )
  list(results = abc_a_method_rows(item, series_id, series_index, contamination$y, methods, metadata, clean_reference), manifest = contamination$manifest)
}

abc_run_module_a <- function(cfg, phase, output_dir) {
  abc_require_phase(phase, cfg)
  m3 <- publication_load_m3()
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  sample_path <- file.path(output_dir, "stratified_series_sample.csv")
  sample_table <- abc_a_series_sample(m3, cfg, sample_path)
  if (!file.exists(sample_path)) abc_write_csv(sample_table, sample_path)
  pilot_indices <- as.integer(unlist(cfg$module_a$pilot_series_indices))
  amplitudes <- if (identical(phase, "pilot")) as.numeric(unlist(cfg$module_a$pilot_amplitudes)) else as.numeric(unlist(cfg$module_a$amplitudes))
  signs <- if (identical(phase, "pilot")) as.numeric(unlist(cfg$module_a$pilot_signs)) else as.numeric(unlist(cfg$module_a$signs))
  draw1 <- as.integer(cfg$module_a$draw1_id)
  a1_indices <- if (identical(phase, "pilot")) pilot_indices else seq_along(m3)
  a2_indices <- if (identical(phase, "pilot")) pilot_indices else as.integer(sample_table$series_index)
  a2_draws <- if (identical(phase, "pilot")) as.integer(unlist(cfg$module_a$pilot_draw_ids)) else as.integer(unlist(cfg$module_a$resample_draw_ids))
  methods <- publication_method_panel()
  clean_indices <- sort(unique(c(a1_indices, a2_indices)))
  clean <- lapply(clean_indices, function(i) abc_a_clean_reference(m3[[i]], names(m3)[[i]], i, methods))
  names(clean) <- as.character(clean_indices)
  outputs <- clean; manifests <- list(); k <- length(outputs)
  plans <- list(A1_DRAW1 = list(indices = a1_indices, draws = draw1), A2_POSITION_DRAWS = list(indices = a2_indices, draws = a2_draws))
  for (study_component in names(plans)) for (i in plans[[study_component]]$indices) for (draw_id in plans[[study_component]]$draws) for (amplitude in amplitudes) for (sign in signs) {
    k <- k + 1L
    one <- abc_a_output_row(m3[[i]], names(m3)[[i]], i, study_component, draw_id, amplitude, sign, methods, cfg, clean[[as.character(i)]])
    outputs[[k]] <- one$results; manifests[[k]] <- one$manifest
  }
  result <- do.call(rbind, outputs); manifest <- do.call(rbind, manifests)
  abc_write_csv(result, file.path(output_dir, "MODULE_A_RESULTS.csv"))
  abc_write_csv(manifest, file.path(output_dir, "MODULE_A_CONTAMINATION_MANIFEST.csv"))
  failure_log <- result[, c("series_id", "series_index", "study_component", "draw_id", "condition", "method_id", "method_success", "fallback_used", "fallback_type", "warning_observed", "warning_class", "warning_message", "error_class", "error_message")]
  failure_log$status <- ifelse(failure_log$method_success & !failure_log$fallback_used, "PASS", "FAIL")
  abc_write_csv(failure_log, file.path(output_dir, "MODULE_A_FAILURE_LOG.csv"))
  invisible(list(results = result, manifest = manifest, sample = sample_table))
}
