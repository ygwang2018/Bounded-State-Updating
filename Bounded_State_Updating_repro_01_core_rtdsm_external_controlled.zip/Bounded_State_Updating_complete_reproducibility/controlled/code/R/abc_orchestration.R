abc_assert <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
  invisible(TRUE)
}

abc_read_config <- function(path = file.path("config", "abc_config.yml")) {
  abc_assert(requireNamespace("yaml", quietly = TRUE), "The yaml package is required.")
  cfg <- yaml::read_yaml(path)
  required <- c("protocol_id", "phase_authorization", "formal_run_authorized", "data", "rng", "module_a", "module_b", "module_c", "reporting", "outputs", "workers")
  abc_assert(!length(setdiff(required, names(cfg))), "ABC config is missing a required top-level field.")
  abc_assert(cfg$phase_authorization %in% c("pilot_only", "formal_authorized"), "ABC phase_authorization is invalid.")
  abc_assert(identical(cfg$formal_run_authorized, identical(cfg$phase_authorization, "formal_authorized")), "ABC authorization fields are inconsistent.")
  abc_assert(identical(as.numeric(unlist(cfg$module_a$amplitudes)), c(2, 4, 6)), "Module A amplitudes differ from TL28.")
  abc_assert(identical(as.numeric(unlist(cfg$module_a$signs)), c(-1, 1)), "Module A signs differ from TL28.")
  abc_assert(isTRUE(all.equal(as.numeric(cfg$module_b$huber_c), 1.345, tolerance = 0)), "Module B Huber c differs from TL28.")
  abc_assert(identical(as.numeric(unlist(cfg$module_c$nu_grid)), c(3, 5, 8, 15)), "Module C nu grid differs from TL28.")
  abc_assert(identical(as.numeric(unlist(cfg$module_c$P1_grid)), c(100, 10000, 1000000)), "Module C P1 grid differs from TL28.")
  cfg
}

abc_set_rng <- function(cfg) {
  do.call(RNGkind, list(kind = cfg$rng$kind, normal.kind = cfg$rng$normal_kind, sample.kind = cfg$rng$sample_kind))
  invisible(TRUE)
}

abc_root <- function(start = getwd()) {
  configured <- Sys.getenv("RSTO_PUBLICATION_ROOT", unset = "")
  if (nzchar(configured) && file.exists(file.path(configured, "run_all.R"))) return(normalizePath(configured, winslash = "/"))
  current <- normalizePath(start, winslash = "/", mustWork = TRUE)
  repeat {
    if (file.exists(file.path(current, "run_all.R")) && file.exists(file.path(current, "config", "abc_config.yml"))) return(current)
    parent <- dirname(current)
    if (identical(parent, current)) break
    current <- parent
  }
  stop("Cannot locate the RST-O ABC execution root.", call. = FALSE)
}

abc_source_kernels <- function(root = abc_root()) {
  Sys.setenv(RSTO_PUBLICATION_ROOT = root)
  for (file in c("config/config.R", "R/io.R", "R/model.R", "R/evaluation.R", "R/experiments.R", "R/c1_simulation.R", "R/c1_publication.R")) {
    source(file.path(root, file), local = .GlobalEnv)
  }
  invisible(TRUE)
}

abc_output_dir <- function(cfg, phase, module = NULL, root = abc_root()) {
  base <- file.path(root, cfg$outputs$root, phase)
  if (is.null(module)) base else file.path(base, cfg$outputs[[paste0("module_", tolower(module))]])
}

abc_write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  invisible(path)
}

abc_parse_cli <- function(args = commandArgs(trailingOnly = TRUE)) {
  out <- list(phase = NULL, module = NULL, summarize = FALSE, verify = FALSE, output_dir = NULL)
  i <- 1L
  while (i <= length(args)) {
    token <- args[[i]]
    if (token %in% c("--summarize", "--verify")) {
      out[[sub("^--", "", token)]] <- TRUE
      i <- i + 1L
    } else if (token %in% c("--phase", "--module", "--output-dir")) {
      abc_assert(i < length(args), paste("Missing value for", token))
      key <- gsub("-", "_", sub("^--", "", token))
      out[[key]] <- args[[i + 1L]]
      i <- i + 2L
    } else {
      stop("Unknown ABC argument: ", token, call. = FALSE)
    }
  }
  abc_assert(!is.null(out$phase) && out$phase %in% c("pilot", "formal"), "Use --phase pilot|formal.")
  if (!is.null(out$module)) out$module <- toupper(out$module)
  abc_assert(is.null(out$module) || out$module %in% c("A", "B", "C"), "Use --module A|B|C.")
  abc_assert(xor(!is.null(out$module), isTRUE(out$summarize)) || isTRUE(out$verify), "Select one module, --summarize, or --verify.")
  out
}

abc_require_phase <- function(phase, cfg) {
  if (identical(phase, "formal") && !isTRUE(cfg$formal_run_authorized)) {
    stop("FORMAL_ABC_RUN_STARTED=NO: formal execution requires later TL31 authorization and a config amendment.", call. = FALSE)
  }
  invisible(TRUE)
}

abc_run_module <- function(module, phase, cfg, root = abc_root(), output_dir = NULL) {
  abc_require_phase(phase, cfg)
  if (is.null(output_dir)) output_dir <- abc_output_dir(cfg, phase, module, root)
  runner <- get(paste0("abc_run_module_", tolower(module)), mode = "function")
  runner(cfg = cfg, phase = phase, output_dir = output_dir)
}

abc_summarize <- function(cfg, phase, root = abc_root(), output_dir = NULL) {
  abc_require_phase(phase, cfg)
  base <- output_dir %||% abc_output_dir(cfg, phase, root = root)
  files <- list.files(base, recursive = TRUE, full.names = FALSE)
  rows <- lapply(c("A", "B", "C"), function(module) {
    prefix <- paste0(cfg$outputs[[paste0("module_", tolower(module))]], "/")
    data.frame(module = module, files = sum(startsWith(gsub("\\\\", "/", files), prefix)), stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, rows)
  abc_write_csv(out, file.path(base, "ABC_PILOT_FILE_SUMMARY.csv"))
  out
}

abc_verify_assets <- function(cfg, root = abc_root()) {
  required <- c("ABC_FROZEN_PROTOCOL.md", "ABC_RUNBOOK.md", "config/abc_config.yml", "R/abc_orchestration.R", "R/abc_module_a.R", "R/abc_module_b.R", "R/abc_module_c.R", "scripts/run_abc.R", "scripts/audit_abc_pilot.R", "tests/test_abc_execution_assets.R")
  missing <- required[!file.exists(file.path(root, required))]
  abc_assert(!length(missing), paste("Missing ABC execution assets:", paste(missing, collapse = ", ")))
  authorization_consistent <- identical(isTRUE(cfg$formal_run_authorized), identical(cfg$phase_authorization, "formal_authorized"))
  data.frame(check = c("assets_present", "authorization_consistent"), status = c("PASS", if (authorization_consistent) "PASS" else "FAIL"), stringsAsFactors = FALSE)
}

`%||%` <- function(lhs, rhs) if (is.null(lhs) || !length(lhs)) rhs else lhs
