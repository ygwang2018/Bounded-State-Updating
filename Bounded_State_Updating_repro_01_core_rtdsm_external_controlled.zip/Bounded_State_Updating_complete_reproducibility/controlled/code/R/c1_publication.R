# Publication output mapping for the frozen C1 scientific core.

c1_contrast_dictionary <- function() {
  data.frame(
    contrast = paste0("C", 1:5),
    first_method = c("M1", "P2", "P2", "P2", "U4A"),
    second_method = c("G0", "M1", "G0", "V3", "M1"),
    scientific_contrast = c("M1 - G0", "P2 - M1", "P2 - G0", "P2 - V3", "U4A - M1"),
    contrast_role = c("PRIMARY_TOTAL_EFFECT", "PRIMARY_INCREMENTAL", "PRIMARY_TOTAL_EFFECT", "PRIMARY_INCREMENTAL", "SECONDARY_DIAGNOSTIC"),
    stringsAsFactors = FALSE
  )
}

c1_unblind_results <- function(out, cfg) {
  out <- merge(out, cfg$design, by = "cell_id", sort = FALSE)
  profiles <- cfg$profiles_df
  names(profiles)[names(profiles) == "family"] <- "raw_family"
  out <- merge(out, profiles, by = "profile_id", sort = FALSE)
  out <- merge(out, c1_contrast_dictionary(), by = "contrast", sort = FALSE)
  out$profile_family <- ifelse(out$raw_family == "clean", "CLEAN",
    ifelse(out$raw_family == "DGP2", "DGP2_OBSERVATION_CONTAMINATION", "DGP4_TRUE_STATE_JUMP"))
  out$profile_sign <- out$sign
  out$lower_95 <- out$mean - 1.96 * out$mcse
  out$upper_95 <- out$mean + 1.96 * out$mcse
  out$mase_materiality_class <- ifelse(out$metric != "MASE", "NOT_APPLICABLE",
    ifelse(out$upper_95 < -0.02, "FIRST_MATERIALLY_LOWER_LOSS",
      ifelse(out$lower_95 > 0.02, "FIRST_MATERIALLY_HIGHER_LOSS",
        ifelse(out$lower_95 >= -0.02 & out$upper_95 <= 0.02, "PRACTICAL_EQUIVALENCE", "INDETERMINATE"))))
  wanted <- c("cell_id", "profile_id", "metric", "contrast", "n", "mean", "variance", "mcse",
    "profile_family", "first_method", "second_method", "scientific_contrast", "contrast_role",
    "n_train", "h", "q", "H", "omega", "p_out", "c", "tau_fraction", "jump_magnitude",
    "profile_sign", "lower_95", "upper_95", "mase_materiality_class")
  out <- out[, wanted]
  out[order(out$cell_id, match(out$profile_id, cfg$profiles_df$profile_id),
            match(out$metric, cfg$metrics), match(out$contrast, paste0("C", 1:5))), ]
}

c1_cell_results <- function(state, cfg) c1_unblind_results(finalize_aggregates(state, cfg), cfg)

c1_family_summaries <- function(cell_results) {
  schemes <- rbind(
    data.frame(profile_family = "DGP2_OBSERVATION_CONTAMINATION", summary_scheme = "SELECTED_36_CELL_SUMMARY"),
    expand.grid(profile_family = c("CLEAN", "DGP4_TRUE_STATE_JUMP"),
      summary_scheme = c("A_MATCHED_36_CELL_WEIGHTED", "B_UNIQUE_15_STRUCTURAL_SETTING"), stringsAsFactors = FALSE)
  )
  dictionaries <- unique(cell_results[, c("contrast", "first_method", "second_method", "scientific_contrast", "contrast_role")])
  rows <- vector("list", nrow(schemes) * 15L); k <- 0L
  for (si in seq_len(nrow(schemes))) for (metric in c("MASE", "RMSSE", "sMAPE")) for (contrast in paste0("C", 1:5)) {
    scheme <- schemes[si, ]; source <- cell_results[cell_results$profile_family == scheme$profile_family &
      cell_results$metric == metric & cell_results$contrast == contrast, ]
    n_source <- nrow(source)
    if (scheme$profile_family == "DGP2_OBSERVATION_CONTAMINATION" || scheme$summary_scheme == "A_MATCHED_36_CELL_WEIGHTED") {
      values <- aggregate(mean ~ cell_id, source, mean)
    } else {
      matched <- aggregate(mean ~ cell_id, source, mean)
      design <- unique(source[, c("cell_id", "n_train", "h", "q", "H", "omega")])
      values <- aggregate(mean ~ n_train + h + q + H + omega, merge(matched, design, by = "cell_id"), mean)
    }
    x <- values$mean; d <- dictionaries[dictionaries$contrast == contrast, ]
    classes <- if (metric == "MASE" && scheme$summary_scheme != "B_UNIQUE_15_STRUCTURAL_SETTING") source$mase_materiality_class else character()
    k <- k + 1L
    rows[[k]] <- data.frame(profile_family = scheme$profile_family, summary_scheme = scheme$summary_scheme,
      metric = metric, contrast = contrast, first_method = d$first_method, second_method = d$second_method,
      scientific_contrast = d$scientific_contrast, contrast_role = d$contrast_role,
      n_cells = nrow(values), n_cell_profile_estimands = n_source,
      n_structural_settings = if (scheme$summary_scheme == "B_UNIQUE_15_STRUCTURAL_SETTING") nrow(values) else NA_integer_,
      n_source_cell_profile_estimands = n_source, descriptive_mean = mean(x), descriptive_median = median(x),
      descriptive_min = min(x), descriptive_max = max(x), count_negative = sum(x < 0), count_zero = sum(x == 0),
      count_positive = sum(x > 0), descriptive_direction = ifelse(mean(x) < 0, "NEGATIVE", "POSITIVE"),
      descriptive_mase_magnitude = if (metric != "MASE") "NOT_APPLICABLE" else if (mean(x) < -0.02) "MEAN_BELOW_MINUS_0.02" else if (mean(x) > 0.02) "MEAN_ABOVE_PLUS_0.02" else "MEAN_WITHIN_PLUS_MINUS_0.02",
      mase_count_first_materially_lower = if (length(classes)) sum(classes == "FIRST_MATERIALLY_LOWER_LOSS") else NA_integer_,
      mase_count_first_materially_higher = if (length(classes)) sum(classes == "FIRST_MATERIALLY_HIGHER_LOSS") else NA_integer_,
      mase_count_practical_equivalence = if (length(classes)) sum(classes == "PRACTICAL_EQUIVALENCE") else NA_integer_,
      mase_count_indeterminate = if (length(classes)) sum(classes == "INDETERMINATE") else NA_integer_,
      mase_count_basis = if (metric != "MASE") "NOT_APPLICABLE" else if (length(classes)) "CELL_PROFILE_95CI_CLASS" else "NOT_AVAILABLE_WITHOUT_WITHIN_SETTING_COVARIANCE",
      formal_family_mcse = NA_real_, formal_family_ci = NA_character_,
      family_inference_status = "FIXED_DESIGN_DESCRIPTIVE_ONLY_NO_FORMAL_FAMILY_CI",
      weighting_sensitivity = if (scheme$summary_scheme == "SELECTED_36_CELL_SUMMARY") "NOT_APPLICABLE_SINGLE_FROZEN_WEIGHTING" else "STABLE_TO_DEDUPLICATION",
      stringsAsFactors = FALSE)
  }
  do.call(rbind, rows)
}

run_c1 <- function(n = 16538L, config = file.path("config", "c1_config.yml")) {
  cfg <- load_config(config)
  do.call(RNGkind, list(kind = cfg$rng$kind, normal.kind = cfg$rng$normal_kind, sample.kind = cfg$rng$sample_kind))
  cells <- c1_cell_results(run_minimal(cfg, seq_len(as.integer(n))), cfg)
  list(cell_results = cells, family_summaries = c1_family_summaries(cells))
}
