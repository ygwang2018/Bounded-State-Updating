#!/usr/bin/env Rscript

parse_args <- function(x = commandArgs(trailingOnly = TRUE)) {
  out <- list()
  i <- 1L
  while (i <= length(x)) {
    key <- sub("^--", "", x[[i]])
    if (i == length(x) || startsWith(x[[i + 1L]], "--")) {
      out[[key]] <- TRUE
      i <- i + 1L
    } else {
      out[[key]] <- x[[i + 1L]]
      i <- i + 2L
    }
  }
  out
}

arg <- function(args, key, default = NULL, required = FALSE) {
  value <- args[[key]]
  if (is.null(value)) value <- default
  if (required && (is.null(value) || !nzchar(value))) {
    stop("Missing required argument --", key, call. = FALSE)
  }
  value
}

write_csv <- function(x, path) {
  utils::write.csv(x, path, row.names = FALSE, na = "", quote = TRUE)
}

append_log <- function(out_dir, text) {
  cat(format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"), text, "\n",
      file = file.path(out_dir, "RUN_LOG.txt"), append = TRUE)
}

load_config <- function(path) {
  if (!requireNamespace("yaml", quietly = TRUE)) {
    stop("The yaml package is required.", call. = FALSE)
  }
  x <- yaml::read_yaml(path)
  x$design <- do.call(rbind, lapply(x$design_cells, function(z) {
    as.data.frame(z, stringsAsFactors = FALSE)
  }))
  x$profiles_df <- data.frame(
    profile_id = vapply(x$profiles, `[[`, character(1L), "profile_id"),
    family = vapply(x$profiles, `[[`, character(1L), "family"),
    sign = vapply(x$profiles, function(z) if (is.null(z$sign)) NA_real_ else as.numeric(z$sign), numeric(1L)),
    tau_fraction = vapply(x$profiles, function(z) if (is.null(z$tau_fraction)) NA_real_ else as.numeric(z$tau_fraction), numeric(1L)),
    jump_magnitude = vapply(x$profiles, function(z) if (is.null(z$jump_magnitude)) NA_real_ else as.numeric(z$jump_magnitude), numeric(1L)),
    stringsAsFactors = FALSE
  )
  x$contrasts_df <- do.call(rbind, lapply(x$contrasts, function(z) {
    as.data.frame(z, stringsAsFactors = FALSE)
  }))
  numeric_design <- c("cell_id", "n_train", "h", "q", "H", "omega", "p_out", "c")
  x$design[numeric_design] <- lapply(x$design[numeric_design], as.numeric)
  if (nrow(x$design) != 36L || nrow(x$profiles_df) != 11L || length(x$arms) != 5L ||
      nrow(x$contrasts_df) != 5L) {
    stop("Frozen C1 dimensions are not 36 cells, 11 profiles, 5 arms, and 5 contrasts.", call. = FALSE)
  }
  if (!identical(unlist(x$arms, use.names = FALSE), paste0("A", 1:5)) ||
      !identical(x$contrasts_df$contrast_id, paste0("C", 1:5))) {
    stop("Opaque arm or contrast labels are not in the frozen order.", call. = FALSE)
  }
  x
}

generate_path <- function(seed, design_cell, profile, mu0 = 0) {
  n_train <- as.integer(design_cell$n_train)
  h <- as.integer(design_cell$h)
  n_total <- n_train + h
  H <- as.numeric(design_cell$H)
  q <- as.numeric(design_cell$q)
  omega <- as.numeric(design_cell$omega)
  family <- as.character(profile$family)
  set.seed(as.integer(seed))
  epsilon <- stats::rnorm(n_total, sd = sqrt(H))
  eta <- stats::rnorm(n_total, sd = sqrt(q * H))
  state_shock <- numeric(n_total)
  if (identical(family, "DGP4")) {
    tau <- as.integer(floor(as.numeric(profile$tau_fraction) * n_train))
    state_shock[tau] <- as.numeric(profile$sign) * as.numeric(profile$jump_magnitude) * sqrt(H)
  }
  mu_after_update <- mu0 + cumsum(omega + eta + state_shock)
  mu_before_y <- c(mu0, head(mu_after_update, -1L))
  y <- mu_before_y + epsilon
  outlier_shift <- numeric(n_total)
  if (identical(family, "DGP2")) {
    eligible_t <- 5L:n_train
    repeat {
      flags <- stats::rbinom(length(eligible_t), size = 1L, prob = as.numeric(design_cell$p_out)) == 1L
      if (any(flags)) break
    }
    positions <- eligible_t[flags]
    outlier_shift[positions] <- as.numeric(profile$sign) * as.numeric(design_cell$c) * sqrt(H)
    y <- y + outlier_shift
  }
  list(
    y_train = y[seq_len(n_train)],
    y_test = y[n_train + seq_len(h)],
    y = y,
    mu_before_y = mu_before_y,
    mu_after_update = mu_after_update,
    epsilon = epsilon,
    eta = eta,
    state_shock = state_shock,
    outlier_shift = outlier_shift,
    seed = as.integer(seed),
    profile_id = as.character(profile$profile_id)
  )
}

run_five_arms <- function(path, parameters, trace = FALSE) {
  y_train <- as.numeric(path$y_train)
  h <- as.integer(parameters$h)
  omega <- as.numeric(parameters$omega)
  q <- as.numeric(parameters$q)
  H <- as.numeric(parameters$H)
  nu <- as.numeric(parameters$nu)
  P1 <- as.numeric(parameters$P1)
  arms <- paste0("A", 1:5)
  a <- rep(y_train[[1L]], 5L)
  P <- rep(P1, 5L)
  trace_rows <- if (trace) vector("list", length(y_train)) else NULL
  s2 <- H * (nu - 2) / nu
  for (t in seq_along(y_train)) {
    yt <- y_train[[t]]
    a_prior <- a
    P_prior <- P
    v <- yt - a
    Fv <- P + 1
    K <- P / Fv
    r2 <- (v^2) / (s2 * Fv)
    w <- (nu + 1) / (nu + r2)
    wt <- pmin.int(1, w)
    a_post <- P_post <- numeric(5L)
    a_post[[1L]] <- a[[1L]] + K[[1L]] * v[[1L]]
    P_post[[1L]] <- P[[1L]] / (P[[1L]] + 1)
    a_post[[2L]] <- a[[2L]] + K[[2L]] * wt[[2L]] * v[[2L]]
    P_post[[2L]] <- P[[2L]] / (P[[2L]] + 1)
    a_post[[3L]] <- a[[3L]] + K[[3L]] * wt[[3L]] * v[[3L]]
    P_post[[3L]] <- P[[3L]] - wt[[3L]] * P[[3L]]^2 / (P[[3L]] + 1)
    k_infl <- wt[[4L]] * P[[4L]] / (1 + wt[[4L]] * P[[4L]])
    a_post[[4L]] <- a[[4L]] + k_infl * v[[4L]]
    P_post[[4L]] <- P[[4L]] / (1 + wt[[4L]] * P[[4L]])
    a_post[[5L]] <- a[[5L]] + K[[5L]] * w[[5L]] * v[[5L]]
    P_post[[5L]] <- P[[5L]] / (P[[5L]] + 1)
    if (any(!is.finite(c(a_post, P_post))) || any(P_post < 0)) {
      stop("Nonfinite or negative state update.", call. = FALSE)
    }
    a <- a_post + omega
    P <- P_post + q
    if (trace) {
      trace_rows[[t]] <- data.frame(
        t = t, arm = arms, y = yt, a_prior = a_prior, P_prior = P_prior,
        innovation = v, F = Fv, K = K, w = w, capped_w = wt,
        a_post = a_post, P_post = P_post, a_next = a, P_next = P,
        stringsAsFactors = FALSE
      )
    }
  }
  names(a_post) <- names(P_post) <- arms
  forecasts <- matrix(rep(a_post, each = h), nrow = h) + seq_len(h) * omega
  colnames(forecasts) <- arms
  list(
    forecasts = forecasts,
    final_a_post = a_post,
    final_P_post = P_post,
    trace = if (trace) do.call(rbind, trace_rows) else NULL
  )
}

score_forecasts <- function(truth, forecasts, y_train) {
  denom_abs <- mean(abs(diff(y_train)))
  denom_sq <- mean(diff(y_train)^2)
  errors <- forecasts - as.numeric(truth)
  out <- cbind(
    MASE = colMeans(abs(errors)) / denom_abs,
    RMSSE = sqrt(colMeans(errors^2) / denom_sq),
    sMAPE = colMeans((abs(errors) * 200) / (abs(as.numeric(truth)) + abs(forecasts)))
  )
  rownames(out) <- colnames(forecasts)
  out
}

paired_contrasts <- function(losses) {
  out <- losses[c(2L, 3L, 3L, 3L, 5L), , drop = FALSE] -
    losses[c(1L, 2L, 1L, 4L, 2L), , drop = FALSE]
  rownames(out) <- paste0("C", 1:5)
  out
}

new_aggregates <- function(cfg) {
  d <- c(nrow(cfg$design), nrow(cfg$profiles_df), length(cfg$metrics), 5L)
  state <- new.env(parent = emptyenv())
  state$n <- matrix(0L, nrow(cfg$design), nrow(cfg$profiles_df))
  state$mean <- array(0, dim = d)
  state$M2 <- array(0, dim = d)
  state
}

update_aggregates <- function(state, cell_index, profile_index, contrast_values) {
  x <- t(contrast_values)
  n1 <- state$n[cell_index, profile_index] + 1L
  old_mean <- state$mean[cell_index, profile_index, , ]
  delta <- x - old_mean
  new_mean <- old_mean + delta / n1
  state$mean[cell_index, profile_index, , ] <- new_mean
  state$M2[cell_index, profile_index, , ] <- state$M2[cell_index, profile_index, , ] + delta * (x - new_mean)
  state$n[cell_index, profile_index] <- n1
  invisible(state)
}

finalize_aggregates <- function(state, cfg) {
  rows <- vector("list", nrow(cfg$design) * nrow(cfg$profiles_df) * length(cfg$metrics) * 5L)
  k <- 0L
  for (ci in seq_len(nrow(cfg$design))) {
    for (pi in seq_len(nrow(cfg$profiles_df))) {
      n <- state$n[ci, pi]
      for (mi in seq_along(cfg$metrics)) {
        for (ki in seq_len(5L)) {
          k <- k + 1L
          variance <- if (n > 1L) state$M2[ci, pi, mi, ki] / (n - 1L) else NA_real_
          rows[[k]] <- data.frame(
            cell_id = cfg$design$cell_id[[ci]],
            profile_id = cfg$profiles_df$profile_id[[pi]],
            metric = cfg$metrics[[mi]],
            contrast = paste0("C", ki),
            n = n,
            mean = state$mean[ci, pi, mi, ki],
            variance = variance,
            mcse = sqrt(variance / n),
            stringsAsFactors = FALSE
          )
        }
      }
    }
  }
  do.call(rbind, rows)
}

run_minimal <- function(cfg, seeds) {
  state <- new_aggregates(cfg)
  cells <- lapply(seq_len(nrow(cfg$design)), function(i) as.list(cfg$design[i, , drop = FALSE]))
  profiles <- lapply(seq_len(nrow(cfg$profiles_df)), function(i) as.list(cfg$profiles_df[i, , drop = FALSE]))
  parameters <- lapply(cells, function(cell) c(cell, cfg$model))
  for (seed in seeds) {
    for (ci in seq_along(cells)) {
      for (pi in seq_along(profiles)) {
        path <- generate_path(seed, cells[[ci]], profiles[[pi]], cfg$model$mu0)
        arms <- run_five_arms(path, parameters[[ci]])
        losses <- score_forecasts(path$y_test, arms$forecasts, path$y_train)
        update_aggregates(state, ci, pi, paired_contrasts(losses))
      }
    }
  }
  state
}
