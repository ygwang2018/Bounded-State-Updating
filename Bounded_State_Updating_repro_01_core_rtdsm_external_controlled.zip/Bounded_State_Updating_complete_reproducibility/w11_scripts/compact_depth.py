"""Display-only Table S7 rebuild from accepted R1 predictions; no fitting."""
from pathlib import Path
import pandas as pd

METHODS=['G_MATCH','HUBER_ST','MB_ST','CB_ST']
NAMES=['G-MATCH','Huber-ST','MB-ST','CB-ST']
DEPTHS=['D1','D3','DSTABLE']
SERIES=['EMPLOY','IPT','IPM','H','CUT']
SHOCK='COVID_SHOCK_2020_03_TO_07'

def build_depth_table(root):
    root=Path(root)
    f=pd.read_csv(root/'02_REPRODUCIBILITY_PACKAGE/R1_R2/03_R1_RTDSM/R1_RTDSM_FORECASTS.csv')
    f=f[(f.interface=='PRE')&(f.fit_interface=='full_refit')]
    allrows=[];keyrows=[]
    for sn in SERIES:
        for m,name in zip(METHODS,NAMES):
            a=f[(f.series==sn)&(f.method==m)]
            assert a.groupby('depth').size().to_dict()==dict.fromkeys(DEPTHS,90)
            vals=[f'{a[a.depth==d][met].mean()**power:.3f}' for met,power in [('abs_error',1),('sq_error',.5)] for d in DEPTHS]
            allrows.append([sn,name]+vals)
    for m,name in zip(METHODS,NAMES):
        vals=[]
        for sn in ['EMPLOY','CUT']:
            a=f[(f.series==sn)&(f.method==m)&(f.phase==SHOCK)]
            assert a.groupby('depth').size().to_dict()==dict.fromkeys(DEPTHS,5)
            vals.extend(f'{a[a.depth==d].abs_error.mean():.3f}' for d in DEPTHS)
        a=f[(f.series=='EMPLOY')&(f.method==m)&(f.target_date=='2020-05-01')].set_index('depth')
        assert (a.target_third==2725).all()
        vals.extend(f'{a.loc[d,"forecast_h1"]:.3f}' for d in DEPTHS)
        keyrows.append([name]+vals)
    for lang,folder in [('en','01_ENGLISH_CANONICAL'),('zh','03_CHINESE_DERIVATIVE')]:
        en=lang=='en'
        caption='RTDSM fitting-depth sensitivity.' if en else 'RTDSM 拟合深度敏感性。'
        panel_a='A. Full-period errors: all 90 target months' if en else 'A. 全期误差：全部 90 个目标月'
        panel_b='B. Shock-window errors and the employment reversal forecast' if en else 'B. 冲击窗口误差与就业反转预测'
        series='Series' if en else '序列';method='Method' if en else '方法'
        out=r'\begin{table}[htbp]'+'\n'+r'\centering'+'\n'+r'\caption{'+caption+'}\n'+r'\label{tab:rtdsm_depth}'+'\n'
        out+=r'\small\setlength{\tabcolsep}{3.5pt}\renewcommand{\arraystretch}{1.13}'+'\n'
        out+=r'\textbf{'+panel_a+r'}\par\smallskip'+'\n'+r'\begin{tabular}{@{}llrrrrrr@{}}'+'\n'+r'\toprule'+'\n'
        out+=series+' & '+method+r' & \multicolumn{3}{c}{MAE} & \multicolumn{3}{c}{RMSE} \\'+'\n'
        out+=r'\cmidrule(lr){3-5}\cmidrule(l){6-8}'+'\n'+r' & & D1 & D3 & DSTABLE & D1 & D3 & DSTABLE \\'+'\n'+r'\midrule'+'\n'
        for i,row in enumerate(allrows):
            if i and i%4==0:out+=r'\addlinespace[3pt]'+'\n'
            row=row.copy()
            if i%4:row[0]=''
            out+=' & '.join(row)+r' \\'+'\n'
        out+=r'\bottomrule\end{tabular}\end{table}'+'\n\n'
        out+=r'\begin{table}[htbp]\centering\ContinuedFloat'+'\n'+r'\textbf{'+panel_b+r'}\par\smallskip'+'\n'
        out+=r'\footnotesize\setlength{\tabcolsep}{3pt}\renewcommand{\arraystretch}{1.18}'+'\n'+r'\begin{tabular}{@{}lrrrrrrrrr@{}}'+'\n'+r'\toprule'+'\n'
        labels=['EMPLOY shock MAE','CUT shock MAE','May EMPLOY forecast'] if en else ['EMPLOY 冲击 MAE','CUT 冲击 MAE','5 月 EMPLOY 预测']
        out+=method+' & '+' & '.join(r'\multicolumn{3}{c}{'+x+'}' for x in labels)+r' \\'+'\n'
        out+=r'\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(l){8-10}'+'\n'+r' & D1 & D3 & DSTABLE & D1 & D3 & DSTABLE & D1 & D3 & DSTABLE \\'+'\n'+r'\midrule'+'\n'
        for row in keyrows:out+=' & '.join(row)+r' \\'+'\n'
        out+=r'\bottomrule\end{tabular}\par\smallskip'+'\n'+r'\begin{minipage}{\textwidth}\footnotesize'+'\n'
        note=('PRE full-refit predictions. Panel A covers January 2018--June 2025; panel B uses March--July 2020 MAE and the May 2020 EMPLOY forecast (Third-release target: 2,725). EMPLOY is in thousands of employees; IPT/IPM/H are in annualized growth-rate percentage points; CUT is in level percentage points. D1, D3 and DSTABLE share the original starting tuple and numerical bounds. Complete PRE/REF and fixed-context values are supplied as source data.' if en else 'PRE 完整重新拟合预测。面板 A 覆盖 2018 年 1 月至 2025 年 6 月；面板 B 列出 2020 年 3--7 月 MAE 和 2020 年 5 月 EMPLOY 预测（Third 发布目标：2,725）。EMPLOY 单位为千人，IPT/IPM/H 为年化增长率百分点，CUT 为水平百分点。D1、D3 和 DSTABLE 共享原始起点和数值边界。完整 PRE/REF 及固定上下文数值由源数据提供。')
        out+=note+'\n'+r'\end{minipage}\end{table}\FloatBarrier'+'\n'
        (root/folder/'tables/rtdsm_depth.tex').write_text(out,encoding='utf-8')
    return allrows,keyrows

if __name__=='__main__':
    a,b=build_depth_table(Path(__file__).resolve().parents[2])
    print('Table S7: 120 full-period + 36 key-window values; two panels; bilingual.')
