"""Regenerate Main 4/5 and Supplement 8--11 from frozen ten-method records.

No model fitting and no manuscript mutation. Presentation templates contain no
numerical body rows. Historical seven/five/four-method studies are not rewritten.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import numpy as np
import pandas as pd

METHODS = ['ST_AUTHOR', 'G_MATCH', 'HUBER_ST', 'MB_ST', 'CB_ST', 'ROBETS',
           'AutoTheta', 'NAIVE', 'ETS', 'AutoARIMA']
NAMES = dict(zip(METHODS, ['ST-Author', 'G-MATCH', 'Huber-ST', 'MB-ST', 'CB-ST',
                         'ROBETS', 'AutoTheta', 'Naive', 'ETS', 'AutoARIMA']))
SERIES = ['EMPLOY', 'IPT', 'IPM', 'H', 'CUT']
PHASES = ['PRE_COVID_2018_TO_2020_02', 'COVID_SHOCK_2020_03_TO_07',
          'RECOVERY_2020_08_TO_2021_12', 'POST_2022_TO_2025_06']
ALL = 'ALL_2018_01_TO_2025_06'
SCRIPT_DIR = Path(__file__).resolve().parent


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def safe_output(path: Path, package: Path) -> Path:
    path = path.resolve()
    require(path != package.resolve(), 'Use a separate output directory.')
    require(not any(p in ('01_ENGLISH_CANONICAL', '03_CHINESE_DERIVATIVE') for p in path.parts),
            'This generator does not write manuscript directories.')
    path.mkdir(parents=True, exist_ok=True)
    return path


def number(value: float, minimum: float | None = None, digits: int = 3) -> str:
    text = f'{value:.{digits}f}'
    return r'\textbf{' + text + '}' if minimum is not None and value == minimum else text


def render_tables(rows: dict, language: str, output: Path) -> None:
    layouts = json.loads((SCRIPT_DIR / 'table_layouts.json').read_text(encoding='utf-8'))[language]
    folder = output / language
    folder.mkdir(parents=True, exist_ok=True)
    translations = {'Other recorded structures': '其余记录结构',
                    'nonzero mean': '非零均值', 'no mean/drift': '无均值／漂移'}
    for filename, panels in rows.items():
        text = layouts[filename]
        for i, panel in enumerate(panels):
            lines = []
            for row in panel:
                values = list(row)
                if language == 'ZH':
                    for a, b in translations.items():
                        values[0] = values[0].replace(a, b)
                lines.append(' & '.join(values) + r' \\')
            marker = '@@ROWS_' + str(i) + '@@'
            require(text.count(marker) == 1, 'Layout panel count mismatch: ' + filename)
            text = text.replace(marker, '\n'.join(lines))
        require('@@ROWS_' not in text, 'Unfilled layout panel: ' + filename)
        (folder / filename).write_text(text, encoding='utf-8')


def build(package: Path, metrics_path: Path, auto_path: Path, output: Path) -> dict:
    d = pd.read_csv(metrics_path, float_precision='round_trip')
    keys = ['series', 'phase', 'interface', 'method']
    require(len(d) == 500 and not d.duplicated(keys).any(), 'Expected 500 unique summary rows.')
    require(set(d.method) == set(METHODS), 'Unexpected full-refit method set.')
    require(np.isfinite(d[['MAE', 'RMSE', 'forecast_revision_abs']]).all().all(), 'Nonfinite metrics.')
    require(d.groupby(['series', 'phase', 'interface']).size().eq(10).all(), 'Incomplete method cells.')
    rank = d[d.interface.eq('PRE')].copy()
    rank['rank'] = rank.groupby(['series', 'phase']).MAE.rank(method='average')
    rank['RMSE_rank'] = rank.groupby(['series', 'phase']).RMSE.rank(method='average')
    source = output / 'source_data'
    source.mkdir(exist_ok=True)
    shutil.copyfile(metrics_path, source / 'rtdsm_ten_method_metrics.csv')
    rank.to_csv(source / 'rtdsm_mae_ranks.csv', index=False)
    tables: dict[str, list] = {}
    for phase, filename in [(ALL, 'realtime_all.tex'), (PHASES[1], 'realtime_covid_mae_rank.tex')]:
        block = rank[rank.phase.eq(phase)]
        means = block.groupby('method')['rank'].mean()
        minima = block.groupby('series').MAE.min()
        rows = []
        for method in METHODS:
            z = block[block.method.eq(method)].set_index('series')
            cells = [number(z.loc[s, 'MAE'], minima[s]) + f' ({z.loc[s, "rank"]:g})' for s in SERIES]
            rows.append([NAMES[method], *cells, number(means[method], means.min(), 2)])
        tables[filename] = [rows]
    phase_rank = rank[rank.phase.isin(PHASES)].groupby(['method', 'phase'])['rank'].mean().unstack()
    phase_rank = phase_rank.reindex(index=METHODS, columns=PHASES)
    phase_rank['20-cell mean'] = phase_rank.mean(axis=1)
    minimum = phase_rank.min()
    tables['realtime_phase_mean_ranks.tex'] = [[[NAMES[m]] +
        [number(phase_rank.loc[m, c], minimum[c], 2) for c in phase_rank] for m in METHODS]]
    phase_rank.to_csv(source / 'rtdsm_period_balanced_ranks.csv')
    panels = []
    for phase in PHASES:
        block = d[d.phase.eq(phase) & d.interface.eq('PRE')]
        minimum = block.groupby('series')[['MAE', 'RMSE']].min()
        rows = []
        for method in METHODS:
            z = block[block.method.eq(method)].set_index('series')
            cells = [' / '.join(number(z.loc[s, k], minimum.loc[s, k]) for k in ['MAE', 'RMSE']) for s in SERIES]
            rows.append([NAMES[method], *cells])
        panels.append(rows)
    tables['realtime_full_phase_results.tex'] = panels
    panels = []
    block = d[d.phase.eq(ALL) & d.interface.eq('PRE')]
    for metric in ['RMSE', 'forecast_revision_abs']:
        minimum = block.groupby('series')[metric].min()
        panels.append([[NAMES[m]] + [number(block[(block.method == m) & (block.series == s)][metric].iloc[0],
                                          minimum[s]) for s in SERIES] for m in METHODS])
    tables['realtime_all_secondary.tex'] = panels
    fits = pd.read_csv(package / 'R1_R2/05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FITS.csv', keep_default_na=False)
    require(len(fits) == 1800, 'Expected 1,800 ETS/AutoARIMA records.')
    def arima_identity(row: pd.Series) -> str:
        orders = ','.join(part.split('=')[1] for part in row['orders'].split(';'))
        suffix = 'drift' if str(row.drift).lower() == 'true' else (
                 'nonzero mean' if str(row['mean']).lower() == 'true' else 'no mean/drift')
        return f'ARIMA({orders}), {suffix}'
    mask = fits.method.eq('AutoARIMA')
    fits.loc[mask, 'selected_model'] = fits[mask].apply(arima_identity, axis=1)
    panels = []
    for method in ['ETS', 'AutoARIMA']:
        counts = fits[fits.method.eq(method)].groupby(['selected_model', 'interface']).size().unstack(fill_value=0)
        counts.to_csv(source / f'{method}_selection_counts.csv')
        if method == 'AutoARIMA':
            require(len(counts) == 47, 'Unexpected AutoARIMA identity count.')
            counts = counts.sort_values(['PRE', 'REF'], ascending=False, kind='stable')
            shown, other = counts.head(10), counts.iloc[10:].sum()
        else:
            shown = counts
        rows = [[str(model), str(int(v.PRE)), str(int(v.REF))] for model, v in shown.iterrows()]
        if method == 'AutoARIMA':
            rows.append(['Other recorded structures', str(int(other.PRE)), str(int(other.REF))])
        panels.append(rows)
    auto = pd.read_csv(auto_path, float_precision='round_trip', keep_default_na=False)
    require(len(auto) == 900 and not auto.duplicated(['series', 'target_date', 'interface']).any(),
            'Expected 900 unique AutoTheta fits.')
    require(auto.fit_status.eq('OK').all(), 'AutoTheta contains a failed fit.')
    auto['family'] = auto[['seasonality_code', 'combination_code', 'trend_code']].agg(' '.join, axis=1)
    families = ['N A Lrl', 'N A Exp', 'N M Exp']
    counts = auto.groupby(['series', 'interface', 'family']).size()
    medians = auto.groupby(['series', 'interface']).theta.median()
    selection_rows = [dict(series=s, interface=i, phase=ALL, family=f,
                           count=int(counts.get((s, i, f), 0)),
                           n_fits=int((auto.series.eq(s) & auto.interface.eq(i)).sum()),
                           median_theta=medians[s, i])
                      for s in SERIES for i in ['PRE', 'REF'] for f in families]
    pd.DataFrame(selection_rows).to_csv(source / 'AutoTheta_selection_summary.csv', index=False)
    rows = []
    for s in SERIES:
        cells = ['/'.join(str(int(counts.get((s, interface, family), 0))) for interface in ['PRE', 'REF']) for family in families]
        cells.append('/'.join(number(medians[s, interface]) for interface in ['PRE', 'REF']))
        rows.append([s, *cells])
    panels.append(rows)
    tables['benchmark_selection.tex'] = panels
    (output / 'table_rows.json').write_text(json.dumps(tables, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    render_tables(tables, 'EN', output)
    return tables


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-root', type=Path, default=SCRIPT_DIR.parent)
    parser.add_argument('--ten-method-source', type=Path)
    parser.add_argument('--autotheta-fits', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    pkg = args.package_root.resolve()
    source = args.ten_method_source or pkg / 'R1_R2/07_SUMMARIES/R2_TEN_METHOD_COMPARISON.csv'
    auto = args.autotheta_fits or pkg / 'R1_R2/05_R2_BENCHMARKS/R2_AUTOTHETA_FITS.csv'
    output = safe_output(args.output or pkg / 'reproduced/ten_method_tables', pkg)
    tables = build(pkg, source, auto, output)
    print(f'Regenerated {len(tables)} English tables from frozen records: {output}')


if __name__ == '__main__':
    main()
