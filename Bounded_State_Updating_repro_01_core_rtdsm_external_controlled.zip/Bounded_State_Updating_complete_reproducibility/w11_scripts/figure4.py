"""Figure 4: protection at employment reversal and adaptation cost in utilization.
Display-only revision of the accepted 60 forecasts and 12 Third targets.
Python/matplotlib; width 6.5 inches. Panel b enlarges the three bounded paths.
"""
from pathlib import Path
import sys
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
ROOT=Path(__file__).resolve().parents[2]
R=ROOT/'02_REPRODUCIBILITY_PACKAGE'; O=ROOT/'01_ENGLISH_CANONICAL/figures'
Q=ROOT/'05_REPAIR_QA'; Q.mkdir(exist_ok=True); O.mkdir(exist_ok=True,parents=True)
d=pd.read_csv(R/'w11_source_data/figure4_realtime_paths.csv')
assert len(d)==60 and not d.duplicated(['series','target_date','method']).any()
assert d.groupby(['series','target_date']).target_third.nunique().eq(1).all()
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Liberation Sans','DejaVu Sans'],
 'font.size':8,'axes.labelsize':7,'axes.titlesize':8,'xtick.labelsize':7,'ytick.labelsize':7,
 'legend.fontsize':7,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6})
styles={'G_MATCH':('#0072B2','s','-','G-MATCH'),'HUBER_ST':('#D55E00','v',(0,(4,1,1,1)),'Huber-ST'),
 'MB_ST':('#E69F00','o','--','MB-ST'),'CB_ST':('#CC79A7','x',':','CB-ST'),'NAIVE':('#009E73','^','-.','Naive')}
fig,axs=plt.subplots(1,3,figsize=(6.5,3.2))
fig.subplots_adjust(left=.10,right=.985,bottom=.27,top=.85,wspace=.48)
for i,(ax,sn,title) in enumerate(zip(axs,['EMPLOY','EMPLOY','CUT'],['Employment change','Bounded variants','Capacity utilization'])):
 a=d[d.series==sn]
 target=a[['target_date','target_third']].drop_duplicates().sort_values('target_date')
 assert len(target)==6
 if i!=1:
  ax.plot(range(6),target.target_third,color='black',marker='D',markersize=3.2,lw=1.3,label='Third-release target',zorder=3)
 methods=['HUBER_ST','MB_ST','CB_ST'] if i==1 else list(styles)
 for m in methods:
  color,mark,ls,label=styles[m]; z=a[a.method==m].sort_values('target_date')
  assert z.target_date.tolist()==target.target_date.tolist()
  ax.plot(range(6),z.forecast_pre_realtime,color=color,marker=mark,linestyle=ls,
   markersize=4 if m=='CB_ST' else 3.3,lw=1.1,markerfacecolor='none' if m=='MB_ST' else color,
   label=label,zorder=4 if m=='CB_ST' else 2)
 ax.set_xticks(range(6),['Mar','Apr','May','Jun','Jul','Aug']); ax.set_xlim(-.2,5.2)
 ax.set_title(title,pad=11);ax.set_xlabel('2020');ax.grid(axis='y',color='#dedede',linewidth=.4,zorder=0)
 ax.annotate('abc'[i],xy=(0,1),xycoords='axes fraction',xytext=(-24,12),textcoords='offset points',fontweight='bold',fontsize=10)
 if i==0:
  ax.set_ylim(-24000,6500);ax.set_yticks([-20000,-10000,0,5000]);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{int(v):,}'))
  ax.set_ylabel('Thousands of employees')
 elif i==1:
  z=a[a.method.isin(methods)].forecast_pre_realtime;lo,hi=z.min(),z.max()
  ax.set_ylim(lo-.14*(hi-lo),hi+.16*(hi-lo));ax.set_yticks([-500,0,500]);ax.set_ylabel('Thousands of employees')
 else:ax.set_ylim(60,79);ax.set_yticks([60,65,70,75]);ax.set_ylabel('Level (%)')
handles,labels=axs[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.005),ncol=3,frameon=False,columnspacing=1.4,handlelength=2.4)
fig.canvas.draw()
sys.path.insert(0,str(Path(__file__).resolve().parent))
from audit_panel_alignment import require_matplotlib_panel_alignment
require_matplotlib_panel_alignment(fig,json_out=Q/'figure4_alignment.json')
for ext in ['pdf','svg','png','tiff']:
 kw={'dpi':600,'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else ({'dpi':300} if ext=='png' else {})
 fig.savefig(O/('figure4_realtime_paths.'+ext),facecolor='white',**kw)
plt.close(fig)
