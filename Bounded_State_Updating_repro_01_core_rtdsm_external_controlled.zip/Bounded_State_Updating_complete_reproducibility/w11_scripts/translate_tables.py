"""Render the six Chinese tables from the same generated numerical rows as English.

Run build_tables.py first. This entry point changes presentation labels only;
it does not refit, rescore, recompute ranks or write manuscript directories.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from build_tables import render_tables, safe_output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).resolve().parents[1] / 'reproduced/ten_method_tables')
    args = parser.parse_args()
    output = safe_output(args.output, Path(__file__).resolve().parents[1])
    rows_path = output / 'table_rows.json'
    if not rows_path.is_file():
        raise FileNotFoundError('Run build_tables.py with the same --output first.')
    rows = json.loads(rows_path.read_text(encoding='utf-8'))
    render_tables(rows, 'ZH', output)
    print(f'Regenerated {len(rows)} Chinese tables from shared numerical rows: {output}')


if __name__ == '__main__':
    main()
