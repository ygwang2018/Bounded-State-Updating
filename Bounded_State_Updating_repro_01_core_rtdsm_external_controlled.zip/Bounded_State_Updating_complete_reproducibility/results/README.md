# Results index

Stored outputs used by the manuscript remain in their validated project-relative locations.

- `../controlled/` — controlled-study summaries and contrasts.
- `../M3/` — fitted-layer and formal Gate-F outputs.
- `../R1_R2/` — fitting-depth, benchmark and ten-method summaries.
- `../realtime/` — full-refit and fixed-context real-time results.
- `../tables/` and `../w11_source_data/` — publication tables and their frozen source records.

Detailed source-to-display mapping is in `../source_data_mapping.md`.
