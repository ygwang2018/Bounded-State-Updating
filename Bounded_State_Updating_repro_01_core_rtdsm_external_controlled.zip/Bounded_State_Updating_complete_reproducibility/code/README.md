# Code index

This folder is a review-time navigation layer. Exact analysis code remains in its validated project-relative locations; files are not duplicated or moved.

- `../method_code/` — G-MATCH, Huber-ST, MB-ST, CB-ST and ST-Author adapters.
- `../controlled/code/` — controlled contamination and persistent-shift experiments.
- `../fitting_depth_code/` — fitting-depth, M3 and RTDSM sensitivity code.
- `../realtime/` — real-time-vintage construction and forecasting scripts.
- `../w11_scripts/` — final table, figure and alignment scripts.

See `../README.md` and `../README_TECHNICAL_DETAIL.md` for entry points.
