# Long-sample RTDSM results

These files are the canonical R outputs for the primary balanced July 1983--June 2025 RTDSM analysis.

Scope:

- five monthly series: EMPLOY, IPT, IPM, H, CUT;
- 504 forecast targets per series;
- 2,520 series--origin cases;
- four internal methods only: Gaussian-ST, Huber-ST, MB-ST, CB-ST;
- PRE and REF histories contain 120 transformed observations each.

Manuscript-facing outputs:

- `long_sample_internal_forecasts_1983_2025.csv`
- `long_sample_internal_fits_1983_2025.csv`
- `table_long_sample_internal_mae_long.csv`
- `table_long_sample_internal_mae_wide.csv`
- `table_long_sample_revision.csv`
- `table_long_sample_signed_revision_decomposition.csv`
- `check_2020_internal_mae.csv`
- `check_2020_internal_revision.csv`
- `check_EMPLOY_2020_05_forecasts.csv`
- `LONG_SAMPLE_SUMMARY.txt`

Processed inputs:

- `long_sample_training_1983_2025.csv`
- `long_sample_release_targets_1983_2025.csv`
- `long_sample_origin_manifest_1983_2025.csv`

Validation records are under `validation/`. The January 2018--June 2025 ten-method benchmark remains a separate restricted-sample analysis elsewhere in the package and is not part of this four-method primary long-sample output.
