# Raw RTDSM workbooks

Place the following Federal Reserve Bank of Philadelphia RTDSM workbooks in this directory, or pass a different directory with `--raw-dir`:

- `employMvMd.xlsx`
- `employ_level_first_second_third.xlsx`
- `iptMvMd.xlsx`
- `ipt_first_second_third.xlsx`
- `ipmMvMd.xlsx`
- `ipm_first_second_third.xlsx`
- `hMvMd.xlsx`
- `h_first_second_third.xlsx`
- `cutMvMd.xlsx`
- `cut_first_second_third.xlsx`

The provider workbooks are intentionally not redistributed in this extension package.
