# Python cross-check note

Before the canonical R extension was assembled, the long-sample internal-method analysis was independently reconstructed in Python from the manuscript/supplement specifications.

The provisional Python MAEs used only as diagnostic references were:

| Method | EMPLOY | IPT | IPM | H | CUT |
|---|---:|---:|---:|---:|---:|
| Gaussian-ST | 233.344 | 6.297 | 7.104 | 5.413 | 0.545 |
| Huber-ST | 178.144 | 6.249 | 7.014 | 5.325 | 0.623 |
| MB-ST | 177.454 | 6.230 | 7.023 | 5.321 | 0.664 |
| CB-ST | 176.766 | 6.216 | 7.024 | 5.335 | 0.629 |

Approximate provisional mean absolute full-refit revisions were:

- EMPLOY: Gaussian 20.95, Huber 25.17, MB 26.05, CB 28.34
- CUT: Gaussian 0.256, Huber 0.241, MB 0.236, CB 0.235

These values are **not** the acceptance target. The authoritative acceptance test is reproduction of the frozen 2018--2025 R outputs by the unchanged canonical R estimator source. `R/05_compare_python_reference.R` reports R-versus-Python differences after the canonical R run completes.
