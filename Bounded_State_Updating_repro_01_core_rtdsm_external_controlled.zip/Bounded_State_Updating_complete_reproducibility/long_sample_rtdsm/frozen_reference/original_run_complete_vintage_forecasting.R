options(stringsAsFactors = FALSE, warn = 1)
# Run from this realtime directory. Results are written separately from frozen evidence.
INPUT <- normalizePath('.', mustWork=TRUE)
OUT <- file.path(INPUT, 'reproduced');dir.create(OUT, showWarnings=FALSE)
METHOD_ROOT <- file.path(INPUT, '..', 'method_code', 'R')
ADAPTER <- file.path(INPUT, '..', 'method_code', 'gate_f_fitted_adapters.R')
for (rf in c("rst_o_config.R","rst_o_filters.R","rst_o_objectives.R","rst_o_optimizer.R","rst_o_fit.R","rst_o_forecast.R")) source(file.path(METHOD_ROOT, rf))
source(ADAPTER)
stopifnot(requireNamespace("robets", quietly = TRUE), as.character(packageVersion("robets")) == "1.4")

source(file.path(INPUT, '..', 'method_code', 'author_rt_functions.R'))
fit_bundle <- function(y) {
  list(
    ST_AUTHOR = fit_author_gaussian(y, 1L),
    G_MATCH = rst_o_fit(y, nu = Inf),
    HUBER_ST = gate_f_optimize(y, method = "HUBER"),
    MB_ST = gate_f_optimize(y, method = "MB"),
    CB_ST = rst_o_fit(y, nu = 5),
    ROBETS = robets::robets(stats::ts(y, frequency = 1))
  )
}
forecast_bundle <- function(fits) c(
  ST_AUTHOR = unname(fits$ST_AUTHOR$mean[1L]),
  G_MATCH = unname(rst_o_forecast(fits$G_MATCH, 1L)[1L]),
  HUBER_ST = unname(gate_f_forecast(fits$HUBER_ST, 1L)[1L]),
  MB_ST = unname(gate_f_forecast(fits$MB_ST, 1L)[1L]),
  CB_ST = unname(rst_o_forecast(fits$CB_ST, 1L)[1L]),
  ROBETS = unname(as.numeric(robets::forecast.robets(fits$ROBETS, h = 1)$mean[1L])),
  NAIVE = NA_real_
)
forecast_frozen_ref_params_on_pre <- function(pre, ref_fits, initial_state) c(
  ST_AUTHOR = unname(fixed_author_gaussian(pre, ref_fits$ST_AUTHOR$omega, ref_fits$ST_AUTHOR$q, 1L, initial_state=initial_state)[1L]),
  G_MATCH = unname(rst_o_forecast(rst_o_filter_gaussian(pre, ref_fits$G_MATCH$omega_hat, ref_fits$G_MATCH$q_hat, initial_state=initial_state), 1L)[1L]),
  HUBER_ST = unname(gate_f_forecast(gate_f_huber_filter(pre, ref_fits$HUBER_ST$fit_inputs$omega, ref_fits$HUBER_ST$fit_inputs$q, ref_fits$HUBER_ST$fit_inputs$H, initial_state=initial_state), 1L)[1L]),
  MB_ST = unname(gate_f_forecast(gate_f_mb_filter(pre, ref_fits$MB_ST$fit_inputs$omega, ref_fits$MB_ST$fit_inputs$q, ref_fits$MB_ST$fit_inputs$H, initial_state=initial_state), 1L)[1L]),
  CB_ST = unname(rst_o_forecast(rst_o_filter_finite_nu(pre, ref_fits$CB_ST$omega_hat, ref_fits$CB_ST$q_hat, ref_fits$CB_ST$H_hat, 5, initial_state=initial_state), 1L)[1L])
)

read_fst <- function(series_name) {
  d <- read.csv(file.path(INPUT, 'frozen_release_targets.csv'), check.names=FALSE)
  d <- d[d$series == series_name, ]
  data.frame(date=as.Date(d$target_date), First=d$target_first, Second=d$target_second,
             Third=d$target_third, Most_Recent=d$target_most_recent)
}

train <- read.csv(file.path(INPUT, "complete_vintage_training_long.csv"), fileEncoding = "UTF-8-BOM", check.names = FALSE)
train$target <- as.Date(train$target); train$train_date <- as.Date(train$train_date); train$y <- as.numeric(train$y)
stopifnot(nrow(train) == 5L * 90L * 2L * 120L)
stopifnot(!anyDuplicated(train[c("series","target","interface","train_date")]))
stopifnot(all(is.finite(train$y)))

series_names <- c("EMPLOY","IPT","IPM","H","CUT")
truth_map <- setNames(lapply(series_names, read_fst), series_names)
methods <- c("ST_AUTHOR","G_MATCH","HUBER_ST","MB_ST","CB_ST","ROBETS","NAIVE")
all_rows <- list(); rr <- 0L; frozen_rows <- list(); fr <- 0L; manifest <- list(); mr <- 0L

for (sn in series_names) {
  targets <- sort(unique(train$target[train$series == sn]))
  for (jj in seq_along(targets)) {
    tt <- targets[jj]
    pre_d <- train[train$series == sn & train$target == tt & train$interface == "PRE", c("train_date","y")]
    ref_d <- train[train$series == sn & train$target == tt & train$interface == "REF", c("train_date","y")]
    pre_d <- pre_d[order(pre_d$train_date),]; ref_d <- ref_d[order(ref_d$train_date),]
    stopifnot(nrow(pre_d) == 120L, nrow(ref_d) == 120L, identical(pre_d$train_date, ref_d$train_date), max(pre_d$train_date) < tt)
    pre <- pre_d$y; ref <- ref_d$y
    td <- truth_map[[sn]]; ti <- match(tt, td$date); stopifnot(!is.na(ti), is.finite(td$Third[ti]))
    truth <- td$Third[ti]

    pre_fits <- fit_bundle(pre); ref_fits <- fit_bundle(ref)
    fpre <- forecast_bundle(pre_fits); fref <- forecast_bundle(ref_fits)
    fpre["NAIVE"] <- tail(pre, 1L); fref["NAIVE"] <- tail(ref, 1L)
    last_rev <- tail(ref - pre, 1L); recent3 <- mean(abs(tail(ref - pre, 3L))); recent12 <- mean(abs(tail(ref - pre, 12L)))

    mr <- mr + 1L
    manifest[[mr]] <- data.frame(series=sn,target_date=tt,n_train=nrow(pre_d),train_start=min(pre_d$train_date),train_end=max(pre_d$train_date),truth_third=truth,target_first=td$First[ti],target_second=td$Second[ti],target_third=td$Third[ti],target_most_recent=td$Most_Recent[ti])

    for (m in methods) {
      rr <- rr + 1L
      all_rows[[rr]] <- data.frame(
        series=sn,target_date=tt,method=m,truth_third=truth,
        forecast_pre_realtime=unname(fpre[m]),forecast_ref_replay=unname(fref[m]),
        abs_error_pre=abs(unname(fpre[m])-truth),abs_error_ref=abs(unname(fref[m])-truth),
        sq_error_pre=(unname(fpre[m])-truth)^2,sq_error_ref=(unname(fref[m])-truth)^2,
        forecast_revision_abs=abs(unname(fref[m])-unname(fpre[m])),
        training_last_revision=last_rev,recent3_revision_mae=recent3,recent12_revision_mae=recent12,
        target_first=td$First[ti],target_second=td$Second[ti],target_third=td$Third[ti],target_most_recent=td$Most_Recent[ti]
      )
    }

    frozen_pre <- forecast_frozen_ref_params_on_pre(pre, ref_fits, initial_state=ref[1L])
    frozen_ref <- fref[names(frozen_pre)]
    for (m in names(frozen_pre)) {
      fr <- fr + 1L
      frozen_rows[[fr]] <- data.frame(
        series=sn,target_date=tt,method=m,truth_third=truth,
        forecast_pre_refparams=unname(frozen_pre[m]),forecast_ref_refparams=unname(frozen_ref[m]),
        abs_error_pre_refparams=abs(unname(frozen_pre[m])-truth),abs_error_ref_refparams=abs(unname(frozen_ref[m])-truth),
        forecast_revision_abs_refparams=abs(unname(frozen_ref[m])-unname(frozen_pre[m])),
        training_last_revision=last_rev,recent3_revision_mae=recent3
      )
    }
    if (jj %% 10L == 0L || jj == length(targets)) cat(sprintf("%s completed %d/%d target=%s\n", sn, jj, length(targets), tt))
  }
}

res <- do.call(rbind, all_rows); frozen <- do.call(rbind, frozen_rows); manifest <- do.call(rbind, manifest)
phase <- function(x) ifelse(x <= as.Date("2020-02-01"), "PRE_COVID_2018_TO_2020_02",
                     ifelse(x <= as.Date("2020-07-01"), "COVID_SHOCK_2020_03_TO_07",
                     ifelse(x <= as.Date("2021-12-01"), "RECOVERY_2020_08_TO_2021_12", "POST_2022_TO_2025_06")))
res$phase <- phase(res$target_date); frozen$phase <- phase(frozen$target_date)
res$revision_benefit_abs <- res$abs_error_pre - res$abs_error_ref
frozen$revision_benefit_abs_refparams <- frozen$abs_error_pre_refparams - frozen$abs_error_ref_refparams

write.csv(manifest, file.path(OUT,"complete_vintage_origin_manifest.csv"), row.names=FALSE)
write.csv(res, file.path(OUT,"complete_vintage_full_refit_long.csv"), row.names=FALSE)
write.csv(frozen, file.path(OUT,"complete_vintage_ref_frozen_long.csv"), row.names=FALSE)

summ <- aggregate(cbind(abs_error_pre,abs_error_ref,forecast_revision_abs,revision_benefit_abs) ~ series + phase + method, data=res, FUN=mean)
rmse <- aggregate(cbind(sq_error_pre,sq_error_ref) ~ series + phase + method, data=res, FUN=mean)
rmse$RMSE_pre <- sqrt(rmse$sq_error_pre); rmse$RMSE_ref <- sqrt(rmse$sq_error_ref); rmse$sq_error_pre <- rmse$sq_error_ref <- NULL
summ <- merge(summ,rmse,by=c("series","phase","method"))
write.csv(summ,file.path(OUT,"complete_vintage_phase_summary.csv"),row.names=FALSE)

fsumm <- aggregate(cbind(abs_error_pre_refparams,abs_error_ref_refparams,forecast_revision_abs_refparams,revision_benefit_abs_refparams) ~ series + phase + method, data=frozen, FUN=mean)
write.csv(fsumm,file.path(OUT,"complete_vintage_ref_frozen_phase_summary.csv"),row.names=FALSE)

contr <- list(); cc <- 0L
for (sn in unique(res$series)) for (ph in unique(res$phase)) {
  g <- res[res$series == sn & res$phase == ph & res$method == "G_MATCH", c("target_date","revision_benefit_abs","forecast_revision_abs")]
  names(g)[2:3] <- c("g_benefit","g_sens")
  for (m in setdiff(methods,"G_MATCH")) {
    z <- res[res$series == sn & res$phase == ph & res$method == m, c("target_date","revision_benefit_abs","forecast_revision_abs")]
    zz <- merge(z,g,by="target_date")
    cc <- cc + 1L
    contr[[cc]] <- data.frame(series=sn,phase=ph,method=m,n=nrow(zz),mean_revision_benefit_diff_vs_g=mean(zz$revision_benefit_abs-zz$g_benefit),mean_forecast_sensitivity_diff_vs_g=mean(zz$forecast_revision_abs-zz$g_sens))
  }
}
write.csv(do.call(rbind,contr),file.path(OUT,"complete_vintage_method_contrasts_vs_g.csv"),row.names=FALSE)
cat("COMPLETE VINTAGE FORECASTING DONE\n")
