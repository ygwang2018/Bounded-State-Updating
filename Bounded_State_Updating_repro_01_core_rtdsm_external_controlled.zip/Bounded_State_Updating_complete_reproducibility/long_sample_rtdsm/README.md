# Long-sample RTDSM R extension (self-contained method source)

This extension rebuilds the real-time RTDSM analysis for the balanced period **July 1983--June 2025** using the **same canonical R estimator code** contained in the previously supplied IJF reproducibility package.

The estimator source files are copied into this package under `method_code/`; the long-sample scripts source those local copies. Therefore, after the ten public RTDSM Excel workbooks are supplied, this extension does **not** require the old IJF ZIP at run time.

## What is copied unchanged from the existing IJF package

The following canonical method files are copied verbatim from `IJF_ANONYMOUS_REPRODUCIBILITY_PACKAGE_RST_O_FINAL_20260913`:

- `method_code/R/rst_o_config.R`
- `method_code/R/rst_o_filters.R`
- `method_code/R/rst_o_objectives.R`
- `method_code/R/rst_o_optimizer.R`
- `method_code/R/rst_o_fit.R`
- `method_code/R/rst_o_forecast.R`
- `method_code/gate_f_fitted_adapters.R`

The original 2018--2025 RTDSM runner is retained under `frozen_reference/original_run_complete_vintage_forecasting.R` for provenance. The frozen 2018--2025 transformed inputs, release targets, origin manifest, and R1 forecast output are also included so the new pipeline can run a strict regression test before producing any long-sample results.

See `PROVENANCE.md` and `SHA256SUMS.txt`.

## Statistical scope

The extended run covers the four internally implemented Structural Theta procedures:

- Gaussian-ST (`G_MATCH` in the frozen code)
- Huber-ST (`HUBER_ST`)
- MB-ST (`MB_ST`)
- CB-ST (`CB_ST`)

It uses the original fitting code unchanged: diffuse working variance `kappa = 1e4`, Huber `c_H = 1.345`, Student `nu = 5`, `q` in `[1e-8,10]`, the training-dependent drift bound, one coordinate sweep, and Brent tolerance `1e-2`.

The package intentionally does **not** claim to extend the external Structural Theta, ROBETS, AutoTheta, ETS, or AutoARIMA benchmarks over 1983--2025. Those can be added separately after the internal long-sample run has been audited.

## Raw data

Place these ten Philadelphia Fed workbooks in `data_raw/`, or pass their directory using `--raw-dir`:

1. `employMvMd.xlsx`
2. `employ_level_first_second_third.xlsx`
3. `iptMvMd.xlsx`
4. `ipt_first_second_third.xlsx`
5. `ipmMvMd.xlsx`
6. `ipm_first_second_third.xlsx`
7. `hMvMd.xlsx`
8. `h_first_second_third.xlsx`
9. `cutMvMd.xlsx`
10. `cut_first_second_third.xlsx`

The raw provider workbooks are not redistributed in this ZIP.

## Required R software

The estimator code uses base R. The data-construction script additionally requires `readxl`:

```r
install.packages("readxl")
```

No Python is required to run the canonical analysis.

## One-command run

From the package root:

```bash
Rscript R/run_all.R --raw-dir=/path/to/RTDSM_workbooks --out-dir=/path/to/output
```

The sequence is:

1. `01_build_long_sample_inputs.R` constructs the balanced July 1983--June 2025 PRE/REF histories.
2. `02_validate_frozen_2018_2025.R` first verifies the reconstructed 2018--2025 transformed inputs and then **refits all four internal methods on every frozen PRE and REF history**, comparing all 3,600 forecasts against `R1_RTDSM_FORECASTS_2018_2025.csv`.
3. `03_run_long_sample_internal.R` runs the four canonical internal methods over all 504 targets per series and performs full-refit and fixed-REF-context revision calculations.
4. `04_summarize_results.R` produces the long-sample MAE/rank tables, revision summaries, signed revision decomposition, and the 2020 checks.
5. `05_compare_python_reference.R` compares the audited R output with the earlier provisional Python reconstruction. The Python values are diagnostic only; the frozen R regression test is the acceptance criterion.

The long run is checkpointed by series under `results/checkpoints/`. To recompute existing checkpoints, add `--overwrite=true`.

## Acceptance rule

**Do not use the long-sample numbers in the manuscript unless**

```text
results/validation/STATUS.txt
```

begins with `PASS:`.

That status means both the reconstructed 2018--2025 data and every D1 internal forecast have reproduced the frozen R evidence within the specified numerical tolerance.

## Expected sample dimensions

- 504 target months per series
- 5 series
- 2,520 series-origin forecast cases
- 5,040 PRE/REF histories
- 120 transformed observations per history
- 604,800 transformed training observations

The balanced period begins in July 1983 because CUT determines the common feasible start.

## Main outputs

After a successful complete run:

- `long_sample_internal_forecasts_1983_2025.csv`
- `long_sample_internal_fits_1983_2025.csv`
- `table_long_sample_internal_mae_long.csv`
- `table_long_sample_internal_mae_wide.csv`
- `table_long_sample_internal_mae.tex`
- `table_long_sample_revision.csv`
- `table_long_sample_signed_revision_decomposition.csv`
- `check_2020_internal_mae.csv`
- `check_EMPLOY_2020_05_forecasts.csv`
- `comparison_R_vs_provisional_Python_MAE.csv`
- `comparison_R_vs_provisional_Python_revision.csv`
- `LONG_SAMPLE_SUMMARY.txt`

