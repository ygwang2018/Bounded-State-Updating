# Provenance

The canonical estimator source and frozen 2018--2025 validation artifacts in this extension come from the earlier validated reproducibility package used for the same study.

## Canonical source mapping

| This module | Source in the validated package |
|---|---|
| `method_code/R/rst_o_config.R` | `method_code/R/rst_o_config.R` |
| `method_code/R/rst_o_filters.R` | `method_code/R/rst_o_filters.R` |
| `method_code/R/rst_o_objectives.R` | `method_code/R/rst_o_objectives.R` |
| `method_code/R/rst_o_optimizer.R` | `method_code/R/rst_o_optimizer.R` |
| `method_code/R/rst_o_fit.R` | `method_code/R/rst_o_fit.R` |
| `method_code/R/rst_o_forecast.R` | `method_code/R/rst_o_forecast.R` |
| `method_code/gate_f_fitted_adapters.R` | `method_code/gate_f_fitted_adapters.R` |
| `frozen_reference/original_run_complete_vintage_forecasting.R` | `realtime/run_complete_vintage_forecasting.R` |
| `frozen_reference/complete_vintage_training_2018_2025.csv` | `realtime/complete_vintage_training_long.csv` |
| `frozen_reference/frozen_release_targets_2018_2025.csv` | `realtime/frozen_release_targets.csv` |
| `frozen_reference/complete_vintage_origin_manifest_2018_2025.csv` | `realtime/complete_vintage_origin_manifest.csv` |
| `frozen_reference/R1_RTDSM_FORECASTS_2018_2025.csv` | `R1_R2/03_R1_RTDSM/R1_RTDSM_FORECASTS.csv` |

The long-sample scripts in `R/` extend the information-set construction to July 1983--June 2025. They do not alter the canonical estimator definitions. The public provider workbooks are intentionally not redistributed.
