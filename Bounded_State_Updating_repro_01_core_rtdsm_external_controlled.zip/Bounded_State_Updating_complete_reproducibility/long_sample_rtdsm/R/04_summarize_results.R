cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
fc_path <- file.path(out_dir, "long_sample_internal_forecasts_1983_2025.csv")
if (!file.exists(fc_path)) stop("Missing combined long-sample forecasts. Run 03_run_long_sample_internal.R for all five series first.", call. = FALSE)

fc <- bsu_read_csv(fc_path)
fc$target_date <- as.Date(fc$target_date)
fc$abs_error_pre <- as.numeric(fc$abs_error_pre)
fc$forecast_revision_abs <- as.numeric(fc$forecast_revision_abs)
fc$fixed_state_revision_abs <- as.numeric(fc$fixed_state_revision_abs)

series_order <- c("EMPLOY", "IPT", "IPM", "H", "CUT")
method_order <- names(bsu_method_display)

expected_rows <- length(series_order) * 504L * length(method_order)
if (nrow(fc) != expected_rows) stop("Unexpected long-sample forecast row count: ", nrow(fc), call. = FALSE)
if (!setequal(unique(fc$series), series_order) || !setequal(unique(fc$method), method_order)) {
  stop("Long-sample forecast panel has an unexpected series or method set.", call. = FALSE)
}
if (anyDuplicated(fc[c("series", "target_date", "method")])) {
  stop("Duplicate series-target-method rows in long-sample forecasts.", call. = FALSE)
}
target_counts <- table(fc$series, fc$method)
if (any(target_counts != 504L) ||
    min(fc$target_date) != as.Date("1983-07-01") ||
    max(fc$target_date) != as.Date("2025-06-01")) {
  stop("Long-sample forecast panel is not the required 504-target July 1983--June 2025 design.", call. = FALSE)
}
numeric_check <- c("target_third", "forecast_pre", "forecast_ref", "abs_error_pre",
                   "abs_error_ref", "forecast_revision", "forecast_revision_abs",
                   "forecast_pre_fixed_ref", "forecast_ref_fixed_ref",
                   "fixed_state_revision", "fixed_state_revision_abs",
                   "signed_refit_channel", "signed_total_change_pre_to_ref")
if (any(!vapply(fc[numeric_check], function(x) all(is.finite(as.numeric(x))), logical(1L)))) {
  stop("Non-finite value in required long-sample forecast fields.", call. = FALSE)
}

# Long-sample PRE MAE by series and method.
mae <- aggregate(abs_error_pre ~ series + method + method_display, data = fc, FUN = mean)
mae$series <- factor(mae$series, levels = series_order)
mae$method <- factor(mae$method, levels = method_order)
mae <- mae[order(mae$series, mae$method), ]
mae$rank <- ave(mae$abs_error_pre, mae$series, FUN = function(x) rank(x, ties.method = "average"))
mae$series <- as.character(mae$series); mae$method <- as.character(mae$method)
bsu_write_csv(mae, file.path(out_dir, "table_long_sample_internal_mae_long.csv"))

# Wide table with mean rank.
wide <- data.frame(method = method_order, method_display = unname(bsu_method_display[method_order]), stringsAsFactors = FALSE)
rankwide <- data.frame(method = method_order, stringsAsFactors = FALSE)
for (sn in series_order) {
  z <- mae[mae$series == sn, c("method", "abs_error_pre", "rank")]
  wide[[sn]] <- z$abs_error_pre[match(wide$method, z$method)]
  rankwide[[sn]] <- z$rank[match(rankwide$method, z$method)]
}
wide$mean_rank <- rowMeans(rankwide[series_order])
bsu_write_csv(wide, file.path(out_dir, "table_long_sample_internal_mae_wide.csv"))

# Full-refit and fixed-context mean absolute revision statistics.
rev <- aggregate(cbind(forecast_revision_abs, fixed_state_revision_abs) ~ series + method + method_display,
                 data = fc, FUN = mean)
rev$series <- factor(rev$series, levels = series_order)
rev$method <- factor(rev$method, levels = method_order)
rev <- rev[order(rev$series, rev$method), ]
rev$series <- as.character(rev$series); rev$method <- as.character(rev$method)
bsu_write_csv(rev, file.path(out_dir, "table_long_sample_revision.csv"))

# Signed decomposition summaries. Mean signed terms are additive by construction.
dec <- aggregate(cbind(fixed_state_revision, signed_refit_channel, signed_total_change_pre_to_ref) ~ series + method + method_display,
                 data = fc, FUN = mean)
dec$additivity_error <- dec$fixed_state_revision + dec$signed_refit_channel - dec$signed_total_change_pre_to_ref
bsu_write_csv(dec, file.path(out_dir, "table_long_sample_signed_revision_decomposition.csv"))

# March--July 2020 internal-method check on the extended run.
covid <- fc[fc$target_date >= as.Date("2020-03-01") & fc$target_date <= as.Date("2020-07-01"), ]
covid_mae <- aggregate(abs_error_pre ~ series + method + method_display, data = covid, FUN = mean)
covid_rev <- aggregate(forecast_revision_abs ~ series + method + method_display, data = covid, FUN = mean)
bsu_write_csv(covid_mae, file.path(out_dir, "check_2020_internal_mae.csv"))
bsu_write_csv(covid_rev, file.path(out_dir, "check_2020_internal_revision.csv"))

# Explicit EMPLOY May 2020 forecasts, used in the manuscript mechanism discussion.
may20 <- fc[fc$series == "EMPLOY" & fc$target_date == as.Date("2020-05-01"),
            c("method", "method_display", "target_third", "forecast_pre", "forecast_ref", "forecast_pre_fixed_ref")]
bsu_write_csv(may20, file.path(out_dir, "check_EMPLOY_2020_05_forecasts.csv"))

# Generate a compact LaTeX body for the four-method long-sample table.
fmt <- function(x) sprintf("%.3f", x)
rankfmt <- function(x) if (abs(x - round(x)) < 1e-12) sprintf("%d", as.integer(round(x))) else sprintf("%.1f", x)
tex_lines <- c(
  "% Generated by R/04_summarize_results.R",
  "\\begin{tabular}{@{}lrrrrrr@{}}",
  "\\toprule",
  "Method & EMPLOY & IPT & IPM & H & CUT & Mean rank \\\\",
  "\\midrule"
)
for (i in seq_len(nrow(wide))) {
  m <- wide$method[i]
  vals <- character(length(series_order))
  for (j in seq_along(series_order)) {
    sn <- series_order[j]
    val <- wide[[sn]][i]
    rk <- rankwide[[sn]][i]
    is_min <- rk == min(rankwide[[sn]])
    txt <- paste0(fmt(val), " (", rankfmt(rk), ")")
    if (is_min) txt <- paste0("\\textbf{", txt, "}")
    vals[j] <- txt
  }
  mr <- wide$mean_rank[i]
  is_best_mr <- abs(mr - min(wide$mean_rank)) < 1e-12
  mrtxt <- sprintf("%.2f", mr)
  if (is_best_mr) mrtxt <- paste0("\\textbf{", mrtxt, "}")
  tex_lines <- c(tex_lines, paste0(wide$method_display[i], " & ", paste(vals, collapse = " & "), " & ", mrtxt, " \\\\"))
}
tex_lines <- c(tex_lines, "\\bottomrule", "\\end{tabular}")
writeLines(tex_lines, file.path(out_dir, "table_long_sample_internal_mae.tex"))

# Human-readable audit summary.
summary_txt <- c(
  "LONG-SAMPLE INTERNAL-METHOD SUMMARY",
  "Period: July 1983--June 2025",
  "Targets per series: 504",
  "Series-origin cases: 2520",
  "Methods: Gaussian-ST, Huber-ST, MB-ST, CB-ST",
  "",
  "MAE table:",
  capture.output(print(wide, row.names = FALSE)),
  "",
  "Mean absolute revisions:",
  capture.output(print(rev, row.names = FALSE)),
  "",
  "Maximum signed decomposition additivity error:",
  format(max(abs(dec$additivity_error)), digits = 16)
)
writeLines(summary_txt, file.path(out_dir, "LONG_SAMPLE_SUMMARY.txt"))
cat(paste(summary_txt, collapse = "\n"), "\n")
