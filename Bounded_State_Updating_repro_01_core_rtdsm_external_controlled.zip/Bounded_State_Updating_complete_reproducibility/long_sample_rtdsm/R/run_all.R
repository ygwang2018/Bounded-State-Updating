cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
raw_dir <- bsu_get_arg(args, "raw-dir", file.path(root, "data_raw"))
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
overwrite <- bsu_as_flag(bsu_get_arg(args, "overwrite", FALSE))

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
rscript <- file.path(R.home("bin"), "Rscript")
if (!file.exists(rscript)) rscript <- Sys.which("Rscript")
if (!nzchar(rscript) || !file.exists(rscript)) stop("Cannot locate Rscript.", call. = FALSE)

run_one <- function(script, extra = character()) {
  cmd_args <- c(file.path(script_dir0, script),
                paste0("--raw-dir=", raw_dir), paste0("--out-dir=", out_dir), extra)
  cat("\n=== Running ", script, " ===\n", sep = "")
  status <- system2(rscript, cmd_args)
  if (!identical(status, 0L)) stop(script, " failed with exit status ", status, call. = FALSE)
}

run_one("01_build_long_sample_inputs.R")
run_one("02_validate_frozen_2018_2025.R")
run_one("03_run_long_sample_internal.R", paste0("--overwrite=", if (overwrite) "true" else "false"))
run_one("04_summarize_results.R")
run_one("05_compare_python_reference.R")

cat("\nALL LONG-SAMPLE STEPS COMPLETED.\n")
cat("Validation status: ", paste(readLines(file.path(out_dir, "validation", "STATUS.txt"), warn = FALSE), collapse = " "), "\n", sep = "")
cat("Main audit summary: ", file.path(out_dir, "LONG_SAMPLE_SUMMARY.txt"), "\n", sep = "")
