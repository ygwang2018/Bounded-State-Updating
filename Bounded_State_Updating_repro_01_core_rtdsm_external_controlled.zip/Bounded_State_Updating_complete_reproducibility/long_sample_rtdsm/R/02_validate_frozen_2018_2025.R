cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
val_dir <- file.path(out_dir, "validation")
dir.create(val_dir, recursive = TRUE, showWarnings = FALSE)
ref_dir <- file.path(root, "frozen_reference")

tol_input <- as.numeric(bsu_get_arg(args, "input-tol", "1e-10"))
tol_forecast <- as.numeric(bsu_get_arg(args, "forecast-tol", "1e-6"))
skip_refit <- bsu_as_flag(bsu_get_arg(args, "skip-refit", FALSE))

new_train_path <- file.path(out_dir, "long_sample_training_1983_2025.csv")
new_target_path <- file.path(out_dir, "long_sample_release_targets_1983_2025.csv")
if (!file.exists(new_train_path) || !file.exists(new_target_path)) {
  stop("Run 01_build_long_sample_inputs.R first.", call. = FALSE)
}

new_train <- bsu_read_csv(new_train_path)
old_train <- bsu_read_csv(file.path(ref_dir, "complete_vintage_training_2018_2025.csv"))
for (nm in c("target", "train_date")) {
  new_train[[nm]] <- as.Date(new_train[[nm]])
  old_train[[nm]] <- as.Date(old_train[[nm]])
}
new_train$y <- as.numeric(new_train$y); old_train$y <- as.numeric(old_train$y)
new_overlap <- new_train[new_train$target >= as.Date("2018-01-01") & new_train$target <= as.Date("2025-06-01"), ]
key <- c("series", "target", "interface", "train_date")
new_overlap <- new_overlap[do.call(order, new_overlap[key]), ]
old_train <- old_train[do.call(order, old_train[key]), ]
if (nrow(new_overlap) != nrow(old_train)) stop("Input overlap row-count mismatch.", call. = FALSE)
if (!identical(as.data.frame(new_overlap[key]), as.data.frame(old_train[key]))) stop("Input overlap key mismatch.", call. = FALSE)
input_diff <- abs(new_overlap$y - old_train$y)
input_max <- max(input_diff)
input_n_bad <- sum(input_diff > tol_input)
input_status <- input_n_bad == 0L

new_targets <- bsu_read_csv(new_target_path)
old_targets <- bsu_read_csv(file.path(ref_dir, "frozen_release_targets_2018_2025.csv"))
new_targets$target_date <- as.Date(new_targets$target_date); old_targets$target_date <- as.Date(old_targets$target_date)
new_targets <- new_targets[new_targets$target_date >= as.Date("2018-01-01") & new_targets$target_date <= as.Date("2025-06-01"), ]
tkey <- c("series", "target_date")
new_targets <- new_targets[do.call(order, new_targets[tkey]), ]
old_targets <- old_targets[do.call(order, old_targets[tkey]), ]
if (nrow(new_targets) != nrow(old_targets)) stop("Target overlap row-count mismatch.", call. = FALSE)
if (!identical(as.data.frame(new_targets[tkey]), as.data.frame(old_targets[tkey]))) stop("Target overlap key mismatch.", call. = FALSE)
target_cols <- c("target_first", "target_second", "target_third", "target_most_recent")
target_diffs <- unlist(Map(function(a, b) abs(as.numeric(a) - as.numeric(b)), new_targets[target_cols], old_targets[target_cols]), use.names = FALSE)
target_diffs <- target_diffs[is.finite(target_diffs)]
target_max <- if (length(target_diffs)) max(target_diffs) else 0
target_n_bad <- sum(target_diffs > tol_input)
target_status <- target_n_bad == 0L

input_summary <- data.frame(
  check = c("transformed_training_values", "release_targets"),
  n_rows = c(nrow(new_overlap), nrow(new_targets)),
  max_abs_difference = c(input_max, target_max),
  tolerance = tol_input,
  n_exceeding_tolerance = c(input_n_bad, target_n_bad),
  status = c(if (input_status) "PASS" else "FAIL", if (target_status) "PASS" else "FAIL")
)
bsu_write_csv(input_summary, file.path(val_dir, "input_overlap_validation.csv"))

if (!input_status || !target_status) {
  writeLines("FAIL: newly built 2018-2025 inputs do not reproduce frozen inputs.", file.path(val_dir, "STATUS.txt"))
  stop("Frozen input regression test failed. See validation/input_overlap_validation.csv", call. = FALSE)
}

if (skip_refit) {
  writeLines("PASS_INPUT_ONLY: frozen inputs reproduced; forecast refit validation skipped by request.", file.path(val_dir, "STATUS.txt"))
  cat("Input validation PASS. Refit validation skipped.\n")
  quit(save = "no", status = 0L)
}

bsu_source_internal_methods(root)
methods <- names(bsu_method_display)
frozen_fc <- bsu_read_csv(file.path(ref_dir, "R1_RTDSM_FORECASTS_2018_2025.csv"))
frozen_fc$target_date <- as.Date(frozen_fc$target_date)
frozen_fc <- frozen_fc[frozen_fc$depth == "D1" & frozen_fc$fit_interface == "full_refit" & frozen_fc$method %in% methods, ]
if (nrow(frozen_fc) != 5L * 90L * 2L * 4L) {
  stop("Unexpected frozen internal forecast row count: ", nrow(frozen_fc), call. = FALSE)
}

hist_keys <- unique(new_overlap[c("series", "target", "interface")])
hist_keys <- hist_keys[order(hist_keys$series, hist_keys$target, hist_keys$interface), ]
rows <- vector("list", nrow(hist_keys) * length(methods)); z <- 0L
for (i in seq_len(nrow(hist_keys))) {
  sn <- hist_keys$series[i]; tt <- hist_keys$target[i]; intf <- hist_keys$interface[i]
  h <- new_overlap[new_overlap$series == sn & new_overlap$target == tt & new_overlap$interface == intf, c("train_date", "y")]
  h <- h[order(h$train_date), ]
  stopifnot(nrow(h) == 120L, all(is.finite(h$y)))
  for (m in methods) {
    fit <- bsu_fit_internal(h$y, m)
    pred <- bsu_forecast_internal(fit, m)
    ref <- frozen_fc[frozen_fc$series == sn & frozen_fc$target_date == tt & frozen_fc$interface == intf & frozen_fc$method == m, ]
    if (nrow(ref) != 1L) stop("Frozen forecast lookup did not return exactly one row.", call. = FALSE)
    z <- z + 1L
    rows[[z]] <- data.frame(series = sn, target_date = tt, interface = intf, method = m,
                            forecast_recomputed = pred, forecast_frozen = as.numeric(ref$forecast_h1),
                            abs_difference = abs(pred - as.numeric(ref$forecast_h1)))
  }
  if (i %% 100L == 0L || i == nrow(hist_keys)) cat(sprintf("Validated %d/%d histories\n", i, nrow(hist_keys)))
}
cmp <- do.call(rbind, rows[seq_len(z)])
bsu_write_csv(cmp, file.path(val_dir, "forecast_overlap_validation.csv"))
forecast_max <- max(cmp$abs_difference)
forecast_n_bad <- sum(cmp$abs_difference > tol_forecast)
forecast_status <- forecast_n_bad == 0L

by_split <- split(cmp$abs_difference, cmp$method)
by_method_out <- do.call(rbind, lapply(names(by_split), function(m) {
  x <- by_split[[m]]
  data.frame(method = m, max_abs_difference = max(x), mean_abs_difference = mean(x))
}))
row.names(by_method_out) <- NULL
bsu_write_csv(by_method_out, file.path(val_dir, "forecast_overlap_validation_by_method.csv"))

may20 <- cmp[cmp$series == "EMPLOY" & cmp$target_date == as.Date("2020-05-01") & cmp$interface == "PRE", ]
bsu_write_csv(may20, file.path(val_dir, "EMPLOY_2020_05_validation.csv"))

if (forecast_status) {
  writeLines(sprintf("PASS: frozen inputs and all %d D1 internal forecasts reproduced within tolerance %.3g; max forecast difference %.12g.", nrow(cmp), tol_forecast, forecast_max), file.path(val_dir, "STATUS.txt"))
  cat("FULL FROZEN VALIDATION PASS. max forecast difference = ", format(forecast_max, digits = 16), "\n", sep = "")
} else {
  writeLines(sprintf("FAIL: %d of %d D1 internal forecasts differ by more than %.3g; max difference %.12g.", forecast_n_bad, nrow(cmp), tol_forecast, forecast_max), file.path(val_dir, "STATUS.txt"))
  stop("Frozen forecast regression test failed. See validation/forecast_overlap_validation.csv", call. = FALSE)
}
