cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
series_arg <- bsu_get_arg(args, "series", "ALL")
overwrite <- bsu_as_flag(bsu_get_arg(args, "overwrite", FALSE))
allow_without_validation <- bsu_as_flag(bsu_get_arg(args, "allow-without-validation", FALSE))

train_path <- file.path(out_dir, "long_sample_training_1983_2025.csv")
target_path <- file.path(out_dir, "long_sample_release_targets_1983_2025.csv")
if (!file.exists(train_path) || !file.exists(target_path)) stop("Run 01_build_long_sample_inputs.R first.", call. = FALSE)

val_status <- file.path(out_dir, "validation", "STATUS.txt")
if (!allow_without_validation) {
  if (!file.exists(val_status)) stop("Frozen validation has not been run. Run 02_validate_frozen_2018_2025.R first.", call. = FALSE)
  status_text <- paste(readLines(val_status, warn = FALSE), collapse = " ")
  if (!grepl("^PASS:", status_text)) {
    stop("Full frozen forecast validation has not passed. STATUS: ", status_text,
         "\nUse --allow-without-validation=true only for debugging, not final results.", call. = FALSE)
  }
}

bsu_source_internal_methods(root)
train <- bsu_read_csv(train_path)
targets <- bsu_read_csv(target_path)
train$target <- as.Date(train$target); train$train_date <- as.Date(train$train_date); train$y <- as.numeric(train$y)
targets$target_date <- as.Date(targets$target_date)

all_series <- c("EMPLOY", "IPT", "IPM", "H", "CUT")
series_to_run <- if (toupper(series_arg) == "ALL") all_series else strsplit(series_arg, ",", fixed = TRUE)[[1L]]
series_to_run <- trimws(series_to_run)
if (!all(series_to_run %in% all_series)) stop("Unknown --series value. Use ALL or a comma-separated subset of EMPLOY,IPT,IPM,H,CUT.", call. = FALSE)
methods <- names(bsu_method_display)
checkpoint_dir <- file.path(out_dir, "checkpoints")
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)

run_series <- function(sn) {
  forecast_file <- file.path(checkpoint_dir, paste0("forecasts_", sn, ".csv"))
  fit_file <- file.path(checkpoint_dir, paste0("fits_", sn, ".csv"))
  if (!overwrite && file.exists(forecast_file) && file.exists(fit_file)) {
    old_fc <- try(bsu_read_csv(forecast_file), silent = TRUE)
    old_fit <- try(bsu_read_csv(fit_file), silent = TRUE)
    complete_checkpoint <- !inherits(old_fc, "try-error") && !inherits(old_fit, "try-error") &&
      nrow(old_fc) == 504L * length(methods) && nrow(old_fit) == 504L * length(methods) * 2L
    if (complete_checkpoint) {
      cat("Using complete existing checkpoint for ", sn, "\n", sep = "")
      return(invisible(NULL))
    }
    cat("Existing checkpoint for ", sn, " is incomplete; recomputing this series.\n", sep = "")
  }

  ts <- sort(unique(train$target[train$series == sn]))
  if (length(ts) != 504L) stop(sn, ": expected 504 target months, found ", length(ts), call. = FALSE)
  fc_rows <- vector("list", length(ts) * length(methods))
  fit_rows <- vector("list", length(ts) * length(methods) * 2L)
  fci <- 0L; fi <- 0L

  for (jj in seq_along(ts)) {
    tt <- ts[jj]
    pre_d <- train[train$series == sn & train$target == tt & train$interface == "PRE", c("train_date", "y")]
    ref_d <- train[train$series == sn & train$target == tt & train$interface == "REF", c("train_date", "y")]
    pre_d <- pre_d[order(pre_d$train_date), ]; ref_d <- ref_d[order(ref_d$train_date), ]
    stopifnot(nrow(pre_d) == 120L, nrow(ref_d) == 120L, identical(pre_d$train_date, ref_d$train_date))
    pre <- pre_d$y; ref <- ref_d$y
    tr <- targets[targets$series == sn & targets$target_date == tt, ]
    if (nrow(tr) != 1L || !is.finite(tr$target_third)) stop("Target lookup failed for ", sn, " ", tt, call. = FALSE)
    truth <- as.numeric(tr$target_third)

    for (m in methods) {
      pre_fit <- bsu_fit_internal(pre, m)
      ref_fit <- bsu_fit_internal(ref, m)
      fpre <- bsu_forecast_internal(pre_fit, m)
      fref <- bsu_forecast_internal(ref_fit, m)
      fpre_fixed_ref <- bsu_fixed_ref_pre_forecast(pre, ref, ref_fit, m)
      # Replaying REF under its own fitted context equals the full-refit REF forecast.
      fref_fixed_ref <- fref

      fci <- fci + 1L
      fc_rows[[fci]] <- data.frame(
        series = sn, target_date = tt, method = m, method_display = unname(bsu_method_display[m]),
        target_third = truth,
        forecast_pre = fpre, forecast_ref = fref,
        abs_error_pre = abs(fpre - truth), abs_error_ref = abs(fref - truth),
        sq_error_pre = (fpre - truth)^2, sq_error_ref = (fref - truth)^2,
        forecast_revision = fref - fpre, forecast_revision_abs = abs(fref - fpre),
        forecast_pre_fixed_ref = fpre_fixed_ref, forecast_ref_fixed_ref = fref_fixed_ref,
        fixed_state_revision = fref_fixed_ref - fpre_fixed_ref,
        fixed_state_revision_abs = abs(fref_fixed_ref - fpre_fixed_ref),
        signed_refit_channel = fpre_fixed_ref - fpre,
        signed_total_change_pre_to_ref = fref - fpre
      )

      pp <- bsu_fit_params(pre_fit, m); rp <- bsu_fit_params(ref_fit, m)
      fi <- fi + 1L
      fit_rows[[fi]] <- data.frame(series = sn, target_date = tt, interface = "PRE", method = m,
                                   q = pp$q, omega = pp$omega, H = pp$H, objective = pp$objective,
                                   selected_source = pp$selected_source)
      fi <- fi + 1L
      fit_rows[[fi]] <- data.frame(series = sn, target_date = tt, interface = "REF", method = m,
                                   q = rp$q, omega = rp$omega, H = rp$H, objective = rp$objective,
                                   selected_source = rp$selected_source)
    }

    if (jj %% 25L == 0L || jj == length(ts)) {
      cat(sprintf("%s completed %d/%d target=%s\n", sn, jj, length(ts), tt))
      # Write rolling checkpoints so an interrupted run loses at most 24 origins.
      bsu_write_csv(do.call(rbind, fc_rows[seq_len(fci)]), forecast_file)
      bsu_write_csv(do.call(rbind, fit_rows[seq_len(fi)]), fit_file)
    }
  }
  invisible(NULL)
}

for (sn in series_to_run) run_series(sn)

# Combine all available series checkpoints. A final all-series result requires all five.
avail_fc <- file.path(checkpoint_dir, paste0("forecasts_", all_series, ".csv"))
avail_fit <- file.path(checkpoint_dir, paste0("fits_", all_series, ".csv"))
if (all(file.exists(avail_fc)) && all(file.exists(avail_fit))) {
  fc <- do.call(rbind, lapply(avail_fc, bsu_read_csv))
  fits <- do.call(rbind, lapply(avail_fit, bsu_read_csv))
  fc$target_date <- as.Date(fc$target_date); fits$target_date <- as.Date(fits$target_date)
  fc <- fc[order(match(fc$series, all_series), fc$target_date, match(fc$method, methods)), ]
  fits <- fits[order(match(fits$series, all_series), fits$target_date, fits$interface, match(fits$method, methods)), ]
  stopifnot(nrow(fc) == 5L * 504L * 4L)
  stopifnot(nrow(fits) == 5L * 504L * 4L * 2L)
  bsu_write_csv(fc, file.path(out_dir, "long_sample_internal_forecasts_1983_2025.csv"))
  bsu_write_csv(fits, file.path(out_dir, "long_sample_internal_fits_1983_2025.csv"))
  cat("Combined all five series into final long-sample output files.\n")
} else {
  cat("Not all five series checkpoints are present. Run remaining series to create combined outputs.\n")
}
