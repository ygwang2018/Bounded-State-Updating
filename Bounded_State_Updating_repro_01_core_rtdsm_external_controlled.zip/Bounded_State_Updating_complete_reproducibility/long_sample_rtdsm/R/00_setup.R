options(stringsAsFactors = FALSE, warn = 1)

bsu_script_dir <- function() {
  cmd <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd, value = TRUE)
  if (length(file_arg)) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1L]), mustWork = TRUE)))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

bsu_package_root <- function() {
  sd <- bsu_script_dir()
  if (basename(sd) == "R") dirname(sd) else sd
}

bsu_parse_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  out <- list()
  i <- 1L
  while (i <= length(args)) {
    a <- args[i]
    if (grepl("^--[^=]+=", a)) {
      key <- sub("^--([^=]+)=.*$", "\\1", a)
      val <- sub("^--[^=]+=", "", a)
      out[[key]] <- val
      i <- i + 1L
    } else if (grepl("^--", a)) {
      key <- sub("^--", "", a)
      if (i < length(args) && !grepl("^--", args[i + 1L])) {
        out[[key]] <- args[i + 1L]
        i <- i + 2L
      } else {
        out[[key]] <- TRUE
        i <- i + 1L
      }
    } else {
      i <- i + 1L
    }
  }
  out
}

bsu_get_arg <- function(args, key, default = NULL) {
  if (!is.null(args[[key]])) args[[key]] else default
}

bsu_as_flag <- function(x, default = FALSE) {
  if (is.null(x)) return(default)
  if (is.logical(x)) return(isTRUE(x))
  tolower(as.character(x)) %in% c("1", "true", "yes", "y", "on")
}

bsu_source_internal_methods <- function(root = bsu_package_root()) {
  method_root <- file.path(root, "method_code", "R")
  files <- c(
    "rst_o_config.R",
    "rst_o_filters.R",
    "rst_o_objectives.R",
    "rst_o_optimizer.R",
    "rst_o_fit.R",
    "rst_o_forecast.R"
  )
  missing <- files[!file.exists(file.path(method_root, files))]
  if (length(missing)) stop("Missing method source files: ", paste(missing, collapse = ", "), call. = FALSE)
  for (f in files) source(file.path(method_root, f), local = .GlobalEnv)
  adapter <- file.path(root, "method_code", "gate_f_fitted_adapters.R")
  if (!file.exists(adapter)) stop("Missing adapter source: ", adapter, call. = FALSE)
  source(adapter, local = .GlobalEnv)
  invisible(TRUE)
}

bsu_month_id <- function(year, month) as.integer(year) * 12L + as.integer(month) - 1L

bsu_parse_ym <- function(x) {
  x <- trimws(as.character(x))
  m <- regexec("^([0-9]{4}):([0-9]{1,2})$", x)
  z <- regmatches(x, m)
  ok <- lengths(z) == 3L
  if (!all(ok)) stop("Cannot parse YYYY:MM values: ", paste(unique(x[!ok])[1:min(5, sum(!ok))], collapse = ", "), call. = FALSE)
  yr <- as.integer(vapply(z, `[[`, character(1L), 2L))
  mo <- as.integer(vapply(z, `[[`, character(1L), 3L))
  bsu_month_id(yr, mo)
}

bsu_id_to_date <- function(id) {
  id <- as.integer(id)
  yr <- id %/% 12L
  mo <- id %% 12L + 1L
  as.Date(sprintf("%04d-%02d-01", yr, mo))
}

bsu_date_to_id <- function(x) {
  x <- as.Date(x)
  lt <- as.POSIXlt(x)
  bsu_month_id(lt$year + 1900L, lt$mon + 1L)
}

bsu_parse_vintage_col_id <- function(name, prefix) {
  pat <- paste0("^", prefix, "([0-9]{2,4})M([0-9]{1,2})$")
  m <- regexec(pat, name)
  z <- regmatches(name, m)[[1L]]
  if (length(z) != 3L) return(NA_integer_)
  yr_txt <- z[2L]
  yr <- as.integer(yr_txt)
  if (nchar(yr_txt) == 2L) yr <- if (yr <= 49L) 2000L + yr else 1900L + yr
  mo <- as.integer(z[3L])
  bsu_month_id(yr, mo)
}

bsu_require <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Required R package is not installed: ", pkg, "\nInstall with install.packages('", pkg, "').", call. = FALSE)
  }
}

bsu_read_csv <- function(path) {
  if (!file.exists(path)) stop("Missing file: ", path, call. = FALSE)
  read.csv(path, check.names = FALSE, stringsAsFactors = FALSE, fileEncoding = "UTF-8-BOM")
}

bsu_write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write.csv(x, path, row.names = FALSE, na = "")
}

bsu_method_display <- c(
  G_MATCH = "Gaussian-ST",
  HUBER_ST = "Huber-ST",
  MB_ST = "MB-ST",
  CB_ST = "CB-ST"
)

bsu_fit_internal <- function(y, method) {
  switch(method,
    G_MATCH = rst_o_fit(y, nu = Inf),
    HUBER_ST = gate_f_optimize(y, method = "HUBER"),
    MB_ST = gate_f_optimize(y, method = "MB"),
    CB_ST = rst_o_fit(y, nu = 5),
    stop("Unknown internal method: ", method, call. = FALSE)
  )
}

bsu_forecast_internal <- function(fit, method) {
  switch(method,
    G_MATCH = unname(rst_o_forecast(fit, 1L)[1L]),
    HUBER_ST = unname(gate_f_forecast(fit, 1L)[1L]),
    MB_ST = unname(gate_f_forecast(fit, 1L)[1L]),
    CB_ST = unname(rst_o_forecast(fit, 1L)[1L]),
    stop("Unknown internal method: ", method, call. = FALSE)
  )
}

bsu_fit_params <- function(fit, method) {
  if (method %in% c("G_MATCH", "CB_ST")) {
    data.frame(q = fit$q_hat, omega = fit$omega_hat,
               H = if (!is.null(fit$H_hat)) fit$H_hat else NA_real_,
               objective = if (!is.null(fit$optimizer$objective_final)) fit$optimizer$objective_final else NA_real_,
               selected_source = if (!is.null(fit$optimizer$selected_source)) fit$optimizer$selected_source else NA_character_)
  } else {
    data.frame(q = fit$fit_inputs$q, omega = fit$fit_inputs$omega, H = fit$fit_inputs$H,
               objective = if (!is.null(fit$optimizer$objective_final)) fit$optimizer$objective_final else NA_real_,
               selected_source = if (!is.null(fit$optimizer$selected_source)) fit$optimizer$selected_source else NA_character_)
  }
}

bsu_fixed_ref_pre_forecast <- function(pre, ref, ref_fit, method) {
  initial_state <- ref[1L]
  switch(method,
    G_MATCH = {
      f <- rst_o_filter_gaussian(pre, ref_fit$omega_hat, ref_fit$q_hat, initial_state = initial_state)
      unname(f$a_next_after_train)
    },
    HUBER_ST = {
      f <- gate_f_huber_filter(pre, ref_fit$fit_inputs$omega, ref_fit$fit_inputs$q,
                               ref_fit$fit_inputs$H, initial_state = initial_state)
      unname(gate_f_forecast(f, 1L)[1L])
    },
    MB_ST = {
      f <- gate_f_mb_filter(pre, ref_fit$fit_inputs$omega, ref_fit$fit_inputs$q,
                            ref_fit$fit_inputs$H, initial_state = initial_state)
      unname(gate_f_forecast(f, 1L)[1L])
    },
    CB_ST = {
      f <- rst_o_filter_finite_nu(pre, ref_fit$omega_hat, ref_fit$q_hat,
                                  ref_fit$H_hat, 5, initial_state = initial_state)
      unname(f$a_next_after_train)
    },
    stop("Unknown internal method: ", method, call. = FALSE)
  )
}

bsu_phase_2018 <- function(x) {
  x <- as.Date(x)
  ifelse(x <= as.Date("2020-02-01"), "PRE_COVID_2018_TO_2020_02",
  ifelse(x <= as.Date("2020-07-01"), "COVID_SHOCK_2020_03_TO_07",
  ifelse(x <= as.Date("2021-12-01"), "RECOVERY_2020_08_TO_2021_12", "POST_2022_TO_2025_06")))
}
