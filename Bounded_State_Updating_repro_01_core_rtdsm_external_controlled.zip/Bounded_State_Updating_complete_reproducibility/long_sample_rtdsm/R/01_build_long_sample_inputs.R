cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
raw_dir <- normalizePath(bsu_get_arg(args, "raw-dir", file.path(root, "data_raw")), mustWork = TRUE)
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
old_status <- file.path(out_dir, "validation", "STATUS.txt")
if (file.exists(old_status)) {
  writeLines("STALE: long-sample inputs were rebuilt; rerun frozen-overlap validation.", old_status)
}

bsu_require("readxl")

START_ID <- bsu_month_id(1983L, 7L)
END_ID <- bsu_month_id(2025L, 6L)
TARGET_IDS <- seq.int(START_ID, END_ID)
stopifnot(length(TARGET_IDS) == 504L)

meta <- list(
  EMPLOY = list(vintage = "employMvMd.xlsx", vintage_sheet = "employ",
                target = "employ_level_first_second_third.xlsx", prefix = "EMPLOY", transform = "diff"),
  IPT = list(vintage = "iptMvMd.xlsx", vintage_sheet = "ipt",
             target = "ipt_first_second_third.xlsx", prefix = "IPT", transform = "growth"),
  IPM = list(vintage = "ipmMvMd.xlsx", vintage_sheet = "ipm",
             target = "ipm_first_second_third.xlsx", prefix = "IPM", transform = "growth"),
  H = list(vintage = "hMvMd.xlsx", vintage_sheet = "h",
           target = "h_first_second_third.xlsx", prefix = "H", transform = "growth"),
  CUT = list(vintage = "cutMvMd.xlsx", vintage_sheet = "cut",
             target = "cut_first_second_third.xlsx", prefix = "CUT", transform = "level")
)

required <- unique(unlist(lapply(meta, function(z) c(z$vintage, z$target))))
missing <- required[!file.exists(file.path(raw_dir, required))]
if (length(missing)) stop("Missing raw RTDSM workbooks in --raw-dir: ", paste(missing, collapse = ", "), call. = FALSE)

read_vintage <- function(spec) {
  path <- file.path(raw_dir, spec$vintage)
  d <- as.data.frame(readxl::read_excel(path, sheet = spec$vintage_sheet, .name_repair = "minimal"), check.names = FALSE)
  if (ncol(d) < 2L) stop("Vintage workbook has too few columns: ", path, call. = FALSE)
  names(d)[1L] <- "DATE"
  obs_id <- bsu_parse_ym(d$DATE)
  value_names <- names(d)[-1L]
  vintage_id <- vapply(value_names, bsu_parse_vintage_col_id, integer(1L), prefix = spec$prefix)
  if (anyNA(vintage_id)) stop("Could not parse some vintage columns in ", spec$vintage, call. = FALSE)
  if (anyDuplicated(vintage_id)) stop("Duplicate vintage month columns in ", spec$vintage, call. = FALSE)
  vals <- d[-1L]
  vals[] <- lapply(vals, function(x) suppressWarnings(as.numeric(x)))
  list(obs_id = obs_id, values = vals, value_names = value_names,
       vintage_id = vintage_id, file = spec$vintage)
}

read_targets <- function(spec) {
  path <- file.path(raw_dir, spec$target)
  d <- as.data.frame(readxl::read_excel(path, sheet = "DATA", skip = 4, .name_repair = "minimal"), check.names = FALSE)
  names(d) <- trimws(names(d))
  need <- c("Date", "First", "Second", "Third", "Most_Recent")
  if (!all(need %in% names(d))) stop("Target workbook missing required columns: ", path, call. = FALSE)
  d <- d[, need, drop = FALSE]
  d <- d[!is.na(d$Date) & nzchar(trimws(as.character(d$Date))), , drop = FALSE]
  d$target_id <- bsu_parse_ym(d$Date)
  for (nm in need[-1L]) d[[nm]] <- suppressWarnings(as.numeric(d[[nm]]))
  d
}

extract_training <- function(vobj, spec, target_id, vintage_offset) {
  vid <- target_id + as.integer(vintage_offset)
  j <- match(vid, vobj$vintage_id)
  if (is.na(j)) stop(sprintf("%s: missing vintage for target %s offset %+d", spec$prefix, bsu_id_to_date(target_id), vintage_offset), call. = FALSE)
  if (identical(spec$transform, "level")) {
    need_ids <- seq.int(target_id - 120L, target_id - 1L)
    ii <- match(need_ids, vobj$obs_id)
    if (anyNA(ii)) stop(spec$prefix, ": missing observation months for level training.", call. = FALSE)
    y <- vobj$values[[j]][ii]
    train_ids <- need_ids
  } else {
    need_ids <- seq.int(target_id - 121L, target_id - 1L)
    ii <- match(need_ids, vobj$obs_id)
    if (anyNA(ii)) stop(spec$prefix, ": missing observation months for transformed training.", call. = FALSE)
    x <- vobj$values[[j]][ii]
    if (identical(spec$transform, "diff")) {
      y <- diff(x)
    } else if (identical(spec$transform, "growth")) {
      if (any(x <= 0, na.rm = TRUE)) stop(spec$prefix, ": nonpositive level encountered in growth transformation.", call. = FALSE)
      y <- 100 * ((x[-1L] / x[-length(x)])^12 - 1)
    } else stop("Unknown transform: ", spec$transform, call. = FALSE)
    train_ids <- need_ids[-1L]
  }
  if (length(y) != 120L || any(!is.finite(y))) {
    stop(sprintf("%s %s offset %+d: expected 120 finite transformed observations, got %d (%d nonfinite)",
                 spec$prefix, bsu_id_to_date(target_id), vintage_offset, length(y), sum(!is.finite(y))), call. = FALSE)
  }
  list(y = as.numeric(y), train_id = train_ids,
       vintage_name = vobj$value_names[j], vintage_id = vid)
}

training_rows <- vector("list", length(meta) * length(TARGET_IDS) * 2L)
target_rows <- vector("list", length(meta) * length(TARGET_IDS))
manifest_rows <- vector("list", length(meta) * length(TARGET_IDS))
ri <- 0L; ti <- 0L; mi <- 0L

for (sn in names(meta)) {
  spec <- meta[[sn]]
  cat("Reading ", sn, " workbooks...\n", sep = "")
  vobj <- read_vintage(spec)
  tobj <- read_targets(spec)
  for (k in seq_along(TARGET_IDS)) {
    t_id <- TARGET_IDS[k]
    t_date <- bsu_id_to_date(t_id)
    truth_i <- match(t_id, tobj$target_id)
    if (is.na(truth_i) || !is.finite(tobj$Third[truth_i])) {
      stop(sprintf("%s %s: missing finite Third-release target", sn, t_date), call. = FALSE)
    }
    pre <- extract_training(vobj, spec, t_id, 0L)
    ref <- extract_training(vobj, spec, t_id, 2L)
    if (!identical(pre$train_id, ref$train_id)) stop("PRE/REF support mismatch.", call. = FALSE)

    ri <- ri + 1L
    training_rows[[ri]] <- data.frame(series = sn, target = t_date, interface = "PRE",
                                      train_date = bsu_id_to_date(pre$train_id), y = pre$y)
    ri <- ri + 1L
    training_rows[[ri]] <- data.frame(series = sn, target = t_date, interface = "REF",
                                      train_date = bsu_id_to_date(ref$train_id), y = ref$y)

    ti <- ti + 1L
    target_rows[[ti]] <- data.frame(series = sn, target_date = t_date,
                                    target_first = tobj$First[truth_i], target_second = tobj$Second[truth_i],
                                    target_third = tobj$Third[truth_i], target_most_recent = tobj$Most_Recent[truth_i])

    mi <- mi + 1L
    manifest_rows[[mi]] <- data.frame(
      series = sn, target_date = t_date, n_train = 120L,
      train_start = bsu_id_to_date(min(pre$train_id)), train_end = bsu_id_to_date(max(pre$train_id)),
      pre_vintage = pre$vintage_name, ref_vintage = ref$vintage_name,
      truth_third = tobj$Third[truth_i], target_first = tobj$First[truth_i],
      target_second = tobj$Second[truth_i], target_third = tobj$Third[truth_i],
      target_most_recent = tobj$Most_Recent[truth_i]
    )
    if (k %% 100L == 0L || k == length(TARGET_IDS)) cat(sprintf("  %s %d/%d %s\n", sn, k, length(TARGET_IDS), t_date))
  }
}

training <- do.call(rbind, training_rows[seq_len(ri)])
targets <- do.call(rbind, target_rows[seq_len(ti)])
manifest <- do.call(rbind, manifest_rows[seq_len(mi)])

stopifnot(nrow(training) == 5L * 504L * 2L * 120L)
stopifnot(nrow(targets) == 5L * 504L)
stopifnot(nrow(manifest) == 5L * 504L)
stopifnot(!anyDuplicated(training[c("series", "target", "interface", "train_date")]))
stopifnot(!anyDuplicated(targets[c("series", "target_date")]))
stopifnot(all(is.finite(training$y)), all(is.finite(targets$target_third)))

bsu_write_csv(training, file.path(out_dir, "long_sample_training_1983_2025.csv"))
bsu_write_csv(targets, file.path(out_dir, "long_sample_release_targets_1983_2025.csv"))
bsu_write_csv(manifest, file.path(out_dir, "long_sample_origin_manifest_1983_2025.csv"))

cat("Built balanced RTDSM long sample.\n")
cat("Targets per series: 504\n")
cat("Series-origin cases: 2520\n")
cat("PRE/REF histories: 5040\n")
cat("Transformed training observations: 604800\n")
