cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
source(file.path(script_dir0, "00_setup.R"))

args <- bsu_parse_args()
root <- bsu_package_root()
out_dir <- bsu_get_arg(args, "out-dir", file.path(root, "results"))
mae_path <- file.path(out_dir, "table_long_sample_internal_mae_long.csv")
rev_path <- file.path(out_dir, "table_long_sample_revision.csv")
if (!file.exists(mae_path) || !file.exists(rev_path)) stop("Run 04_summarize_results.R first.", call. = FALSE)

mae <- bsu_read_csv(mae_path)
rev <- bsu_read_csv(rev_path)

# These are the earlier Python reconstruction values used during manuscript development.
# They are NOT treated as truth. Their purpose is to flag unexpected disagreement after
# the canonical R implementation has passed the frozen 2018--2025 regression test.
py_mae <- data.frame(
  series = rep(c("EMPLOY", "IPT", "IPM", "H", "CUT"), each = 4L),
  method = rep(c("G_MATCH", "HUBER_ST", "MB_ST", "CB_ST"), times = 5L),
  python_reference = c(
    233.344, 178.144, 177.454, 176.766,
    6.297, 6.249, 6.230, 6.216,
    7.104, 7.014, 7.023, 7.024,
    5.413, 5.325, 5.321, 5.335,
    0.545, 0.623, 0.664, 0.629
  )
)
mae_cmp <- merge(mae[c("series", "method", "abs_error_pre")], py_mae, by = c("series", "method"), all.x = TRUE)
mae_cmp$difference_R_minus_Python <- mae_cmp$abs_error_pre - mae_cmp$python_reference
bsu_write_csv(mae_cmp, file.path(out_dir, "comparison_R_vs_provisional_Python_MAE.csv"))

py_rev <- data.frame(
  series = rep(c("EMPLOY", "CUT"), each = 4L),
  method = rep(c("G_MATCH", "HUBER_ST", "MB_ST", "CB_ST"), times = 2L),
  python_reference = c(20.95, 25.17, 26.05, 28.34, 0.256, 0.241, 0.236, 0.235)
)
rev_cmp <- merge(rev[c("series", "method", "forecast_revision_abs")], py_rev, by = c("series", "method"))
rev_cmp$difference_R_minus_Python <- rev_cmp$forecast_revision_abs - rev_cmp$python_reference
bsu_write_csv(rev_cmp, file.path(out_dir, "comparison_R_vs_provisional_Python_revision.csv"))

cat("R versus provisional Python comparison written.\n")
cat("Maximum absolute MAE difference against 3-decimal Python references: ",
    max(abs(mae_cmp$difference_R_minus_Python), na.rm = TRUE), "\n", sep = "")
cat("Maximum absolute revision difference against rounded Python references: ",
    max(abs(rev_cmp$difference_R_minus_Python), na.rm = TRUE), "\n", sep = "")
cat("Canonical status is determined by the frozen R regression test, not by these Python values.\n")
