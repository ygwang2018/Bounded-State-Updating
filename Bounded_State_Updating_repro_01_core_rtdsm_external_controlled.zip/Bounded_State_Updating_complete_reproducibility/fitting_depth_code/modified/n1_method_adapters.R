#!/usr/bin/env Rscript
# Method adapters for the authorised Stage N1 smoke only.  They neither read
# M3 test values nor calculate losses.  all2.R is deliberately never sourced.

n1_source_frozen_runtime <- function(repo_root) {
  repo_root <- normalizePath(repo_root, winslash = "/", mustWork = TRUE)
  runtime_env <- new.env(parent = baseenv())
  runtime_env$tail <- utils::tail
  source_files <- file.path(repo_root, "R", c(
    "rst_o_config.R",
    "rst_o_filters.R",
    "rst_o_objectives.R",
    "rst_o_optimizer.R",
    "rst_o_fit.R",
    "rst_o_forecast.R",
    "rst_o_v1_7_revised_baselines.R"
  ))
  if (any(!file.exists(source_files))) {
    stop("required frozen RST-O runtime source file is missing", call. = FALSE)
  }
  for (path in source_files) sys.source(path, envir = runtime_env)
  runtime_env
}

n1_source_stg_author_wrapper <- function(stg_path) {
  if (!file.exists(stg_path)) stop("isolated author STG wrapper is missing", call. = FALSE)
  stg_env <- new.env(parent = baseenv())
  stg_env$optim <- stats::optim
  stg_env$qnorm <- stats::qnorm
  stg_env$na.omit <- stats::na.omit
  stg_env$tail <- utils::tail
  sys.source(stg_path, envir = stg_env)
  if (!exists("THETAstructural", envir = stg_env, inherits = FALSE)) {
    stop("isolated author STG wrapper does not define THETAstructural", call. = FALSE)
  }
  get("THETAstructural", envir = stg_env, inherits = FALSE)
}

n1_author_seasonal_bundle <- function(y_train, horizon, frequency) {
  y_train <- as.numeric(y_train)
  frequency <- as.integer(frequency)
  horizon <- as.integer(horizon)
  if (frequency <= 1L) {
    return(list(y_sa = y_train, sfactors = 1, sfactout = rep(1, horizon)))
  }
  for (t in seq_along(y_train)) {
    if (y_train[[t]] != 0) {
      y_train <- y_train[t:length(y_train)]
      break
    }
  }
  s <- frequency
  if (length(y_train) <= s) stop("training series is too short for author seasonal factors", call. = FALSE)
  w <- rep(1 / (2 * s), s + 1L)
  w[2:s] <- 1 / s
  cma <- matrix(NA_real_, length(y_train), 1L)
  for (g in seq_len(length(y_train) - s)) cma[g + s / 2] <- sum(w * y_train[g:(g + s)])
  residuals <- y_train / cma
  sfactors <- numeric(s)
  for (seas in seq_len(s)) {
    sfactors[[seas]] <- mean(stats::na.omit(residuals[seq(seas, length(y_train) - s + seas, by = s)]))
  }
  sfactors <- sfactors * s / sum(sfactors)
  list(
    y_sa = y_train / rep(sfactors, ceiling(length(y_train) / s))[seq_along(y_train)],
    sfactors = sfactors,
    sfactout = rep(sfactors, length(y_train) + horizon)[(length(y_train) + 1L):(length(y_train) + horizon)]
  )
}

n1_make_method_adapters <- function(repo_root, stg_path) {
  runtime_env <- n1_source_frozen_runtime(repo_root)
  stg_fun <- n1_source_stg_author_wrapper(stg_path)

  stg <- function(y_train, horizon, frequency) {
    list(forecast = as.numeric(stg_fun(as.numeric(y_train), as.integer(horizon), as.integer(frequency))))
  }

  iqr_st <- function(y_train, horizon, frequency) {
    seasonal <- n1_author_seasonal_bundle(y_train, horizon, frequency)
    first_fit <- runtime_env$author_theta_structural_nonseasonal(seasonal$y_sa, horizon)
    winsorized <- runtime_env$v17_iqr_winsorized_training_series(seasonal$y_sa, first_fit, k = 1.5)
    second_fit <- runtime_env$author_theta_structural_nonseasonal(winsorized$y_winsorized, horizon)
    list(
      forecast = as.numeric(second_fit$mean) * seasonal$sfactout,
      iqr_warning = if (isTRUE(winsorized$fallback_used)) winsorized$warning_type else NULL
    )
  }

  rsto_nu5 <- function(y_train, horizon, frequency) {
    seasonal <- n1_author_seasonal_bundle(y_train, horizon, frequency)
    config <- runtime_env$rst_o_config()
    fit_out <- runtime_env$v17_forecast_rsto_primary_nu5(
      y_train = seasonal$y_sa,
      horizon = horizon,
      config = config,
      locked_params = NULL
    )
    q_fit <- as.numeric(fit_out$fit$q)
    lower_hit <- is.finite(q_fit) && q_fit <= config$q_lower + config$optimizer_boundary_tol
    upper_hit <- is.finite(q_fit) && q_fit >= config$q_upper - config$optimizer_boundary_tol
    list(
      forecast = as.numeric(fit_out$forecast) * seasonal$sfactout,
      q_endpoint_status = if (!is.finite(q_fit)) {
        "Q_NONFINITE"
      } else if (lower_hit && upper_hit) {
        "Q_BOTH_ENDPOINT_FLAGS"
      } else if (lower_hit) {
        "Q_LOWER_ENDPOINT"
      } else if (upper_hit) {
        "Q_UPPER_ENDPOINT"
      } else {
        "Q_INTERIOR"
      }
    )
  }

  robets <- function(y_train, horizon, frequency) {
    if (!requireNamespace("robets", quietly = TRUE)) stop("robets is unavailable", call. = FALSE)
    y <- stats::ts(as.numeric(y_train), frequency = as.integer(frequency))
    training_domain_requires_additive <- any(as.numeric(y) <= 0)
    fit <- robets::robets(
      y,
      model = "ZZZ",
      damped = NULL,
      additive.only = training_domain_requires_additive,
      lambda = NULL,
      opt.crit = "roblik",
      bounds = "both",
      ic = "robaicc",
      use.initial.values = TRUE,
      opt.initial.values = FALSE,
      rob.start.initial.values = TRUE,
      opt.sigma0 = FALSE,
      k = 3,
      nmse = 1
    )
    forecast <- robets::forecast.robets(fit, h = as.integer(horizon), PI = FALSE)
    list(forecast = as.numeric(forecast$mean), training_domain_requires_additive = training_domain_requires_additive)
  }

  list(STG = stg, IQR_ST = iqr_st, RSTO_NU5 = rsto_nu5, ROBETS = robets)
}
