from pathlib import Path
import sys
import numpy as np
import pandas as pd
ROOT=Path('.')
S=ROOT/'04_R1_M3_PRIMARY/shards'
mode=sys.argv[1]
def read_kind(prefix,kind):
    paths=sorted(S.glob(f'{prefix}_*_{kind}.csv'))
    assert paths,(prefix,kind)
    return pd.concat([pd.read_csv(p) for p in paths],ignore_index=True)
if mode=='D1':
    assert all((S/f'D1_{i}_COMPLETE.txt').exists() for i in [1,2])
    z=read_kind('D1','results');a=read_kind('D1','audit')
    assert len(z)==72072 and z.series_index.nunique()==3003
    assert len(a)==54054 and a.passed.all()
    k=['series_index','condition','method','depth','fit_interface'];assert not z.duplicated(k).any()
    primary=z[z.condition.ne('CLEAN')]
    summary=primary.groupby(['method','fit_interface']).agg(n=('MASE','size'),MASE=('MASE','mean'),RMSSE=('RMSSE','mean')).reset_index()
    expected={('MB_ST','clean_frozen'):1.949311,('CB_ST','clean_frozen'):2.025981,('MB_ST','full_refit'):7.363332,('CB_ST','full_refit'):7.239009}
    checks=[]
    for (m,f),v in expected.items():
        value=summary[(summary.method==m)&(summary.fit_interface==f)].MASE.item()
        checks.append(dict(method=m,fit_interface=f,D1_MASE=value,printed_reference=v,difference=value-v,passed=abs(value-v)<=2e-6))
    check=pd.DataFrame(checks);check.to_csv(ROOT/'04_R1_M3_PRIMARY/D1_AGGREGATE_REPRODUCTION.csv',index=False)
    a.to_csv(ROOT/'04_R1_M3_PRIMARY/D1_PER_SERIES_REPRODUCTION.csv',index=False)
    assert check.passed.all()
    (ROOT/'04_R1_M3_PRIMARY/D1_REPRODUCTION_PASS.txt').write_text('PASS: 3003 series; all 54054 available per-series loss checks; four pooled printed reference checks. G_MATCH is the newly fitted matched internal Gaussian and is not relabeled ST-Author.\n',encoding='utf-8')
    print(check.to_string(index=False))
elif mode=='FINAL':
    assert all((S/f'DEEP_{i}_COMPLETE.txt').exists() for i in range(1,5))
    z=pd.concat([read_kind('D1','results'),read_kind('DEEP','results')],ignore_index=True)
    f=pd.concat([read_kind('D1','fits'),read_kind('DEEP','fits')],ignore_index=True)
    assert len(z)==216216 and len(f)==108108,(len(z),len(f))
    keys=['series_index','condition','method','depth','fit_interface'];assert not z.duplicated(keys).any()
    assert z.groupby('depth').size().eq(72072).all()
    z.to_csv(ROOT/'04_R1_M3_PRIMARY/R1_M3_PRIMARY_RESULTS.csv',index=False)
    f.to_csv(ROOT/'04_R1_M3_PRIMARY/R1_M3_PRIMARY_FITS.csv',index=False)
    primary=z[z.condition.ne('CLEAN')].assign(design='PRIMARY_SIGN_POOLED')
    expanded=pd.concat([z.assign(design=z.condition),primary],ignore_index=True)
    expanded=pd.concat([expanded,expanded.assign(period='ALL')],ignore_index=True)
    summary=expanded.groupby(['design','period','method','depth','fit_interface']).agg(n_rows=('MASE','size'),n_series=('series_index','nunique'),MASE=('MASE','mean'),RMSSE=('RMSSE','mean')).reset_index()
    summary.to_csv(ROOT/'04_R1_M3_PRIMARY/R1_M3_PRIMARY_SUMMARY.csv',index=False)
    both=summary[summary.method.isin(['MB_ST','CB_ST'])].pivot(index=['design','period','depth','fit_interface'],columns='method',values='MASE').reset_index()
    both['MB_minus_CB_MASE']=both.MB_ST-both.CB_ST
    both.to_csv(ROOT/'07_SUMMARIES/R1_M3_BOUNDED_ORDERING.csv',index=False)
    # Verify the scientific invariants across depths directly from saved fits.
    start_columns=['q_start','omega_start','H_start','q_lower','q_upper','omega_lower','omega_upper','logH_lower','logH_upper']
    invariant=f.groupby(['series_index','condition','method'])[start_columns].nunique(dropna=False)
    assert invariant.eq(1).all().all(), invariant[invariant.ne(1).any(axis=1)]
    stability_path=ROOT/'07_SUMMARIES/R1_FITTING_DEPTH_STABILITY_SUMMARY.csv'
    previous=pd.read_csv(stability_path)
    previous=previous[previous.dataset.ne('M3_PRIMARY')]
    rows=[]
    for (method,depth),g in f.groupby(['method','depth']):
        rows.append(dict(dataset='M3_PRIMARY',method=method,depth=depth,n_fits=len(g),stable_count=g.stability_status.str.startswith('STABLE').sum(),max_sweeps_unstable_count=g.stability_status.eq('MAX_SWEEPS_UNSTABLE').sum(),mean_sweeps=g.n_sweeps.mean(),max_sweeps=g.n_sweeps.max(),boundary_count=g.boundary_hit.sum(),incumbent_count=g.incumbent_preserved.sum(),nonfinite_objective_fit_count=g.nonfinite_objectives.gt(0).sum(),max_eval_diagnostic_count=g.max_eval_hit.sum(),median_relative_objective_change=g.relative_objective_change.median(),max_relative_objective_change=g.relative_objective_change.max(),median_dimensionless_parameter_change=g.dimensionless_parameter_change.median(),max_dimensionless_parameter_change=g.dimensionless_parameter_change.max()))
    pd.concat([previous,pd.DataFrame(rows)],ignore_index=True).to_csv(stability_path,index=False)
    # Attribute the existing ordering contrast to stable and maximum-sweep fits.
    # This preserves every case and does not change the primary comparison.
    paired=z[z.condition.ne('CLEAN')&z.method.isin(['MB_ST','CB_ST'])].pivot(index=['series_index','condition','depth','fit_interface'],columns='method',values='MASE').reset_index()
    paired['fit_condition']=np.where(paired.fit_interface.eq('clean_frozen'),'CLEAN',paired.condition)
    unresolved=f[f.method.isin(['MB_ST','CB_ST'])].assign(max_sweeps_unstable=f.stability_status.eq('MAX_SWEEPS_UNSTABLE')).groupby(['series_index','condition','depth']).max_sweeps_unstable.any().reset_index().rename(columns={'condition':'fit_condition'})
    paired=paired.merge(unresolved,on=['series_index','fit_condition','depth'],validate='many_to_one')
    paired['MB_minus_CB_MASE']=paired.MB_ST-paired.CB_ST
    contribution=paired.groupby(['depth','fit_interface','max_sweeps_unstable']).agg(n_rows=('MB_minus_CB_MASE','size'),delta_sum=('MB_minus_CB_MASE','sum'),subset_mean_delta=('MB_minus_CB_MASE','mean')).reset_index()
    contribution['contribution_to_all_6006_mean_delta']=contribution.delta_sum/6006
    contribution.to_csv(ROOT/'07_SUMMARIES/R1_M3_ORDERING_STABILITY_CONTRIBUTIONS.csv',index=False)
    print(both[(both.design=='PRIMARY_SIGN_POOLED')&(both.period=='ALL')].to_string(index=False))
else:raise ValueError(mode)
