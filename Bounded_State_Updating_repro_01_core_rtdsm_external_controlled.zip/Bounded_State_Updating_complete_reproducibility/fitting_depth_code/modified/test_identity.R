source('01_CODE_SNAPSHOT/modified/r1_common.R',encoding='UTF-8')
tr<-fread(file.path(ROOT,'01_CODE_SNAPSHOT/inputs/realtime/complete_vintage_training_long.csv'))
M3<-readRDS(file.path(ROOT,'01_CODE_SNAPSHOT/inputs/M3_frozen.rds'))
ys<-list(RTDSM_EMPLOY=tr[series=='EMPLOY'&target=='2020-04-01'&interface=='REF',y],M3_YEARLY=as.numeric(M3[[1]]$x),M3_QUARTERLY=M3FUN$n1_author_seasonal_bundle(M3[[646]]$x,8L,4L)$y_sa)
rows<-list();j<-0L
for(n in names(ys))for(m in methods){
  y<-ys[[n]];t0<-proc.time()[3];old<-original_fit(y,m);newold<-original_fit(y,m,NEW);a<-depth_fit(y,m,3L)
  z<-a$endpoints$D1$fit
  d1pass<-near(c(z$q_hat,z$omega_hat,z$H_hat,fcfit(z)),c(old$q_hat,old$omega_hat,old$H_hat,fcfit(old)))
  fullpass<-identical(fcfit(old),fcfit(newold))
  j<-j+1L;rows[[j]]<-data.table(case=n,method=m,D1_pass=d1pass,full_refit_unchanged=fullpass,old_forecast=fcfit(old),D1_forecast=fcfit(z),D3_forecast=fcfit(a$endpoints$D3$fit),runtime_sec=unname(proc.time()[3]-t0))
  print(rows[[j]])
}
r<-rbindlist(rows);fwrite(r,file.path(ROOT,'00_PROTOCOL/D1_IMPLEMENTATION_IDENTITY_TEST.csv'));stopifnot(all(r$D1_pass),all(r$full_refit_unchanged));cat('IDENTITY_PASS\n')
