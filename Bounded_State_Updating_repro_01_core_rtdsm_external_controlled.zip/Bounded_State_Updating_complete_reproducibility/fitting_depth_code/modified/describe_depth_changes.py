from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT=Path('.')
dataset=sys.argv[1]
if dataset=='RTDSM':
    folder=ROOT/'03_R1_RTDSM'
    f=pd.read_csv(folder/'R1_RTDSM_FITS.csv')
    keys=['series','target_date','interface','method']
    groups=['series','interface','method','depth']
elif dataset=='M3_PRIMARY':
    folder=ROOT/'04_R1_M3_PRIMARY'
    f=pd.read_csv(folder/'R1_M3_PRIMARY_FITS.csv')
    keys=['series_index','condition','method']
    groups=['condition','method','depth']
else:
    raise ValueError(dataset)
cols=['objective_final','q_final','omega_final','H_final','forecast_h1']
base=f[f.depth.eq('D1')][keys+cols].rename(columns={c:'D1_'+c for c in cols})
p=f[f.depth.ne('D1')].merge(base,on=keys,validate='many_to_one')
p['relative_objective_improvement']=(p.D1_objective_final-p.objective_final)/np.maximum(1,p.D1_objective_final.abs())
p['q_displacement']=p.q_final-p.D1_q_final
p['omega_displacement']=p.omega_final-p.D1_omega_final
p['logH_displacement']=np.log(p.H_final/p.D1_H_final)
p['dimensionless_parameter_displacement']=np.maximum.reduce([
    p.q_displacement.abs()/(p.q_upper-p.q_lower),
    p.omega_displacement.abs()/(p.omega_upper-p.omega_lower),
    p.logH_displacement.abs()/16])
p['forecast_displacement']=p.forecast_h1-p.D1_forecast_h1
p['forecast_displacement_abs']=p.forecast_displacement.abs()
export=keys+['depth','stability_status','n_sweeps']+cols+['D1_'+c for c in cols]+['relative_objective_improvement','q_displacement','omega_displacement','logH_displacement','dimensionless_parameter_displacement','forecast_displacement','forecast_displacement_abs']
rename={}
if dataset=='M3_PRIMARY':
    # Fit diagnostics are in seasonally adjusted units. Aggregate forecast
    # changes only after inverse seasonality and the original MASE scaling.
    z=pd.read_csv(folder/'R1_M3_PRIMARY_RESULTS.csv')
    z=z[z.fit_interface.eq('full_refit')]
    b=z[z.depth.eq('D1')][keys+['forecast_vector']].rename(columns={'forecast_vector':'D1_forecast_vector'})
    d=z[z.depth.ne('D1')].merge(b,on=keys,validate='many_to_one')
    d['full_refit_forecast_displacement_MASE_scaled']=[np.mean(np.abs(np.fromstring(a,sep=';')-np.fromstring(b,sep=';')))/den for a,b,den in zip(d.forecast_vector,d.D1_forecast_vector,d.MASE_denominator)]
    p=p.merge(d[keys+['depth','full_refit_forecast_displacement_MASE_scaled']],on=keys+['depth'],validate='one_to_one')
    export+=['full_refit_forecast_displacement_MASE_scaled']
    rename={c:'seasonally_adjusted_'+c for c in ['forecast_h1','D1_forecast_h1','forecast_displacement','forecast_displacement_abs']}
p[export].rename(columns=rename).to_csv(ROOT/f'07_SUMMARIES/R1_{dataset}_DEPTH_DISPLACEMENTS.csv',index=False)
out=p.groupby(groups).agg(n_fits=('depth','size'),median_relative_objective_improvement=('relative_objective_improvement','median'),max_relative_objective_improvement=('relative_objective_improvement','max'),min_relative_objective_improvement=('relative_objective_improvement','min'),median_dimensionless_parameter_displacement=('dimensionless_parameter_displacement','median'),max_dimensionless_parameter_displacement=('dimensionless_parameter_displacement','max')).reset_index()
displacement_col='forecast_displacement_abs' if dataset=='RTDSM' else 'full_refit_forecast_displacement_MASE_scaled'
names=('mean_absolute_forecast_displacement','max_absolute_forecast_displacement') if dataset=='RTDSM' else ('mean_'+displacement_col,'max_'+displacement_col)
extra=p.groupby(groups).agg(**{names[0]:(displacement_col,'mean'),names[1]:(displacement_col,'max')}).reset_index()
out=out.merge(extra,on=groups,validate='one_to_one')
out.to_csv(ROOT/f'07_SUMMARIES/R1_{dataset}_DEPTH_DISPLACEMENT_SUMMARY.csv',index=False)
if dataset=='RTDSM':
    k=pd.read_csv(folder/'R1_RTDSM_KEY_MECHANISM_TRACE.csv')
    k[k.train_index.eq(k.train_index.max())].to_csv(ROOT/'07_SUMMARIES/R1_RTDSM_KEY_TERMINAL_UPDATES.csv',index=False)
    f[f.stability_status.eq('MAX_SWEEPS_UNSTABLE')].to_csv(ROOT/'07_SUMMARIES/R1_RTDSM_MAX_SWEEPS_CASES.csv',index=False)
print(dataset, 'paired depth fits:',len(p))
