fixed_author_gaussian <- function(y, omega, q, horizon = 1L, initial_state = y[1L]) {
  n <- length(y); state <- p <- rep(0, n + 1L); state[1L] <- initial_state; p[1L] <- 10000
  k <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1)
  p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- omega + state[1L]
  if (n >= 2L) for (t in 2:n) {
    k[t] <- p[t] / (p[t] + 1); inn <- y[t] - state[t]
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- omega + state[t] + k[t] * inn
  }
  state[n + 1L] + omega * (0:(horizon - 1L))
}
fit_author_gaussian <- function(y, horizon = 1L) {
  likelihood <- function(parameters) {
    q <- abs(parameters[1L]); co <- abs(parameters[2L]); n <- length(y)
    state <- p <- rep(0, n + 1L); state[1L] <- y[1L]; p[1L] <- 10000
    k <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1); sigmae <- 0
    p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- co + state[1L]
    if (n >= 2L) for (t in 2:n) {
      k[t] <- p[t] / (p[t] + 1); inn <- y[t] - state[t]
      sigmae <- sigmae + inn^2 / (p[t] + 1)
      p[t + 1L] <- p[t] - p[t] * k[t] + q
      state[t + 1L] <- co + state[t] + k[t] * inn
    }
    sum(log(p + 1)) + n * log(max(sigmae / n, 1e-12))
  }
  op <- stats::optim(c(.01, 1), likelihood)
  q <- abs(op$par[1L]); co <- abs(op$par[2L])
  list(mean = fixed_author_gaussian(y, co, q, horizon), q = q, omega = co, convergence = op$convergence)
}
