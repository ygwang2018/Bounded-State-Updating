from pathlib import Path
import pandas as pd
import numpy as np
ROOT=Path('.')
SHARDS=ROOT/'03_R1_RTDSM/shards'
orig=pd.read_csv(ROOT/'01_CODE_SNAPSHOT/inputs/realtime/complete_vintage_origin_manifest.csv')
pieces={k:[] for k in ['fits','forecasts','trace','mechanism','qa']}
repairs=[]
for sn in ['EMPLOY','IPT','IPM','H','CUT']:
    assert (SHARDS/f'{sn}_COMPLETE.txt').exists(),sn+' incomplete'
    dates=orig[orig.series.eq(sn)].target_date.to_numpy()
    assert len(dates)==90
    for kind,n in [('fits',24),('forecasts',48),('trace',None),('qa',5),('mechanism',None)]:
        p=(ROOT/'02_FIXED_INITIALIZATION/shards'/f'{sn}_qa.csv') if kind=='qa' else SHARDS/f'{sn}_{kind}.csv'
        if kind=='mechanism' and sn not in ['EMPLOY','CUT']:continue
        z=pd.read_csv(p)
        if n is not None:
            assert len(z)==90*n,(sn,kind,len(z))
            expected=np.repeat(dates,n)
        elif kind=='trace':
            starts=z.interface.eq('PRE') & z.method.eq('G_MATCH') & z.sweep.eq(1)
            assert starts.sum()==90,(sn,int(starts.sum()))
            expected=dates[starts.cumsum().to_numpy()-1]
        else:
            expected=np.repeat(dates[(dates>='2020-03-01')&(dates<='2020-07-01')],4*3*2*2*12)
            assert len(z)==len(expected),(sn,kind,len(z),len(expected))
        # Resume serialization on the two initial jobs coerced new string dates to
        # NA because the previously read checkpoint held IDate. Recover only that
        # key column from the deterministic runner order; retain every fitted value.
        valid=z.target_date.notna()
        assert (z.loc[valid,'target_date'].to_numpy()==expected[valid]).all(),(sn,kind,'unexpected nonmissing date')
        missing=int((~valid).sum())
        if missing:
            z['target_date']=expected
            z.to_csv(p,index=False)
            repairs.append({'series':sn,'table':kind,'missing_dates_recovered':missing,'source':'original origin loop order; fixed row multiplicity or PRE/G_MATCH/sweep=1 trace boundaries','scientific_values_changed':False})
        pieces[kind].append(z)
names={'fits':'03_R1_RTDSM/R1_RTDSM_FITS.csv','forecasts':'03_R1_RTDSM/R1_RTDSM_FORECASTS.csv','trace':'03_R1_RTDSM/R1_RTDSM_FIT_TRACE.csv','mechanism':'03_R1_RTDSM/R1_RTDSM_KEY_MECHANISM_TRACE.csv','qa':'02_FIXED_INITIALIZATION/FIXED_INITIALIZATION_QA.csv'}
for kind,items in pieces.items():
    z=pd.concat(items,ignore_index=True)
    if kind=='forecasts':
        k=['series','target_date','method','depth','fit_interface']
        assert not z.duplicated(k+['interface']).any()
        wide=z.pivot(index=k,columns='interface',values='forecast_h1')
        wide['forecast_revision']=wide.REF-wide.PRE
        wide['forecast_revision_abs']=wide.forecast_revision.abs()
        z=z.merge(wide[['forecast_revision','forecast_revision_abs']],on=k,validate='many_to_one')
        check=z[(z.depth=='D1')&(z.fit_interface=='full_refit')]
        b=pd.read_csv(ROOT/'01_CODE_SNAPSHOT/inputs/realtime/complete_vintage_full_refit_long.csv')
        for iface,col in [('PRE','forecast_pre_realtime'),('REF','forecast_ref_replay')]:
            v=check[check.interface.eq(iface)].merge(b[['series','target_date','method','truth_third',col]],on=['series','target_date','method'],validate='one_to_one')
            assert len(v)==1800
            assert np.allclose(v.forecast_h1,v[col],rtol=1e-8,atol=1e-8)
            assert np.array_equal(v.target_third,v.truth_third)
    z.to_csv(ROOT/names[kind],index=False)
pd.DataFrame(repairs,columns=['series','table','missing_dates_recovered','source','scientific_values_changed']).to_csv(ROOT/'08_LOGS_SESSION/RTDSM_DATE_SERIALIZATION_REPAIR.csv',index=False)
print('RTDSM finalized:',{k:sum(len(x) for x in v) for k,v in pieces.items()},'date-only serialization repairs:',repairs)
