clean_seasonal_freeze <- function(y_train, horizon, frequency) {
  y_train <- as.numeric(y_train)
  frequency <- as.integer(frequency)
  horizon <- as.integer(horizon)
  if (frequency <= 1L) {
    return(list(
      trim_start = 1L, n_eff = length(y_train), sfactors = 1,
      y_sa = y_train, sfactout = rep(1, horizon)
    ))
  }
  nz <- which(y_train != 0)
  trim_start <- if (length(nz)) nz[[1L]] else 1L
  y <- y_train[trim_start:length(y_train)]
  s <- frequency
  if (length(y) <= s) stop("training series too short for frozen seasonal factors")
  w <- rep(1 / (2 * s), s + 1L); w[2:s] <- 1 / s
  cma <- matrix(NA_real_, length(y), 1L)
  for (g in seq_len(length(y) - s)) cma[g + s / 2] <- sum(w * y[g:(g + s)])
  residuals <- y / cma
  sfactors <- numeric(s)
  for (seas in seq_len(s)) {
    sfactors[[seas]] <- mean(stats::na.omit(residuals[
      seq(seas, length(y) - s + seas, by = s)
    ]))
  }
  sfactors <- sfactors * s / sum(sfactors)
  patt <- rep(sfactors, ceiling(length(y) / s))[seq_along(y)]
  sfactout <- rep(sfactors, length(y) + horizon)[
    (length(y) + 1L):(length(y) + horizon)
  ]
  list(
    trim_start = trim_start, n_eff = length(y), sfactors = sfactors,
    y_sa = y / patt, sfactout = sfactout
  )
}
apply_frozen_seasonal <- function(y, freeze) {
  z <- as.numeric(y)[freeze$trim_start:length(y)]
  if (length(freeze$sfactors) == 1L) return(z)
  patt <- rep(freeze$sfactors, ceiling(length(z) / length(freeze$sfactors)))[seq_along(z)]
  z / patt
}

fixed_author_gaussian <- function(y, omega, q, horizon) {
  n <- length(y)
  state <- p <- rep(0, n + 1L)
  state[1L] <- y[1L]; p[1L] <- 10000
  k <- inn <- numeric(n)
  k[1L] <- p[1L] / (p[1L] + 1)
  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- omega + state[1L]
  if (n >= 2L) for (t in 2:n) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- omega + state[t] + k[t] * inn[t]
  }
  state[n + 1L] + omega * (0:(horizon - 1L))
}


fit_author_gaussian_m3 <- function(y, horizon) {
  likelihood <- function(parameters) {
    q <- abs(parameters[1L]); co <- abs(parameters[2L]); n <- length(y)
    state <- p <- rep(0, n + 1L); state[1L] <- y[1L]; p[1L] <- 10000
    k <- inn <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1); sigmae <- 0
    p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- co + state[1L]
    if (n >= 2L) for (t in 2:n) {
      k[t] <- p[t] / (p[t] + 1); inn[t] <- y[t] - state[t]
      sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
      p[t + 1L] <- p[t] - p[t] * k[t] + q
      state[t + 1L] <- co + state[t] + k[t] * inn[t]
    }
    sum(log(p + 1)) + n * log(sigmae / n)
  }
  op <- stats::optim(c(.01, 1), likelihood)
  q <- abs(op$par[1L]); co <- abs(op$par[2L])
  fc <- fixed_author_gaussian(y, co, q, horizon)
  # Recompute H exactly as in isolated M3 author kernel.
  n <- length(y); state <- p <- rep(0, n + 1L); state[1L] <- y[1L]; p[1L] <- 10000
  k <- inn <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1); sigmae <- 0
  p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- co + state[1L]
  if (n >= 2L) for (t in 2:n) { k[t] <- p[t]/(p[t]+1); inn[t] <- y[t]-state[t]; sigmae <- sigmae + inn[t]^2/(p[t]+1); p[t+1L] <- p[t]-p[t]*k[t]+q; state[t+1L] <- co+state[t]+k[t]*inn[t] }
  list(mean=fc, q_fit=q, omega_fit=co, H_fit=sigmae/(n-1L), optim=op)
}

