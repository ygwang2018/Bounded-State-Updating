from pathlib import Path
import pandas as pd
import numpy as np
ROOT=Path('.')
OUT=ROOT/'07_SUMMARIES'
def phase(d):
    return np.select([d<='2020-02-01',d<='2020-07-01',d<='2021-12-01'],['PRE_COVID_2018_TO_2020_02','COVID_SHOCK_2020_03_TO_07','RECOVERY_2020_08_TO_2021_12'],default='POST_2022_TO_2025_06')
for name in ['R2_ETS_AUTOARIMA_FITS.csv','R2_MODEL_SELECTION_DIAGNOSTICS.csv']:
    p=ROOT/'05_R2_BENCHMARKS'/name;d=pd.read_csv(p)
    ets=d.method.eq('ETS');comps=d.loc[ets,'components'].str.split(';',expand=True)
    assert comps.shape[1]==4
    d['damped']=d['damped'].astype('object')
    d.loc[ets,'damped']=comps[3].to_numpy()
    for j,n in enumerate(['ets_error_component','ets_trend_component','ets_seasonal_component']):d.loc[ets,n]=comps[j].to_numpy()
    d.to_csv(p,index=False,encoding='utf-8')
r2=pd.read_csv(ROOT/'05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FORECASTS.csv')
assert len(r2)==1800 and not r2.duplicated(['series','target_date','interface','method']).any()
b=pd.read_csv(ROOT/'01_CODE_SNAPSHOT/inputs/realtime/complete_vintage_full_refit_long.csv')
baseline=[]
for p,suffix in [('PRE','pre_realtime'),('REF','ref_replay')]:
    z=b[['series','target_date','method','truth_third',f'forecast_{suffix}','forecast_revision_abs']].copy()
    z=z.rename(columns={'truth_third':'target_third',f'forecast_{suffix}':'forecast_h1'})
    z['interface']=p;z['fit_interface']='full_refit';z['abs_error']=(z.forecast_h1-z.target_third).abs();z['sq_error']=(z.forecast_h1-z.target_third)**2;z['fit_status']='EXISTING_FROZEN_RESULT'
    baseline.append(z)
all_fc=pd.concat([r2,*baseline],ignore_index=True)
all_fc['phase']=phase(all_fc.target_date)
def summarize(d):
    groups=['series','phase','interface','method']
    s=d.groupby(groups,dropna=False).agg(n_expected=('forecast_h1','size'),n_finite=('forecast_h1','count'),MAE=('abs_error','mean'),mean_sq_error=('sq_error','mean'),forecast_revision_abs=('forecast_revision_abs','mean')).reset_index()
    s['RMSE']=np.sqrt(s.pop('mean_sq_error'))
    return s
expanded=pd.concat([all_fc,all_fc.assign(phase='ALL_2018_01_TO_2025_06')],ignore_index=True)
summary=summarize(expanded)
summary[summary.method.isin(['ETS','AutoARIMA'])].to_csv(OUT/'R2_SERIES_PHASE_SUMMARY.csv',index=False)
summary.to_csv(OUT/'R2_COMPARISON_WITH_EXISTING_METHODS.csv',index=False)
g=['series','phase','interface'];ranking=summary.copy();ranking['MAE_rank']=ranking.groupby(g).MAE.rank(method='min');ranking['RMSE_rank']=ranking.groupby(g).RMSE.rank(method='min')
ranking.to_csv(OUT/'R2_METHOD_RANKING.csv',index=False)
print(ranking[(ranking.phase=='COVID_SHOCK_2020_03_TO_07')&(ranking.interface=='PRE')].sort_values(['series','MAE'])[['series','method','MAE','RMSE','forecast_revision_abs']].to_string(index=False))
print('\nFull-span PRE best MAE:')
print(ranking[(ranking.phase=='ALL_2018_01_TO_2025_06')&(ranking.interface=='PRE')&(ranking.MAE_rank==1)][['series','method','MAE']].to_string(index=False))
print('R2 expected=1800 finite=',r2.forecast_h1.notna().sum(),'failures=',r2.fit_status.eq('FAILED').sum(),'warning_rows=',r2.warnings.notna().sum())
