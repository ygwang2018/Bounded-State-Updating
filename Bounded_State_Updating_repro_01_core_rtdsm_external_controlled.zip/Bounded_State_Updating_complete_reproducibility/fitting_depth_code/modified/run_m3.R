source('01_CODE_SNAPSHOT/modified/r1_common.R',encoding='UTF-8')
args<-commandArgs(TRUE);mode<-args[1];shard<-as.integer(args[2]);nshards<-as.integer(args[3])
stopifnot(mode%in%c('D1','DEEP'))
M3<-readRDS(file.path(ROOT,'01_CODE_SNAPSHOT/inputs/M3_frozen.rds'));stopifnot(length(M3)==3003L)
inp<-file.path(ROOT,'01_CODE_SNAPSHOT/inputs/M3')
base_full<-fread(file.path(inp,'formal_gate_f/FORMAL_GATE_F_SERIES_METHOD_RESULTS.csv'))[condition%in%c('CLEAN','PRIMARY_CORE_NEG','PRIMARY_CORE_POS')]
base_frozen<-fread(file.path(inp,'fitted_layer/FITTED_LAYER_DECOMPOSITION_SERIES_RESULTS.csv'))[condition%in%c('PRIMARY_CORE_NEG','PRIMARY_CORE_POS')]
legacy<-c(G_MATCH=NA_character_,HUBER_ST='HUBER_ST',MB_ST='MB',CB_ST='CB')
out<-file.path(ROOT,'04_R1_M3_PRIMARY/shards');dir.create(out,showWarnings=FALSE)
tag<-paste0(mode,'_',shard);resfile<-file.path(out,paste0(tag,'_results.csv'));fitfile<-file.path(out,paste0(tag,'_fits.csv'));tracefile<-file.path(out,paste0(tag,'_trace.csv'));auditfile<-file.path(out,paste0(tag,'_audit.csv'))
stopifnot(!file.exists(resfile))
if(mode=='DEEP')stopifnot(file.exists(file.path(ROOT,'04_R1_M3_PRIMARY/D1_REPRODUCTION_PASS.txt')))
append_csv<-function(z,p)fwrite(z,p,append=file.exists(p))
ids<-seq(shard,3003L,by=nshards)
for(ii in seq_along(ids)){
  i<-ids[ii];s<-M3[[i]];clean<-as.numeric(s$x);actual<-as.numeric(s$xx);h<-as.integer(s$h);freq<-as.integer(frequency(s$x))
  lag<-max(1L,freq);dif<-clean[(lag+1L):length(clean)]-clean[1L:(length(clean)-lag)];den<-mean(abs(dif));den2<-sqrt(mean(dif^2))
  scale<-max(sd(clean),IQR(clean,type=7)/1.349,1e-6,na.rm=TRUE);idx<-(length(clean)-2L):length(clean)
  neg<-pos<-clean;neg[idx]<-neg[idx]-6*scale;pos[idx]<-pos[idx]+6*scale
  yy<-list(CLEAN=clean,PRIMARY_CORE_NEG=neg,PRIMARY_CORE_POS=pos)
  seas<-lapply(yy,M3FUN$clean_seasonal_freeze,horizon=h,frequency=freq)
  bundles<-list();fitrows<-tracerows<-resrows<-auditrows<-list();nf<-nt<-nr<-na<-0L
  for(cond in names(yy)){
    y<-seas[[cond]]$y_sa;g0<-NEW$rst_o_fit(y,Inf);bundles[[cond]]<-list()
    for(m in methods){
      a<-depth_fit(y,m,max_sweeps=if(mode=='D1')1L else 30L,original_gaussian=g0);bundles[[cond]][[m]]<-a
      depths<-if(mode=='D1')'D1' else c('D3','DSTABLE')
      for(d in depths){nf<-nf+1L;fitrows[[nf]]<-cbind(data.table(series_index=i,series_name=as.character(s$sn),period=as.character(s$period),condition=cond,method=m,depth=d,n_train=length(y),frequency=freq,h=h),a$endpoints[[d]]$info)}
      nt<-nt+1L;tracerows[[nt]]<-cbind(data.table(series_index=i,condition=cond,method=m),a$trace)
    }
  }
  for(cond in names(yy))for(m in methods)for(d in if(mode=='D1')'D1' else c('D3','DSTABLE'))for(iface in c('clean_frozen','full_refit')){
    if(iface=='full_refit'){
      f<-bundles[[cond]][[m]]$endpoints[[d]]$fit;fc<-fcfit(f,h)*seas[[cond]]$sfactout
    }else{
      ref_fit<-bundles$CLEAN[[m]]$endpoints[[d]]$fit;y<-M3FUN$apply_frozen_seasonal(yy[[cond]],seas$CLEAN)
      f<-replay(y,m,ref_fit,seas$CLEAN$y_sa[1]);fc<-fcfit(f,h)*seas$CLEAN$sfactout
    }
    mase<-mean(abs(actual-fc))/den;rmsse<-sqrt(mean((actual-fc)^2))/den2
    nr<-nr+1L;resrows[[nr]]<-data.table(series_index=i,series_name=as.character(s$sn),period=as.character(s$period),frequency=freq,n_train=length(clean),h=h,condition=cond,method=m,depth=d,fit_interface=iface,contamination_scale=scale,MASE_denominator=den,RMSSE_denominator=den2,MASE=mase,RMSSE=rmsse,forecast_h1=fc[1],forecast_vector=paste(format(fc,digits=17,scientific=TRUE),collapse=';'),q=f$q_hat,omega=f$omega_hat,H=f$H_hat,fit_status=if(all(is.finite(fc)))'OK' else 'FAILED_NONFINITE')
    if(mode=='D1'&&m!='G_MATCH'){
      lm<-unname(legacy[m]);b<-if(iface=='full_refit'||cond=='CLEAN')base_full[series_index==i&condition==cond&method==lm] else base_frozen[series_index==i&condition==cond&method==lm]
      expected<-if(iface=='full_refit'||cond=='CLEAN')c(b$MASE,b$RMSSE) else c(b$MASE_frozen,b$RMSSE_frozen)
      passed<-length(expected)==2L&&near(c(mase,rmsse),expected,1e-8)
      na<-na+1L;auditrows[[na]]<-data.table(series_index=i,condition=cond,method=m,fit_interface=iface,MASE=mase,stored_MASE=if(length(expected))expected[1] else NA_real_,RMSSE=rmsse,stored_RMSSE=if(length(expected)>1L)expected[2] else NA_real_,passed=passed)
      if(!passed){append_csv(rbindlist(auditrows),auditfile);append_csv(rbindlist(resrows),resfile);stop('D1 baseline mismatch series=',i,' condition=',cond,' method=',m,' interface=',iface)}
    }
  }
  append_csv(rbindlist(resrows),resfile);append_csv(rbindlist(fitrows),fitfile);append_csv(rbindlist(tracerows),tracefile)
  if(length(auditrows))append_csv(rbindlist(auditrows),auditfile)
  if(ii%%10L==0L||ii==length(ids)){cat(format(Sys.time()),tag,ii,'/',length(ids),'series=',i,'\n');flush.console()}
}
writeLines('COMPLETE',file.path(out,paste0(tag,'_COMPLETE.txt')))
