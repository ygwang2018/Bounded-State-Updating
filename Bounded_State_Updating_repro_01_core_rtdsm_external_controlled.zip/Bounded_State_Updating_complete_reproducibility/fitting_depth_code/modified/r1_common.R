options(stringsAsFactors=FALSE,warn=1)
.libPaths(unique(c('',.libPaths())))
ROOT <- '.'
CODE <- file.path(ROOT,'01_CODE_SNAPSHOT/modified')
library(data.table)
load_methods <- function(path) {
  e<-new.env(parent=globalenv())
  for(n in c('rst_o_config.R','rst_o_filters.R','rst_o_objectives.R','rst_o_optimizer.R','rst_o_fit.R','rst_o_forecast.R','rst_o_v1_7_revised_baselines.R'))sys.source(file.path(path,'R',n),e)
  sys.source(file.path(path,'gate_f_fitted_adapters.R'),e)
  e
}
OLD <- load_methods(file.path(ROOT,'01_CODE_SNAPSHOT/original'))
NEW <- load_methods(CODE)
sys.source(file.path(CODE,'author_rt_functions.R'),NEW)
M3FUN <- new.env(parent=globalenv());sys.source(file.path(CODE,'m3_functions.R'),M3FUN)
sys.source(file.path(CODE,'n1_method_adapters.R'),M3FUN)
methods <- c('G_MATCH','HUBER_ST','MB_ST','CB_ST')
fcfit <- function(f,h=1L) as.numeric(f$a_next_after_train + (seq_len(h)-1L)*f$omega_hat)
original_fit <- function(y,m,e=OLD) {
  if(m=='G_MATCH')e$rst_o_fit(y,Inf) else if(m=='CB_ST')e$rst_o_fit(y,5) else e$gate_f_optimize(y,if(m=='MB_ST')'MB' else 'HUBER')
}
replay <- function(y,m,f,initial_state=y[1L],e=NEW) {
  if(m=='G_MATCH'){
    out<-e$rst_o_filter_gaussian(y,f$omega_hat,f$q_hat,initial_state=initial_state)
    out$H_hat<-f$H_hat
    return(out)
  }
  if(m=='CB_ST')return(e$rst_o_filter_finite_nu(y,f$omega_hat,f$q_hat,f$H_hat,5,initial_state=initial_state))
  if(m=='MB_ST')e$gate_f_mb_filter(y,f$omega_hat,f$q_hat,f$H_hat,initial_state=initial_state) else e$gate_f_huber_filter(y,f$omega_hat,f$q_hat,f$H_hat,initial_state=initial_state)
}
depth_fit <- function(y,m,max_sweeps=30L,original_gaussian=NULL) {
  cfg<-NEW$rst_o_config();st<-NEW$rst_o_optimizer_start_values(y,cfg)
  g<-if(is.null(original_gaussian))NEW$rst_o_fit(y,Inf) else original_gaussian
  hi<-NEW$rst_o_H_init_from_matched_gaussian(y,cfg,matched_gaussian_fit=g)
  H0<-max(hi$H,cfg$H_init_floor);loH<-log(H0)-cfg$log_H_window;hiH<-log(H0)+cfg$log_H_window
  q0<-qcur<-st$q;o0<-ocur<-st$omega;lh0<-log(H0);ob<-st$omega_bound
  neval<-nnonfinite<-0L
  obj <- function(q,o,lh=lh0) {
    neval<<-neval+1L
    z<-if(m=='G_MATCH')NEW$rst_o_gaussian_concentrated_objective(y,q,o,config=cfg) else if(m=='CB_ST')NEW$rst_o_finite_nu_quasi_objective(y,q,o,lh,5,config=cfg) else if(m=='MB_ST')NEW$gate_f_mb_objective(y,q,o,lh,cfg) else NEW$gate_f_huber_objective(y,q,o,lh,cfg)
    if(!is.finite(z$objective))nnonfinite<<-nnonfinite+1L
    z
  }
  safe<-function(q,o,lh=lh0)NEW$rst_o_safe_objective(obj(q,o,lh)$objective)
  initial<-obj(q0,o0,lh0);J0<-NEW$rst_o_safe_objective(initial$objective)
  if(m=='G_MATCH'){H0<-initial$H_hat_G;lh0<-log(H0)}
  prev<-c(qcur,ocur,lh0);prevJ<-J0;consecutive<-0L;trace<-list();endpoints<-list()
  for(sw in seq_len(max_sweeps)) {
    inner<-if(m=='G_MATCH')function(q,o)safe(q,o) else function(q,o)stats::optimize(function(lh)safe(q,o,lh),c(loH,hiH),tol=cfg$optimizer_optimize_tol)$objective
    qo<-stats::optimize(function(q)inner(q,ocur),c(cfg$q_lower,cfg$q_upper),tol=cfg$optimizer_optimize_tol);qcur<-qo$minimum
    oo<-stats::optimize(function(o)inner(qcur,o),c(-ob,ob),tol=cfg$optimizer_optimize_tol);ocur<-oo$minimum
    lh<-if(m=='G_MATCH')0 else stats::optimize(function(lh)safe(qcur,ocur,lh),c(loH,hiH),tol=cfg$optimizer_optimize_tol)$minimum
    cand<-obj(qcur,ocur,lh);if(m=='G_MATCH')lh<-log(cand$H_hat_G)
    deltaJ<-abs(cand$objective-prevJ)/max(1,abs(prevJ))
    deltaP<-max(abs(c(qcur,ocur,lh)-prev)/c(cfg$q_upper-cfg$q_lower,2*ob,16))
    met<-is.finite(deltaJ)&&is.finite(deltaP)&&deltaJ<=1e-6&&deltaP<=1e-3&&nnonfinite==0L
    consecutive<-if(met)consecutive+1L else 0L
    stable<-sw>=3L && consecutive>=2L
    pres<-NEW$rst_o_preserve_incumbent(cand$objective,J0,NEW$rst_o_incumbent_preservation_tolerance(cfg))
    selected<-if(pres$incumbent_preserved)initial else cand
    selected_q<-if(pres$incumbent_preserved)q0 else qcur;selected_o<-if(pres$incumbent_preserved)o0 else ocur
    selected_H<-if(m=='G_MATCH')selected$H_hat_G else if(pres$incumbent_preserved)exp(lh0) else exp(lh)
    qb<-NEW$rst_o_boundary_hit(selected_q,cfg$q_lower,cfg$q_upper,cfg$optimizer_boundary_tol)
    obf<-NEW$rst_o_boundary_hit(selected_o,-ob,ob,cfg$optimizer_boundary_tol)
    hb<-if(m=='G_MATCH')NEW$rst_o_boundary_hit(selected_H,cfg$H_init_floor,Inf,cfg$optimizer_boundary_tol) else NEW$rst_o_boundary_hit(log(selected_H),loH,hiH,cfg$optimizer_boundary_tol)
    boundary<-any(c(qb,obf,hb))
    status<-if(!is.finite(selected$objective))'FAILED_NONFINITE' else if(stable&&pres$incumbent_preserved)'STABLE_RAW_INCUMBENT_SELECTED' else if(stable&&boundary)'STABLE_BOUNDARY' else if(stable)'STABLE_INTERIOR' else if(sw==max_sweeps&&max_sweeps>3L)'MAX_SWEEPS_UNSTABLE' else 'FIXED_DEPTH'
    fit<-selected$filter;fit$H_hat<-selected_H
    info<-data.table(objective_start=J0,objective_final=selected$objective,objective_per_observation=selected$objective/(length(y)-1L),objective_candidate=cand$objective,n_sweeps=sw,stability_status=status,q_start=q0,omega_start=o0,H_start=H0,q_final=selected_q,omega_final=selected_o,H_final=selected_H,q_lower=cfg$q_lower,q_upper=cfg$q_upper,omega_lower=-ob,omega_upper=ob,logH_lower=if(m=='G_MATCH')NA_real_ else loH,logH_upper=if(m=='G_MATCH')NA_real_ else hiH,boundary_hit=boundary,q_lower_hit=qb[1],q_upper_hit=qb[2],omega_lower_hit=obf[1],omega_upper_hit=obf[2],H_lower_hit=hb[1],H_upper_hit=hb[2],relative_objective_change=deltaJ,dimensionless_parameter_change=deltaP,incumbent_preserved=pres$incumbent_preserved,objective_evaluations=neval,max_eval_hit=neval>cfg$optimizer_max_eval,nonfinite_objectives=nnonfinite,forecast_h1=fcfit(fit),warnings=if(neval>cfg$optimizer_max_eval)'original_max_eval_diagnostic_exceeded' else '',failure=if(is.finite(selected$objective))'' else 'nonfinite final objective')
    trace[[sw]]<-cbind(data.table(sweep=sw,raw_q=qcur,raw_omega=ocur,raw_H=exp(lh),objective_after_q=qo$objective,objective_after_omega=oo$objective),info)
    if(sw==1L)endpoints$D1<-list(fit=fit,info=copy(info))
    if(sw==3L)endpoints$D3<-list(fit=fit,info=copy(info))
    if(stable||sw==max_sweeps){endpoints$DSTABLE<-list(fit=fit,info=copy(info));break}
    prev<-c(qcur,ocur,lh);prevJ<-cand$objective
  }
  if(max_sweeps==1L)endpoints$DSTABLE<-NULL
  list(endpoints=endpoints,trace=rbindlist(trace))
}
phase <- function(x)ifelse(x<='2020-02-01','PRE_COVID_2018_TO_2020_02',ifelse(x<='2020-07-01','COVID_SHOCK_2020_03_TO_07',ifelse(x<='2021-12-01','RECOVERY_2020_08_TO_2021_12','POST_2022_TO_2025_06')))
near <- function(x,y,tol=1e-10)all(is.finite(x)&is.finite(y)&abs(x-y)<=tol*(1+abs(y)))
