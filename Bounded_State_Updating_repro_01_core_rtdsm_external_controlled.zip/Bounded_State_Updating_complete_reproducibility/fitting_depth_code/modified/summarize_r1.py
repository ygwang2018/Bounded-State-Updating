from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path('.')
O=ROOT/'07_SUMMARIES'
fc=pd.read_csv(ROOT/'03_R1_RTDSM/R1_RTDSM_FORECASTS.csv')
f=pd.read_csv(ROOT/'03_R1_RTDSM/R1_RTDSM_FITS.csv')
q=pd.read_csv(ROOT/'02_FIXED_INITIALIZATION/FIXED_INITIALIZATION_QA.csv')
assert len(f)==10800 and len(fc)==21600 and len(q)==2250
assert q.full_refit_unchanged.all() and q.old_stored_reproduction_pass.all()
origins=q[['series','target_date','first_values_differ']].drop_duplicates()
assert len(origins)==450
same=q[~q.first_values_differ];assert (same.forecast_change==0).all()
q['changed_above_float_tolerance']=q.forecast_change.abs()>1e-10*(1+q.old_frozen_pre_forecast.abs())
q.to_csv(ROOT/'02_FIXED_INITIALIZATION/FIXED_INITIALIZATION_QA.csv',index=False)
text=['FIXED_INITIALIZATION_STATUS = PASS','',f'All 450 origins and all five methods were checked (2250 rows). Different initial observations: {origins.first_values_differ.sum()}/450; equal-first-value regression origins: {(~origins.first_values_differ).sum()}.',
      'Each replay accepts an explicit initial-state argument. Frozen PRE uses the REF initial-state numerical value with unchanged PRE observations. Gaussian/Huber/MB/CB assimilate their first observation under the existing response; ST-Author retains the public first-innovation-zero convention.',
      'All 3600 internal D1 full-refit forecasts reproduce the stored baseline; original versus modified default-initialization replay is identical. All 900 ST-Author full-refit forecasts reproduce the stored baseline. No full-refit scientific result changed.',
      f'Exactly changed frozen PRE predictions: {q.changed_by_init_alignment.sum()}; changes exceeding 1e-10*(1+abs(old forecast)): {q.changed_above_float_tolerance.sum()}; largest absolute change: {q.forecast_change.abs().max():.17g}. Equal-first-value cases have zero change.',
      'The first PRE observation was not replaced. No preprocessing, parameter estimation or observation response was changed.']
(ROOT/'02_FIXED_INITIALIZATION/FIXED_INITIALIZATION_CLOSEOUT.md').write_text('\n\n'.join(text)+'\n',encoding='utf-8')
expanded=pd.concat([fc,fc.assign(phase='ALL_2018_01_TO_2025_06')],ignore_index=True)
keys=['series','phase','method','depth','fit_interface','interface']
s=expanded.groupby(keys).agg(n=('forecast_h1','size'),MAE=('abs_error','mean'),mean_sq_error=('sq_error','mean'),forecast_revision_abs=('forecast_revision_abs','mean')).reset_index()
s['RMSE']=np.sqrt(s.pop('mean_sq_error'));s.to_csv(O/'R1_RTDSM_SERIES_PHASE_SUMMARY.csv',index=False)
base=s[s.method.eq('G_MATCH')].drop(columns=['method','n']).rename(columns={c:'G_MATCH_'+c for c in ['MAE','RMSE','forecast_revision_abs']})
contr=s.merge(base,on=['series','phase','depth','fit_interface','interface'],validate='many_to_one')
for c in ['MAE','RMSE','forecast_revision_abs']:contr['method_minus_G_MATCH_'+c]=contr[c]-contr['G_MATCH_'+c]
contr.to_csv(O/'R1_RTDSM_CONTRASTS_VS_G_MATCH.csv',index=False)
key=contr[contr.series.isin(['EMPLOY','CUT'])&contr.phase.eq('COVID_SHOCK_2020_03_TO_07')]
key.to_csv(O/'R1_KEY_MECHANISM_DECISION_EVIDENCE.csv',index=False)
# Check invariance of original starts and intervals across depths, using existing fit records.
for k,g in f.groupby(['series','target_date','interface','method']):
    for col in ['q_start','omega_start','H_start','q_lower','q_upper','omega_lower','omega_upper','logH_lower','logH_upper']:
        assert g[col].nunique(dropna=False)==1,(k,col)
files=[('RTDSM',f)]
mp=ROOT/'04_R1_M3_PRIMARY/R1_M3_PRIMARY_FITS.csv'
if mp.exists():files.append(('M3_PRIMARY',pd.read_csv(mp)))
out=[]
for dataset,d in files:
    d=d.copy();d['dataset']=dataset;d['stable']=d.stability_status.str.startswith('STABLE');d['max_sweeps_unstable']=d.stability_status.eq('MAX_SWEEPS_UNSTABLE')
    for k,g in d.groupby(['method','depth']):
        out.append(dict(dataset=dataset,method=k[0],depth=k[1],n_fits=len(g),stable_count=g.stable.sum(),max_sweeps_unstable_count=g.max_sweeps_unstable.sum(),mean_sweeps=g.n_sweeps.mean(),max_sweeps=g.n_sweeps.max(),boundary_count=g.boundary_hit.sum(),incumbent_count=g.incumbent_preserved.sum(),nonfinite_objective_fit_count=g.nonfinite_objectives.gt(0).sum(),max_eval_diagnostic_count=g.max_eval_hit.sum(),median_relative_objective_change=g.relative_objective_change.median(),max_relative_objective_change=g.relative_objective_change.max(),median_dimensionless_parameter_change=g.dimensionless_parameter_change.median(),max_dimensionless_parameter_change=g.dimensionless_parameter_change.max()))
pd.DataFrame(out).to_csv(O/'R1_FITTING_DEPTH_STABILITY_SUMMARY.csv',index=False)
print('\n'.join(text))
print(key[(key.fit_interface=='full_refit')&(key.interface=='PRE')][['series','method','depth','MAE','method_minus_G_MATCH_MAE']].sort_values(['series','method','depth']).to_string(index=False))
