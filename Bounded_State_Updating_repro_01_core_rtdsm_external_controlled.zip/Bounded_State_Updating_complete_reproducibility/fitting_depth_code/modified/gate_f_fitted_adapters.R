
gate_f_huber_filter <- function(y_train, omega, q, H, config = rst_o_config(), c_H = 1.345, initial_state = y_train[1L]) {
  y_train <- rst_o_validate_y_train(y_train); q <- rst_o_validate_q(q, config)
  omega <- rst_o_validate_scalar(omega, "omega"); H <- rst_o_validate_scalar(H, "H", 0, FALSE)
  n <- length(y_train); a <- P <- v <- Fv <- K <- u <- lambda <- a_post <- P_post <- numeric(n)
  a[1] <- initial_state; P[1] <- config$kappa
  for (t in seq_len(n)) {
    v[t] <- y_train[t] - a[t]; Fv[t] <- P[t] + 1; K[t] <- P[t] / Fv[t]
    u[t] <- v[t] / sqrt(H * Fv[t]); lambda[t] <- if (u[t] == 0) 1 else min(1, c_H / abs(u[t]))
    a_post[t] <- a[t] + lambda[t] * K[t] * v[t]; P_post[t] <- P[t] / (P[t] + 1)
    if (t < n) { a[t + 1] <- a_post[t] + omega; P[t + 1] <- P_post[t] + q }
  }
  list(branch="gate_f_huber_st", a_pred=a, P_pred=P, v=v, F=Fv, K=K, u=u, lambda=lambda,
       a_filt=a_post, P_filt=P_post, a_next_after_train=a_post[n]+omega, omega_hat=omega, q_hat=q, H_hat=H)
}

gate_f_mb_filter <- function(y_train, omega, q, H, config = rst_o_config(), nu = 5, initial_state = y_train[1L]) {
  y_train <- rst_o_validate_y_train(y_train); q <- rst_o_validate_q(q, config)
  omega <- rst_o_validate_scalar(omega, "omega"); H <- rst_o_validate_scalar(H, "H", 0, FALSE)
  stopifnot(identical(as.numeric(nu), 5)); s2 <- H * (nu - 2) / nu
  n <- length(y_train); a <- P <- v <- Fv <- K <- r2 <- w_raw <- w_tilde <- a_post <- P_post <- numeric(n)
  a[1] <- initial_state; P[1] <- config$kappa
  for (t in seq_len(n)) {
    v[t] <- y_train[t] - a[t]; Fv[t] <- P[t] + 1; K[t] <- P[t] / Fv[t]
    r2[t] <- v[t]^2 / (s2 * Fv[t]); w_raw[t] <- (nu + 1)/(nu + r2[t]); w_tilde[t] <- min(1, w_raw[t])
    a_post[t] <- a[t] + w_tilde[t] * K[t] * v[t]; P_post[t] <- P[t] / (P[t] + 1)
    if (t < n) { a[t + 1] <- a_post[t] + omega; P[t + 1] <- P_post[t] + q }
  }
  list(branch="gate_f_mb", nu=nu, s2_nu=s2, a_pred=a, P_pred=P, v=v, F=Fv, K=K, r2=r2,
       w_raw=w_raw, w_tilde=w_tilde, a_filt=a_post, P_filt=P_post,
       a_next_after_train=a_post[n]+omega, omega_hat=omega, q_hat=q, H_hat=H)
}

gate_f_huber_objective <- function(y_train, q, omega, logH, config = rst_o_config(), c_H = 1.345) {
  H <- exp(logH); fit <- gate_f_huber_filter(y_train, omega, q, H, config, c_H); idx <- 2:length(y_train)
  rho <- ifelse(abs(fit$u[idx]) <= c_H, 0.5*fit$u[idx]^2, c_H*abs(fit$u[idx]) - 0.5*c_H^2)
  list(objective=sum(0.5*log(H*fit$F[idx]) + rho), score_indices=idx, filter=fit,
       objective_type="quasi_Huber_M_objective", estimator_type="quasi_Huber_M_estimator_not_exact_Gaussian_MLE",
       objective_filter_mismatch_flag=FALSE)
}

gate_f_mb_objective <- function(y_train, q, omega, logH, config = rst_o_config(), nu = 5) {
  H <- exp(logH); fit <- gate_f_mb_filter(y_train, omega, q, H, config, nu); idx <- 2:length(y_train)
  obj <- sum(0.5*log(fit$s2_nu*fit$F[idx]) + 0.5*(nu+1)*log1p(fit$v[idx]^2/(nu*fit$s2_nu*fit$F[idx])))
  list(objective=obj, score_indices=idx, filter=fit, objective_type="MB_mean_only_path_quasi_t_score",
       estimator_type="quasi_M_estimator_not_exact_MLE", objective_filter_mismatch_flag=TRUE)
}

gate_f_optimize <- function(y_train, method=c("HUBER","MB"), config=rst_o_config()) {
  method <- match.arg(method); y_train <- rst_o_validate_y_train(y_train)
  starts <- rst_o_optimizer_start_values(y_train, config); H_info <- rst_o_H_init_from_matched_gaussian(y_train, config)
  H0 <- max(H_info$H, config$H_init_floor); loH <- log(H0)-config$log_H_window; hiH <- log(H0)+config$log_H_window
  q0 <- qcur <- starts$q; o0 <- ocur <- starts$omega; lH0 <- log(H0); ob <- starts$omega_bound
  objective <- function(q, o, lH) if (method=="HUBER") gate_f_huber_objective(y_train,q,o,lH,config)$objective else gate_f_mb_objective(y_train,q,o,lH,config)$objective
  safe <- function(z) rst_o_safe_objective(z); start_obj <- safe(objective(qcur,ocur,lH0))
  inner <- function(q,o) stats::optimize(function(lh) safe(objective(q,o,lh)), c(loH,hiH), tol=config$optimizer_optimize_tol)$objective
  qcur <- stats::optimize(function(q) inner(q,ocur), c(config$q_lower,config$q_upper), tol=config$optimizer_optimize_tol)$minimum
  ocur <- stats::optimize(function(o) inner(qcur,o), c(-ob,ob), tol=config$optimizer_optimize_tol)$minimum
  lHcur <- stats::optimize(function(lh) safe(objective(qcur,ocur,lh)), c(loH,hiH), tol=config$optimizer_optimize_tol)$minimum
  cand <- if (method=="HUBER") gate_f_huber_objective(y_train,qcur,ocur,lHcur,config) else gate_f_mb_objective(y_train,qcur,ocur,lHcur,config)
  pres <- rst_o_preserve_incumbent(cand$objective, start_obj, rst_o_incumbent_preservation_tolerance(config))
  if (pres$incumbent_preserved) { qcur<-q0; ocur<-o0; lHcur<-lH0; cand <- if(method=="HUBER") gate_f_huber_objective(y_train,qcur,ocur,lHcur,config) else gate_f_mb_objective(y_train,qcur,ocur,lHcur,config) }
  fit <- cand$filter; fit$fit_inputs <- list(q=qcur, omega=ocur, H=exp(lHcur), score_indices=cand$score_indices,
    H_init=H0, H_init_source=H_info$H_init_source, q_start=q0, omega_start=o0)
  fit$objective_type <- cand$objective_type; fit$estimator_type <- cand$estimator_type
  fit$objective_filter_mismatch_flag <- cand$objective_filter_mismatch_flag
  fit$optimizer <- list(objective_start=start_obj, objective_final=cand$objective, selected_source=if(pres$incumbent_preserved) "incumbent" else "candidate",
    incumbent_preserved=pres$incumbent_preserved, incumbent_tolerance=pres$incumbent_preservation_tolerance,
    q_bounds=c(config$q_lower,config$q_upper), omega_bounds=c(-ob,ob), logH_bounds=c(loH,hiH), optimize_tol=config$optimizer_optimize_tol)
  fit
}

gate_f_forecast <- function(fit, horizon) {
  j <- seq_len(as.integer(horizon)); fit$a_next_after_train + (j-1L)*fit$omega_hat
}



gate_f_make_m3_fitted_adapters <- function(seasonal_bundle_fn, config = rst_o_config()) {
  stopifnot(is.function(seasonal_bundle_fn))
  make_one <- function(method) function(y_train, horizon, frequency) {
    seasonal <- seasonal_bundle_fn(y_train, horizon, frequency)
    fit <- gate_f_optimize(seasonal$y_sa, method = method, config = config)
    list(forecast = as.numeric(gate_f_forecast(fit, horizon)) * seasonal$sfactout, fit = fit)
  }
  list(HUBER_ST = make_one("HUBER"), MB = make_one("MB"))
}

