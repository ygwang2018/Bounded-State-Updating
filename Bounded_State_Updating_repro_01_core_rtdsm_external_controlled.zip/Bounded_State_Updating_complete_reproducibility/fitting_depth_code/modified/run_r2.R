options(stringsAsFactors=FALSE,warn=1)
.libPaths(unique(c('',.libPaths())))
ROOT <- '.'
library(data.table)
stopifnot(as.character(getRversion())=='4.3.3',as.character(packageVersion('forecast'))=='8.24.0')
INP <- file.path(ROOT,'01_CODE_SNAPSHOT/inputs/realtime')
tr <- fread(file.path(INP,'complete_vintage_training_long.csv'));setorder(tr,series,target,interface,train_date)
orig <- fread(file.path(INP,'complete_vintage_origin_manifest.csv'))
keys <- unique(tr[,.(series,target,interface)]); ans <- vector('list',nrow(keys)*2L);ii<-0L
for(i in seq_len(nrow(keys))) {
  key<-keys[i];y<-tr[series==key$series & target==key$target & interface==key$interface,y]
  truth<-orig[series==key$series & target_date==key$target,truth_third];stopifnot(length(y)==120L,length(truth)==1L)
  for(m in c('ETS','AutoARIMA')) {
    warnings<-character();err<-'';t0<-proc.time()[3]
    out<-tryCatch(withCallingHandlers({
      fit<-if(m=='ETS') forecast::ets(ts(y,frequency=1)) else forecast::auto.arima(ts(y,frequency=1))
      fc<-as.numeric(forecast::forecast(fit,h=1)$mean[1]);list(fit=fit,fc=fc)
    },warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e){err<<-conditionMessage(e);NULL})
    val<-function(x) if(is.null(x)||!length(x)) NA else paste(x,collapse=';')
    f<-if(is.null(out)) list() else out$fit;fc<-if(is.null(out)) NA_real_ else out$fc
    if(!is.finite(fc)&&!nzchar(err))err<-'Nonfinite forecast'
    orders<-if(m=='AutoARIMA'&&!is.null(out))forecast::arimaorder(f) else numeric()
    co<-names(f$coef)
    ii<-ii+1L;ans[[ii]]<-data.table(series=key$series,target_date=as.character(key$target),interface=key$interface,method=m,fit_interface='full_refit',forecast_h1=fc,target_third=truth,abs_error=abs(fc-truth),sq_error=(fc-truth)^2,fit_status=if(nzchar(err))'FAILED' else if(length(warnings))'OK_WARNING' else 'OK',warnings=paste(unique(warnings),collapse=' | '),failure=err,selected_model=val(f$method),components=val(f$components),damped=if(m=='ETS')val(f$components[4L]) else NA_character_,orders=paste(names(orders),orders,sep='=',collapse=';'),drift='drift'%in%co,mean='intercept'%in%co,AIC=as.numeric(val(f$aic)),AICc=as.numeric(val(f$aicc)),BIC=as.numeric(val(f$bic)),convergence=val(f$code),runtime_sec=unname(proc.time()[3]-t0))
  }
  if(i%%25L==0L)cat(format(Sys.time()),'R2',i,'/',nrow(keys),'\n')
}
a<-rbindlist(ans);a[,forecast_revision:=forecast_h1[interface=='REF']-forecast_h1[interface=='PRE'],by=.(series,target_date,method)];a[,forecast_revision_abs:=abs(forecast_revision)]
fwrite(a,file.path(ROOT,'05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FITS.csv'))
fwrite(a[,.(series,target_date,interface,method,fit_interface,forecast_h1,target_third,abs_error,sq_error,forecast_revision,forecast_revision_abs,fit_status,warnings,failure)],file.path(ROOT,'05_R2_BENCHMARKS/R2_ETS_AUTOARIMA_FORECASTS.csv'))
fwrite(a[,!c('target_third','abs_error','sq_error','forecast_revision','forecast_revision_abs'),with=FALSE],file.path(ROOT,'05_R2_BENCHMARKS/R2_MODEL_SELECTION_DIAGNOSTICS.csv'))
stopifnot(nrow(a)==1800L);cat('R2_COMPLETE rows=',nrow(a),'failed=',sum(a$fit_status=='FAILED'),'\n')
