rst_o_config <- function() {
  list(
    nu_grid = c(3, 5, 8, 15, Inf),
    primary_finite_nu_branch = 5,
    secondary_finite_nu_branch = 3,
    kappa = 1e4,
    H_init_floor = 1e-12,
    c_omega = 10,
    q_lower = 1e-8,
    q_upper = 10,
    log_H_window = 8,
    Rleak_epsilon = 1e-3,
    gain_unit = "fraction",
    G_O_primary_threshold = 0.03,
    weak_G_O_interval = c(0.01, 0.03),
    sign_convention = "balanced_across_paired_seeds",
    min_outliers_per_contaminated_series = 1,
    DGP2_p_out_grid = c(0.02, 0.05, 0.10),
    DGP2_outlier_magnitude_grid = c(4, 6, 8),
    DGP3_main_nu0_grid = c(3, 5),
    DGP3_outgrid_nu0 = 7,
    DGP4_tau_fractions = c(0.5, 0.8),
    DGP4_abs_J_multiplier_grid = c(4, 6),
    DGP4_rho_s_grid = c(0.5, 0.8),
    DGP4_q_sensitivity = 0.01,
    DGP4_finite_duration_formal = FALSE,
    optimizer_outer_cycles = 1L,
    optimizer_optimize_tol = 1e-2,
    optimizer_incumbent_tolerance = sqrt(.Machine$double.eps),
    optimizer_boundary_tol = 1e-7,
    optimizer_max_eval = 5000L,
    optimizer_function = "stats::optimize",
    optimizer_method = "bounded_Brent_coordinate_search",
    paired_bootstrap_CI_level = 0.95,
    paired_bootstrap_B = 2000,
    paired_bootstrap_method = "percentile_bootstrap",
    bootstrap_CI_target_statistic = "cell_median_gain",
    bootstrap_CI_per_cell_target = "cell_median_gain",
    bootstrap_CI_family_target = "unweighted_median_of_cell_medians",
    strong_pass_family_CI_lower_threshold = 0,
    objective_type_finite_nu = "capped_path_quasi_t_score",
    estimator_type_finite_nu = "quasi_M_estimator_not_exact_MLE",
    objective_filter_mismatch_flag_finite_nu = TRUE,
    finite_variance_recursion_label = "algorithmic_information_scale_recursion"
  )
}

rst_o_validate_y_train <- function(y_train) {
  if (!is.numeric(y_train) || length(y_train) < 1L || any(!is.finite(y_train))) {
    stop("y_train must be a non-empty finite numeric vector.", call. = FALSE)
  }
  as.numeric(y_train)
}

rst_o_validate_scalar <- function(x, name, lower = -Inf, allow_equal_lower = TRUE) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x)) {
    stop(sprintf("%s must be a finite numeric scalar.", name), call. = FALSE)
  }
  ok <- if (allow_equal_lower) x >= lower else x > lower
  if (!ok) {
    stop(sprintf("%s is outside the allowed range.", name), call. = FALSE)
  }
  as.numeric(x)
}

rst_o_validate_q <- function(q, config = rst_o_config()) {
  q <- rst_o_validate_scalar(q, "q")
  if (q < config$q_lower || q > config$q_upper) {
    stop("q must satisfy q_lower <= q <= q_upper.", call. = FALSE)
  }
  q
}

rst_o_train_scale <- function(y_train) {
  y_train <- rst_o_validate_y_train(y_train)
  sd_y <- stats::sd(y_train)
  iqr_y <- stats::IQR(y_train) / 1.349
  max(sd_y, iqr_y, sqrt(1e-12), na.rm = TRUE)
}

rst_o_omega_bound <- function(y_train, config = rst_o_config()) {
  y_train <- rst_o_validate_y_train(y_train)
  config$c_omega * rst_o_train_scale(y_train) / length(y_train)
}

rst_o_validate_omega_bound <- function(omega, y_train, config = rst_o_config()) {
  omega <- rst_o_validate_scalar(omega, "omega")
  bound <- rst_o_omega_bound(y_train, config)
  if (abs(omega) > bound) {
    stop("omega is outside the training-only omega bound.", call. = FALSE)
  }
  list(
    omega = omega,
    omega_bound = bound,
    omega_bound_source = "y_train_only",
    omega_within_bound_flag = TRUE
  )
}

rst_o_validate_nu <- function(nu, config = rst_o_config(), enforce_grid = TRUE) {
  if (!is.numeric(nu) || length(nu) != 1L) {
    stop("nu must be a numeric scalar.", call. = FALSE)
  }
  if (is.infinite(nu)) {
    return(Inf)
  }
  if (!is.finite(nu) || nu <= 2) {
    stop("finite nu must be greater than 2.", call. = FALSE)
  }
  if (isTRUE(enforce_grid) && !nu %in% config$nu_grid[is.finite(config$nu_grid)]) {
    stop("nu is not in the frozen nu_grid.", call. = FALSE)
  }
  as.numeric(nu)
}

rst_o_positive_finite_or_na <- function(x) {
  if (length(x) != 1L || !is.finite(x) || x <= 0) NA_real_ else as.numeric(x)
}

rst_o_preliminary_estimates <- function(y_train, config = rst_o_config()) {
  y_train <- rst_o_validate_y_train(y_train)
  n_train <- length(y_train)
  diff_y <- diff(y_train)
  median_diff <- if (length(diff_y) >= 1L) stats::median(diff_y^2) / 2 else NA_real_
  y_variance <- if (n_train >= 2L) stats::var(y_train) else NA_real_
  scale_candidate <- rst_o_positive_finite_or_na(median_diff)
  if (!is.finite(scale_candidate)) {
    scale_candidate <- rst_o_positive_finite_or_na(y_variance)
  }
  if (!is.finite(scale_candidate)) {
    scale_candidate <- config$H_init_floor
  }
  omega_hat <- if (n_train >= 2L) {
    (y_train[n_train] - y_train[1L]) / (n_train - 1L)
  } else {
    0
  }
  omega_bound <- rst_o_omega_bound(y_train, config)
  omega_hat <- max(-omega_bound, min(omega_bound, omega_hat))
  q_hat <- rst_o_validate_q(min(config$q_upper, max(config$q_lower, scale_candidate / config$c_omega)), config)
  list(
    omega = omega_hat,
    q = q_hat,
    H = max(scale_candidate, config$H_init_floor),
    omega_bound = omega_bound,
    omega_bound_source = "y_train_only",
    omega_within_bound_flag = TRUE
  )
}

rst_o_H_init_fallback_cascade <- function(y_train, config = rst_o_config(),
                                          matched_gaussian_H_hat_G = NULL,
                                          matched_gaussian_score_indices = NULL,
                                          matched_gaussian_error_message = NA_character_) {
  y_train <- rst_o_validate_y_train(y_train)
  diff_y <- diff(y_train)
  score_indices <- matched_gaussian_score_indices
  matched_candidate <- NA_real_
  error_message <- matched_gaussian_error_message
  if (!is.null(matched_gaussian_H_hat_G)) {
    matched_candidate <- rst_o_positive_finite_or_na(matched_gaussian_H_hat_G)
  } else if (exists("rst_o_gaussian_concentrated_objective", mode = "function")) {
    preliminary <- rst_o_preliminary_estimates(y_train, config)
    matched_attempt <- try(
      rst_o_gaussian_concentrated_objective(
        y_train = y_train,
        q = preliminary$q,
        omega = preliminary$omega,
        config = config
      ),
      silent = TRUE
    )
    if (inherits(matched_attempt, "try-error")) {
      error_message <- as.character(matched_attempt)
    } else {
      matched_candidate <- rst_o_positive_finite_or_na(matched_attempt$H_hat_G)
      score_indices <- matched_attempt$score_indices
    }
  } else {
    error_message <- "matched_gaussian_objective_unavailable"
  }

  candidates <- c(
    matched_gaussian_H_hat_G = matched_candidate,
    median_diff_squared_half = if (length(diff_y) >= 1L) stats::median(diff_y^2) / 2 else NA_real_,
    y_variance = if (length(y_train) >= 2L) stats::var(y_train) else NA_real_,
    H_init_floor = config$H_init_floor
  )
  valid <- vapply(candidates, rst_o_positive_finite_or_na, numeric(1L))
  selected_index <- which(is.finite(valid))[1L]
  if (is.na(selected_index)) {
    selected_index <- length(valid)
    valid[selected_index] <- config$H_init_floor
  }
  list(
    H = unname(valid[selected_index]),
    H_init_source = names(candidates)[selected_index],
    H_init_candidates = candidates,
    H_init_floor_applied = identical(names(candidates)[selected_index], "H_init_floor"),
    score_indices = score_indices,
    fit_used_test_data_flag = FALSE,
    H_init_error_message = if (is.na(error_message)) "" else error_message
  )
}

rst_o_default_estimates <- function(y_train, config = rst_o_config()) {
  y_train <- rst_o_validate_y_train(y_train)
  preliminary <- rst_o_preliminary_estimates(y_train, config)
  H_info <- rst_o_H_init_fallback_cascade(y_train, config)
  H_hat <- H_info$H
  q_hat <- rst_o_validate_q(min(config$q_upper, max(config$q_lower, H_hat / config$c_omega)), config)

  list(
    omega = preliminary$omega,
    q = q_hat,
    H = H_hat,
    H_init_source = H_info$H_init_source,
    H_init_candidates = H_info$H_init_candidates,
    H_init_floor_applied = H_info$H_init_floor_applied,
    score_indices = H_info$score_indices,
    fit_used_test_data_flag = H_info$fit_used_test_data_flag,
    H_init_error_message = H_info$H_init_error_message,
    omega_bound = preliminary$omega_bound,
    omega_bound_source = "y_train_only",
    omega_within_bound_flag = TRUE
  )
}
