rst_o_score_indices <- function(n_train) {
  if (!is.numeric(n_train) || length(n_train) != 1L || !is.finite(n_train) ||
      n_train != as.integer(n_train) || n_train < 2L) {
    stop("n_train must be an integer >= 2 for objective scoring.", call. = FALSE)
  }
  2L:as.integer(n_train)
}

rst_o_gaussian_filter_path <- function(y_train, q, omega, init = NULL, config = rst_o_config()) {
  kappa <- if (is.list(init) && !is.null(init$kappa)) init$kappa else config$kappa
  rst_o_filter_gaussian(y_train = y_train, omega = omega, q = q, kappa = kappa)
}

rst_o_gaussian_concentrated_objective <- function(y_train, q, omega, init = NULL,
                                                  config = rst_o_config()) {
  fit <- rst_o_gaussian_filter_path(y_train = y_train, q = q, omega = omega, init = init, config = config)
  score_indices <- rst_o_score_indices(length(y_train))
  H_hat_G <- mean(fit$v[score_indices]^2 / fit$F[score_indices])
  objective <- if (is.finite(H_hat_G) && H_hat_G > 0) {
    sum(log(fit$F[score_indices])) + length(score_indices) * log(H_hat_G)
  } else {
    Inf
  }
  list(
    objective = objective,
    H_hat_G = H_hat_G,
    score_indices = score_indices,
    objective_type = fit$objective_type,
    objective_ok = is.finite(objective),
    branch = fit$branch,
    filter = fit
  )
}

rst_o_objective_gaussian <- function(y_train, omega, q) {
  rst_o_gaussian_concentrated_objective(y_train = y_train, q = q, omega = omega)
}

rst_o_finite_nu_filter_path <- function(y_train, q, omega, H, nu, init = NULL,
                                        config = rst_o_config()) {
  kappa <- if (is.list(init) && !is.null(init$kappa)) init$kappa else config$kappa
  rst_o_filter_finite_nu(y_train = y_train, omega = omega, q = q, H = H, nu = nu, kappa = kappa)
}

rst_o_finite_nu_quasi_objective <- function(y_train, q, omega, logH, nu, init = NULL,
                                            config = rst_o_config()) {
  H <- exp(logH)
  fit <- rst_o_finite_nu_filter_path(y_train = y_train, q = q, omega = omega, H = H,
                                     nu = nu, init = init, config = config)
  score_indices <- rst_o_score_indices(length(y_train))
  objective <- sum(
    0.5 * log(fit$s2_nu * fit$F[score_indices]) +
      0.5 * (nu + 1) * log1p(fit$v[score_indices]^2 / (nu * fit$s2_nu * fit$F[score_indices]))
  )
  list(
    objective = objective,
    H = H,
    logH = logH,
    score_indices = score_indices,
    objective_type = fit$objective_type,
    estimator_type = fit$estimator_type,
    objective_filter_mismatch_flag = fit$objective_filter_mismatch_flag,
    objective_ok = is.finite(objective),
    branch = fit$branch,
    filter = fit
  )
}

rst_o_objective_finite_nu <- function(y_train, omega, q, H, nu) {
  rst_o_finite_nu_quasi_objective(y_train = y_train, q = q, omega = omega,
                                  logH = log(H), nu = nu)
}

rst_o_objective_dispatch <- function(y_train, nu, omega, q, H = NULL) {
  nu <- rst_o_validate_nu(nu)
  if (is.infinite(nu)) {
    return(rst_o_objective_gaussian(y_train = y_train, omega = omega, q = q))
  }
  if (is.null(H)) {
    stop("H is required for finite-nu objective dispatch.", call. = FALSE)
  }
  rst_o_objective_finite_nu(y_train = y_train, omega = omega, q = q, H = H, nu = nu)
}
