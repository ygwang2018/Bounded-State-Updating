rst_o_filter_gaussian <- function(y_train, omega, q, kappa = rst_o_config()$kappa, initial_state = y_train[1L]) {
  y_train <- rst_o_validate_y_train(y_train)
  omega <- rst_o_validate_scalar(omega, "omega")
  q <- rst_o_validate_q(q)
  kappa <- rst_o_validate_scalar(kappa, "kappa", lower = 0, allow_equal_lower = FALSE)

  n_train <- length(y_train)
  a_pred <- P_pred <- v <- F_value <- K <- a_filt <- P_filt <- numeric(n_train)
  a_pred[1L] <- initial_state
  P_pred[1L] <- kappa

  for (t in seq_len(n_train)) {
    v[t] <- y_train[t] - a_pred[t]
    F_value[t] <- P_pred[t] + 1
    K[t] <- P_pred[t] / F_value[t]
    a_filt[t] <- a_pred[t] + K[t] * v[t]
    P_filt[t] <- P_pred[t] - K[t] * F_value[t] * K[t]
    if (P_filt[t] < -sqrt(.Machine$double.eps)) {
      stop("Gaussian filter produced negative P_filt.", call. = FALSE)
    }
    if (t < n_train) {
      a_pred[t + 1L] <- a_filt[t] + omega
      P_pred[t + 1L] <- P_filt[t] + q
    }
  }

  structure(
    list(
      branch = "gaussian_structural_theta",
      nu = Inf,
      kappa = kappa,
      omega_hat = omega,
      q_hat = q,
      y_train = y_train,
      a_pred = a_pred,
      P_pred = P_pred,
      v = v,
      F = F_value,
      K = K,
      a_filt = a_filt,
      P_filt = pmax(P_filt, 0),
      a_next_after_train = a_filt[n_train] + omega,
      weight_path = NULL,
      w_raw = NULL,
      w_tilde = NULL,
      s2_nu = NULL,
      objective_type = "gaussian_concentrated",
      estimator_type = "matched_gaussian",
      objective_filter_mismatch_flag = FALSE,
      variance_recursion_label = "matched_gaussian_kalman_recursion",
      y_test_used = FALSE
    ),
    class = c("rst_o_fit", "list")
  )
}

rst_o_filter_finite_nu <- function(y_train, omega, q, H, nu, kappa = rst_o_config()$kappa, initial_state = y_train[1L]) {
  config <- rst_o_config()
  y_train <- rst_o_validate_y_train(y_train)
  omega <- rst_o_validate_scalar(omega, "omega")
  q <- rst_o_validate_q(q)
  H <- rst_o_validate_scalar(H, "H", lower = 0, allow_equal_lower = FALSE)
  nu <- rst_o_validate_nu(nu, config, enforce_grid = FALSE)
  if (is.infinite(nu)) {
    stop("finite-nu filter received nu = Inf; use Gaussian dispatch.", call. = FALSE)
  }
  kappa <- rst_o_validate_scalar(kappa, "kappa", lower = 0, allow_equal_lower = FALSE)

  n_train <- length(y_train)
  s2_nu <- H * (nu - 2) / nu
  a_pred <- P_pred <- v <- F_value <- K <- r2 <- w_raw <- w_tilde <- a_filt <- P_filt <- numeric(n_train)
  a_pred[1L] <- initial_state
  P_pred[1L] <- kappa

  for (t in seq_len(n_train)) {
    v[t] <- y_train[t] - a_pred[t]
    F_value[t] <- P_pred[t] + 1
    K[t] <- P_pred[t] / F_value[t]
    r2[t] <- v[t]^2 / (s2_nu * F_value[t])
    w_raw[t] <- (nu + 1) / (nu + r2[t])
    w_tilde[t] <- min(1, w_raw[t])
    a_filt[t] <- a_pred[t] + w_tilde[t] * K[t] * v[t]
    P_filt[t] <- P_pred[t] - w_tilde[t] * K[t] * F_value[t] * K[t]
    if (P_filt[t] < -sqrt(.Machine$double.eps)) {
      stop("finite-nu information recursion produced negative P_filt.", call. = FALSE)
    }
    if (t < n_train) {
      a_pred[t + 1L] <- a_filt[t] + omega
      P_pred[t + 1L] <- P_filt[t] + q
    }
  }

  structure(
    list(
      branch = "finite_nu_rst_o",
      nu = nu,
      kappa = kappa,
      omega_hat = omega,
      q_hat = q,
      H_hat = H,
      y_train = y_train,
      a_pred = a_pred,
      P_pred = P_pred,
      v = v,
      F = F_value,
      K = K,
      r2 = r2,
      w_raw = w_raw,
      w_tilde = w_tilde,
      weight_path = w_tilde,
      a_filt = a_filt,
      P_filt = pmax(P_filt, 0),
      a_next_after_train = a_filt[n_train] + omega,
      s2_nu = s2_nu,
      objective_type = config$objective_type_finite_nu,
      estimator_type = config$estimator_type_finite_nu,
      objective_filter_mismatch_flag = config$objective_filter_mismatch_flag_finite_nu,
      variance_recursion_label = config$finite_variance_recursion_label,
      y_test_used = FALSE
    ),
    class = c("rst_o_fit", "list")
  )
}
