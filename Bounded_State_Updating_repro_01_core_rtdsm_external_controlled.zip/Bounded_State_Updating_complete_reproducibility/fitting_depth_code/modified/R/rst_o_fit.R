rst_o_fit <- function(y_train, nu, config = rst_o_config(), omega = NULL, q = NULL, H = NULL,
                      matched_gaussian_fit = NULL) {
  y_train <- rst_o_validate_y_train(y_train)
  nu <- rst_o_validate_nu(nu, config)
  if (is.infinite(nu)) {
    fit <- rst_o_optimize_gaussian(
      y_train = y_train,
      config = config,
      q = q,
      omega = omega
    )
  } else {
    fit <- rst_o_optimize_finite_nu(
      y_train = y_train,
      nu = nu,
      config = config,
      q = q,
      omega = omega,
      H = H,
      matched_gaussian_fit = matched_gaussian_fit
    )
  }
  fit$config_snapshot <- config
  fit
}
