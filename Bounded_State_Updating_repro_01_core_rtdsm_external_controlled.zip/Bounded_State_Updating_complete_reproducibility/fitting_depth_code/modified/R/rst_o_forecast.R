rst_o_forecast <- function(fit, horizon) {
  if (!inherits(fit, "rst_o_fit") || is.null(fit$a_next_after_train) || is.null(fit$omega_hat)) {
    stop("fit must be an rst_o_fit object.", call. = FALSE)
  }
  if (!is.numeric(horizon) || length(horizon) != 1L || !is.finite(horizon) ||
      horizon < 1L || horizon != as.integer(horizon)) {
    stop("horizon must be a positive integer scalar.", call. = FALSE)
  }
  j <- seq_len(as.integer(horizon))
  fit$a_next_after_train + (j - 1L) * fit$omega_hat
}
