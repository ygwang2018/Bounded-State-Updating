rst_o_optimizer_control_string <- function(config = rst_o_config()) {
  paste(
    paste0("outer_cycles=", config$optimizer_outer_cycles),
    paste0("tol=", config$optimizer_optimize_tol),
    paste0("max_eval=", config$optimizer_max_eval),
    sep = ";"
  )
}

rst_o_bound_string <- function(bounds) {
  paste(sprintf("%s=%s", names(bounds), format(bounds, scientific = TRUE, digits = 12L)), collapse = ";")
}

rst_o_boundary_hit <- function(value, lower, upper, tol) {
  c(
    lower_flag = isTRUE(is.finite(value) && is.finite(lower) && value <= lower + tol),
    upper_flag = isTRUE(is.finite(value) && is.finite(upper) && value >= upper - tol)
  )
}

rst_o_optimizer_status_from_flags <- function(filter_failure_flag = FALSE,
                                              forecast_failure_flag = FALSE,
                                              invalid_metric_flag = FALSE,
                                              optimizer_warning_flag = FALSE) {
  if (isTRUE(filter_failure_flag)) return("filter_failure")
  if (isTRUE(forecast_failure_flag)) return("forecast_failure")
  if (isTRUE(invalid_metric_flag)) return("invalid_metric")
  if (isTRUE(optimizer_warning_flag)) return("optimizer_warning")
  "ok"
}

rst_o_objective_trajectory_warning <- function(objective_improvement) {
  isTRUE(is.finite(objective_improvement) && objective_improvement < -sqrt(.Machine$double.eps))
}

rst_o_incumbent_preservation_tolerance <- function(config = rst_o_config()) {
  tol <- config$optimizer_incumbent_tolerance
  if (is.null(tol) || !is.numeric(tol) || length(tol) != 1L || !is.finite(tol) || tol < 0) {
    return(sqrt(.Machine$double.eps))
  }
  as.numeric(tol)
}

rst_o_preserve_incumbent <- function(candidate_objective, incumbent_objective,
                                     tolerance = sqrt(.Machine$double.eps)) {
  candidate_ok <- is.numeric(candidate_objective) && length(candidate_objective) == 1L &&
    is.finite(candidate_objective)
  incumbent_ok <- is.numeric(incumbent_objective) && length(incumbent_objective) == 1L &&
    is.finite(incumbent_objective)
  incumbent_preserved <- isTRUE(incumbent_ok && (!candidate_ok ||
    candidate_objective > incumbent_objective + tolerance))
  selected <- if (incumbent_preserved) incumbent_objective else candidate_objective
  list(
    objective_candidate = as.numeric(candidate_objective),
    objective_incumbent = as.numeric(incumbent_objective),
    objective_selected = as.numeric(selected),
    selected_source = if (incumbent_preserved) "incumbent" else "candidate",
    incumbent_preserved = incumbent_preserved,
    incumbent_preservation_tolerance = tolerance,
    incumbent_inequality_passed = isTRUE(is.finite(selected) && is.finite(incumbent_objective) &&
      selected <= incumbent_objective + tolerance)
  )
}

rst_o_safe_objective <- function(expr) {
  value <- try(expr, silent = TRUE)
  if (inherits(value, "try-error") || !is.numeric(value) || length(value) != 1L || !is.finite(value)) {
    return(.Machine$double.xmax / 1e100)
  }
  value
}

rst_o_optimizer_start_values <- function(y_train, config = rst_o_config(), q = NULL, omega = NULL) {
  preliminary <- rst_o_preliminary_estimates(y_train, config)
  omega_info <- if (is.null(omega)) {
    list(
      omega = preliminary$omega,
      omega_bound = preliminary$omega_bound,
      omega_bound_source = preliminary$omega_bound_source,
      omega_within_bound_flag = preliminary$omega_within_bound_flag
    )
  } else {
    rst_o_validate_omega_bound(omega, y_train, config)
  }
  list(
    q = if (is.null(q)) preliminary$q else rst_o_validate_q(q, config),
    omega = omega_info$omega,
    omega_bound = omega_info$omega_bound,
    omega_bound_source = omega_info$omega_bound_source,
    omega_within_bound_flag = omega_info$omega_within_bound_flag
  )
}

rst_o_optimize_gaussian <- function(y_train, config = rst_o_config(), q = NULL, omega = NULL) {
  y_train <- rst_o_validate_y_train(y_train)
  starts <- rst_o_optimizer_start_values(y_train, config, q = q, omega = omega)
  q_current <- starts$q
  omega_current <- starts$omega
  q_start <- q_current
  omega_start <- omega_current
  omega_bound <- starts$omega_bound
  eval_count <- 0L
  objective_value_start <- NA_real_
  objective_value_after_q_step <- NA_real_
  objective_value_after_omega_step <- NA_real_

  counted_objective <- function(q_value, omega_value) {
    eval_count <<- eval_count + 1L
    rst_o_safe_objective(
      rst_o_gaussian_concentrated_objective(
        y_train = y_train,
        q = q_value,
        omega = omega_value,
        config = config
      )$objective
    )
  }

  objective_value_start <- counted_objective(q_current, omega_current)

  for (cycle in seq_len(config$optimizer_outer_cycles)) {
    q_opt <- stats::optimize(
      f = function(q_value) counted_objective(q_value, omega_current),
      interval = c(config$q_lower, config$q_upper),
      tol = config$optimizer_optimize_tol
    )
    q_current <- q_opt$minimum
    objective_value_after_q_step <- q_opt$objective
    omega_opt <- stats::optimize(
      f = function(omega_value) counted_objective(q_current, omega_value),
      interval = c(-omega_bound, omega_bound),
      tol = config$optimizer_optimize_tol
    )
    omega_current <- omega_opt$minimum
    objective_value_after_omega_step <- omega_opt$objective
  }

  candidate_objective <- rst_o_gaussian_concentrated_objective(
    y_train = y_train,
    q = q_current,
    omega = omega_current,
    config = config
  )
  eval_count <- eval_count + 1L
  candidate_q <- q_current
  candidate_omega <- omega_current
  preservation <- rst_o_preserve_incumbent(
    candidate_objective = candidate_objective$objective,
    incumbent_objective = objective_value_start,
    tolerance = rst_o_incumbent_preservation_tolerance(config)
  )
  if (isTRUE(preservation$incumbent_preserved)) {
    q_current <- q_start
    omega_current <- omega_start
    final_objective <- rst_o_gaussian_concentrated_objective(
      y_train = y_train,
      q = q_current,
      omega = omega_current,
      config = config
    )
    eval_count <- eval_count + 1L
  } else {
    final_objective <- candidate_objective
  }
  objective_value_final <- final_objective$objective
  preservation$objective_selected <- objective_value_final
  preservation$incumbent_inequality_passed <- isTRUE(
    is.finite(objective_value_final) &&
      is.finite(preservation$objective_incumbent) &&
      objective_value_final <= preservation$objective_incumbent + preservation$incumbent_preservation_tolerance
  )
  objective_improvement <- objective_value_start - objective_value_final
  objective_monotone_nonincrease_flag <- !rst_o_objective_trajectory_warning(objective_improvement)
  max_eval_hit <- eval_count > config$optimizer_max_eval
  objective_ok <- isTRUE(final_objective$objective_ok)
  optimizer_warning_flag <- isTRUE(max_eval_hit || !objective_ok || !preservation$incumbent_inequality_passed)
  q_flags <- rst_o_boundary_hit(q_current, config$q_lower, config$q_upper, config$optimizer_boundary_tol)
  omega_flags <- rst_o_boundary_hit(omega_current, -omega_bound, omega_bound, config$optimizer_boundary_tol)
  H_flags <- rst_o_boundary_hit(final_objective$H_hat_G, config$H_init_floor, Inf, config$optimizer_boundary_tol)
  boundary_flag <- any(c(q_flags, omega_flags, H_flags), na.rm = TRUE)

  fit <- final_objective$filter
  fit$H_hat <- final_objective$H_hat_G
  fit$optimizer <- list(
    optimizer_type_outer = "bounded_coordinate_search_q_omega",
    optimizer_type_inner = "NA_no_inner_optimizer_gaussian",
    optimizer_function = config$optimizer_function,
    optimizer_method = config$optimizer_method,
    optimizer_control = rst_o_optimizer_control_string(config),
    optimizer_lower_bounds = rst_o_bound_string(c(q = config$q_lower, omega = -omega_bound)),
    optimizer_upper_bounds = rst_o_bound_string(c(q = config$q_upper, omega = omega_bound)),
    optimizer_status = if (optimizer_warning_flag) "bounded_coordinate_search_warning" else "bounded_coordinate_search_converged",
    objective_convergence_flag = !optimizer_warning_flag,
    optimizer_convergence_code = if (optimizer_warning_flag) 1L else 0L,
    optimizer_exit_code = if (optimizer_warning_flag) 1L else 0L,
    optimizer_message = if (optimizer_warning_flag) "nonfinite_objective_max_eval_or_incumbent_inequality_failure" else "converged_deterministic_coordinate_search",
    optimizer_warning_flag = optimizer_warning_flag,
    optimizer_warning = optimizer_warning_flag,
    objective_eval_count = eval_count,
    inner_eval_count = 0L,
    outer_eval_count = eval_count,
    objective_start = objective_value_start,
    objective_incumbent = preservation$objective_incumbent,
    objective_candidate = preservation$objective_candidate,
    objective_selected = preservation$objective_selected,
    selected_source = preservation$selected_source,
    incumbent_preserved = preservation$incumbent_preserved,
    incumbent_preservation_tolerance = preservation$incumbent_preservation_tolerance,
    incumbent_inequality_passed = preservation$incumbent_inequality_passed,
    candidate_q_fit = candidate_q,
    candidate_omega_fit = candidate_omega,
    objective_value_start = objective_value_start,
    objective_value_after_q_step = objective_value_after_q_step,
    objective_value_after_omega_step = objective_value_after_omega_step,
    objective_value_final = objective_value_final,
    objective_improvement = objective_improvement,
    objective_monotone_nonincrease_flag = objective_monotone_nonincrease_flag,
    max_eval_hit = max_eval_hit,
    boundary_flag = boundary_flag,
    q_lower_flag = q_flags[["lower_flag"]],
    q_upper_flag = q_flags[["upper_flag"]],
    H_lower_flag = H_flags[["lower_flag"]],
    H_upper_flag = FALSE,
    omega_lower_flag = omega_flags[["lower_flag"]],
    omega_upper_flag = omega_flags[["upper_flag"]],
    log_H_lower = "NA_no_inner_H_gaussian",
    log_H_upper = "NA_no_inner_H_gaussian",
    q_bound_lower = config$q_lower,
    q_bound_upper = config$q_upper,
    omega_bound_lower = -omega_bound,
    omega_bound_upper = omega_bound,
    H_or_logH_bound_lower = config$H_init_floor,
    H_or_logH_bound_upper = Inf
  )
  fit$fit_inputs <- list(
    n_train = length(y_train),
    nu = Inf,
    omega = omega_current,
    q = q_current,
    H = final_objective$H_hat_G,
    q_fit = q_current,
    omega_fit = omega_current,
    H_fit = final_objective$H_hat_G,
    logH_fit = log(final_objective$H_hat_G),
    H_init = final_objective$H_hat_G,
    H_init_source = "matched_gaussian_H_hat_G",
    H_init_candidates = c(matched_gaussian_H_hat_G = final_objective$H_hat_G),
    H_init_floor_applied = final_objective$H_hat_G <= config$H_init_floor,
    score_indices = final_objective$score_indices,
    fit_used_test_data_flag = FALSE,
    H_init_error_message = "",
    kappa = config$kappa,
    omega_bound_source = starts$omega_bound_source,
    omega_bound = omega_bound,
    omega_within_bound_flag = starts$omega_within_bound_flag,
    objective_uses_train_only = TRUE,
    optimizer_used_DGP_oracle_flag = FALSE,
    optimizer_used_future_truth_flag = FALSE,
    optimizer_used_loss_verdict_flag = FALSE
  )
  fit
}

rst_o_H_init_from_matched_gaussian <- function(y_train, config = rst_o_config(),
                                               H = NULL, matched_gaussian_fit = NULL) {
  if (!is.null(H)) {
    H <- rst_o_validate_scalar(H, "H", lower = 0, allow_equal_lower = FALSE)
    return(list(
      H = H,
      H_init_source = "user_supplied",
      H_init_candidates = c(user_supplied = H),
      H_init_floor_applied = FALSE,
      score_indices = if (length(y_train) >= 2L) rst_o_score_indices(length(y_train)) else NA_integer_,
      fit_used_test_data_flag = FALSE,
      H_init_error_message = ""
    ))
  }
  if (!is.null(matched_gaussian_fit)) {
    H_hat_G <- matched_gaussian_fit$fit_inputs$H
    score_indices <- matched_gaussian_fit$fit_inputs$score_indices
    return(rst_o_H_init_fallback_cascade(
      y_train = y_train,
      config = config,
      matched_gaussian_H_hat_G = H_hat_G,
      matched_gaussian_score_indices = score_indices
    ))
  }
  matched <- try(rst_o_optimize_gaussian(y_train = y_train, config = config), silent = TRUE)
  if (inherits(matched, "try-error")) {
    return(rst_o_H_init_fallback_cascade(
      y_train = y_train,
      config = config,
      matched_gaussian_H_hat_G = NA_real_,
      matched_gaussian_error_message = as.character(matched)
    ))
  }
  rst_o_H_init_fallback_cascade(
    y_train = y_train,
    config = config,
    matched_gaussian_H_hat_G = matched$fit_inputs$H,
    matched_gaussian_score_indices = matched$fit_inputs$score_indices
  )
}

rst_o_optimize_finite_nu <- function(y_train, nu, config = rst_o_config(), q = NULL,
                                     omega = NULL, H = NULL, matched_gaussian_fit = NULL) {
  y_train <- rst_o_validate_y_train(y_train)
  nu <- rst_o_validate_nu(nu, config)
  if (is.infinite(nu)) {
    stop("finite-nu optimizer received nu = Inf; use Gaussian optimizer.", call. = FALSE)
  }
  starts <- rst_o_optimizer_start_values(y_train, config, q = q, omega = omega)
  H_info <- rst_o_H_init_from_matched_gaussian(
    y_train = y_train,
    config = config,
    H = H,
    matched_gaussian_fit = matched_gaussian_fit
  )
  H_init <- max(H_info$H, config$H_init_floor)
  logH_lower <- log(H_init) - config$log_H_window
  logH_upper <- log(H_init) + config$log_H_window
  q_current <- starts$q
  omega_current <- starts$omega
  q_start <- q_current
  omega_start <- omega_current
  logH_start <- log(H_init)
  omega_bound <- starts$omega_bound
  inner_eval_count <- 0L
  outer_eval_count <- 0L
  objective_value_start <- rst_o_safe_objective(
    rst_o_finite_nu_quasi_objective(
      y_train = y_train,
      q = q_current,
      omega = omega_current,
      logH = logH_start,
      nu = nu,
      config = config
    )$objective
  )
  objective_value_after_q_step <- NA_real_
  objective_value_after_omega_step <- NA_real_

  inner_objective_value <- function(q_value, omega_value) {
    outer_eval_count <<- outer_eval_count + 1L
    opt <- stats::optimize(
      f = function(logH_value) {
        inner_eval_count <<- inner_eval_count + 1L
        rst_o_safe_objective(
          rst_o_finite_nu_quasi_objective(
            y_train = y_train,
            q = q_value,
            omega = omega_value,
            logH = logH_value,
            nu = nu,
            config = config
          )$objective
        )
      },
      interval = c(logH_lower, logH_upper),
      tol = config$optimizer_optimize_tol
    )
    opt$objective
  }

  for (cycle in seq_len(config$optimizer_outer_cycles)) {
    q_opt <- stats::optimize(
      f = function(q_value) inner_objective_value(q_value, omega_current),
      interval = c(config$q_lower, config$q_upper),
      tol = config$optimizer_optimize_tol
    )
    q_current <- q_opt$minimum
    objective_value_after_q_step <- q_opt$objective
    omega_opt <- stats::optimize(
      f = function(omega_value) inner_objective_value(q_current, omega_value),
      interval = c(-omega_bound, omega_bound),
      tol = config$optimizer_optimize_tol
    )
    omega_current <- omega_opt$minimum
    objective_value_after_omega_step <- omega_opt$objective
  }

  final_logH <- stats::optimize(
    f = function(logH_value) {
      inner_eval_count <<- inner_eval_count + 1L
      rst_o_safe_objective(
        rst_o_finite_nu_quasi_objective(
          y_train = y_train,
          q = q_current,
          omega = omega_current,
          logH = logH_value,
          nu = nu,
          config = config
        )$objective
      )
    },
    interval = c(logH_lower, logH_upper),
    tol = config$optimizer_optimize_tol
  )$minimum

  candidate_objective <- rst_o_finite_nu_quasi_objective(
    y_train = y_train,
    q = q_current,
    omega = omega_current,
    logH = final_logH,
    nu = nu,
    config = config
  )
  inner_eval_count <- inner_eval_count + 1L
  candidate_q <- q_current
  candidate_omega <- omega_current
  candidate_logH <- final_logH
  preservation <- rst_o_preserve_incumbent(
    candidate_objective = candidate_objective$objective,
    incumbent_objective = objective_value_start,
    tolerance = rst_o_incumbent_preservation_tolerance(config)
  )
  if (isTRUE(preservation$incumbent_preserved)) {
    q_current <- q_start
    omega_current <- omega_start
    final_logH <- logH_start
    final_objective <- rst_o_finite_nu_quasi_objective(
      y_train = y_train,
      q = q_current,
      omega = omega_current,
      logH = final_logH,
      nu = nu,
      config = config
    )
    inner_eval_count <- inner_eval_count + 1L
  } else {
    final_objective <- candidate_objective
  }
  objective_value_final <- final_objective$objective
  preservation$objective_selected <- objective_value_final
  preservation$incumbent_inequality_passed <- isTRUE(
    is.finite(objective_value_final) &&
      is.finite(preservation$objective_incumbent) &&
      objective_value_final <= preservation$objective_incumbent + preservation$incumbent_preservation_tolerance
  )
  objective_improvement <- objective_value_start - objective_value_final
  objective_monotone_nonincrease_flag <- !rst_o_objective_trajectory_warning(objective_improvement)
  objective_eval_count <- inner_eval_count
  max_eval_hit <- objective_eval_count > config$optimizer_max_eval
  objective_ok <- isTRUE(final_objective$objective_ok)
  optimizer_warning_flag <- isTRUE(max_eval_hit || !objective_ok || !preservation$incumbent_inequality_passed)
  q_flags <- rst_o_boundary_hit(q_current, config$q_lower, config$q_upper, config$optimizer_boundary_tol)
  omega_flags <- rst_o_boundary_hit(omega_current, -omega_bound, omega_bound, config$optimizer_boundary_tol)
  H_flags <- rst_o_boundary_hit(final_logH, logH_lower, logH_upper, config$optimizer_boundary_tol)
  boundary_flag <- any(c(q_flags, omega_flags, H_flags), na.rm = TRUE)

  fit <- final_objective$filter
  fit$optimizer <- list(
    optimizer_type_outer = "bounded_coordinate_search_q_omega",
    optimizer_type_inner = "bounded_Brent_logH",
    optimizer_function = config$optimizer_function,
    optimizer_method = config$optimizer_method,
    optimizer_control = rst_o_optimizer_control_string(config),
    optimizer_lower_bounds = rst_o_bound_string(c(q = config$q_lower, omega = -omega_bound, logH = logH_lower)),
    optimizer_upper_bounds = rst_o_bound_string(c(q = config$q_upper, omega = omega_bound, logH = logH_upper)),
    optimizer_status = if (optimizer_warning_flag) "bounded_coordinate_search_warning" else "bounded_coordinate_search_converged",
    objective_convergence_flag = !optimizer_warning_flag,
    optimizer_convergence_code = if (optimizer_warning_flag) 1L else 0L,
    optimizer_exit_code = if (optimizer_warning_flag) 1L else 0L,
    optimizer_message = if (optimizer_warning_flag) "nonfinite_objective_max_eval_or_incumbent_inequality_failure" else "converged_deterministic_coordinate_search",
    optimizer_warning_flag = optimizer_warning_flag,
    optimizer_warning = optimizer_warning_flag,
    objective_eval_count = objective_eval_count,
    inner_eval_count = inner_eval_count,
    outer_eval_count = outer_eval_count,
    objective_start = objective_value_start,
    objective_incumbent = preservation$objective_incumbent,
    objective_candidate = preservation$objective_candidate,
    objective_selected = preservation$objective_selected,
    selected_source = preservation$selected_source,
    incumbent_preserved = preservation$incumbent_preserved,
    incumbent_preservation_tolerance = preservation$incumbent_preservation_tolerance,
    incumbent_inequality_passed = preservation$incumbent_inequality_passed,
    candidate_q_fit = candidate_q,
    candidate_omega_fit = candidate_omega,
    candidate_logH_fit = candidate_logH,
    objective_value_start = objective_value_start,
    objective_value_after_q_step = objective_value_after_q_step,
    objective_value_after_omega_step = objective_value_after_omega_step,
    objective_value_final = objective_value_final,
    objective_improvement = objective_improvement,
    objective_monotone_nonincrease_flag = objective_monotone_nonincrease_flag,
    max_eval_hit = max_eval_hit,
    boundary_flag = boundary_flag,
    q_lower_flag = q_flags[["lower_flag"]],
    q_upper_flag = q_flags[["upper_flag"]],
    H_lower_flag = H_flags[["lower_flag"]],
    H_upper_flag = H_flags[["upper_flag"]],
    omega_lower_flag = omega_flags[["lower_flag"]],
    omega_upper_flag = omega_flags[["upper_flag"]],
    log_H_lower = logH_lower,
    log_H_upper = logH_upper,
    q_bound_lower = config$q_lower,
    q_bound_upper = config$q_upper,
    omega_bound_lower = -omega_bound,
    omega_bound_upper = omega_bound,
    H_or_logH_bound_lower = logH_lower,
    H_or_logH_bound_upper = logH_upper
  )
  fit$fit_inputs <- list(
    n_train = length(y_train),
    nu = nu,
    omega = omega_current,
    q = q_current,
    H = final_objective$H,
    q_fit = q_current,
    omega_fit = omega_current,
    H_fit = final_objective$H,
    logH_fit = final_objective$logH,
    H_init = H_init,
    H_init_source = H_info$H_init_source,
    H_init_candidates = H_info$H_init_candidates,
    H_init_floor_applied = H_info$H_init_floor_applied,
    score_indices = final_objective$score_indices,
    fit_used_test_data_flag = FALSE,
    H_init_error_message = H_info$H_init_error_message,
    kappa = config$kappa,
    omega_bound_source = starts$omega_bound_source,
    omega_bound = omega_bound,
    omega_within_bound_flag = starts$omega_within_bound_flag,
    objective_uses_train_only = TRUE,
    optimizer_used_DGP_oracle_flag = FALSE,
    optimizer_used_future_truth_flag = FALSE,
    optimizer_used_loss_verdict_flag = FALSE
  )
  fit
}
