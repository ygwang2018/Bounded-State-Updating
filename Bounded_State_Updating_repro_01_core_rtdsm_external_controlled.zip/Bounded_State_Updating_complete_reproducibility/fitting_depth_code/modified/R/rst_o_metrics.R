rst_o_compute_metrics <- function(y_train, y_test, yhat) {
  y_train <- rst_o_validate_y_train(y_train)
  if (!is.numeric(y_test) || !is.numeric(yhat) || length(y_test) != length(yhat) ||
      length(y_test) < 1L || any(!is.finite(y_test)) || any(!is.finite(yhat))) {
    stop("y_test and yhat must be finite numeric vectors of equal positive length.", call. = FALSE)
  }

  mase_denom <- mean(abs(diff(y_train)))
  rmsse_denom <- mean(diff(y_train)^2)
  if (!is.finite(mase_denom) || mase_denom <= 0) {
    stop("MASE denominator is invalid; metric must not be computed.", call. = FALSE)
  }
  if (!is.finite(rmsse_denom) || rmsse_denom <= 0) {
    stop("RMSSE denominator is invalid; metric must not be computed.", call. = FALSE)
  }

  error <- y_test - yhat
  smape_denominator <- abs(y_test) + abs(yhat)
  smape_valid <- all(is.finite(smape_denominator) & smape_denominator > 0)
  smape <- if (smape_valid) {
    mean(2 * abs(error) / smape_denominator)
  } else {
    NA_real_
  }

  list(
    MASE = mean(abs(error)) / mase_denom,
    RMSSE = sqrt(mean(error^2) / rmsse_denom),
    SMAPE = smape,
    SMAPE_valid = smape_valid,
    MASE_denom = mase_denom,
    RMSSE_denom = rmsse_denom,
    SMAPE_point_denominator = smape_denominator
  )
}
