# v1.7 revised sanity baselines. This file is intentionally isolated from
# the RST-O model code: it adds audit baselines without changing the primary
# finite-nu implementation, DGP definitions, optimizer, or metrics.

v17_scalar_or_na <- function(x) {
  if (length(x) == 1L && is.finite(x)) as.numeric(x) else NA_real_
}

v17_author_likelihood_value <- function(y, q, co) {
  y <- rst_o_validate_y_train(y)
  q <- abs(q)
  co <- abs(co)
  state <- p <- rep(0, length(y) + 1L)
  state[1L] <- y[1L]
  p[1L] <- 10000
  k <- inn <- rep(0, length(y))
  k[1L] <- p[1L] / (p[1L] + 1)
  sigmae <- 0

  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- co + state[1L] + k[1L] * inn[1L]

  for (t in 2:length(y)) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- co + state[t] + k[t] * inn[t]
  }

  sum(log(p + 1)) + length(y) * log(sigmae / length(y))
}

author_theta_structural_nonseasonal <- function(y, steps) {
  # Source: all1.R, "Structural Theta: codes and Results (Part I)",
  # Table 3 Monte Carlo section, first THETAstructural <- function(y, steps).
  # Only the non-seasonal Gaussian Structural Theta kernel is copied here.
  # all1.R/all2.R are not sourced because they execute top-level Monte Carlo
  # and M-competition code and later redefine THETAstructural.
  y <- rst_o_validate_y_train(y)
  if (!is.numeric(steps) || length(steps) != 1L || !is.finite(steps) ||
      steps < 1L || steps != as.integer(steps)) {
    stop("steps must be a positive integer scalar.", call. = FALSE)
  }
  steps <- as.integer(steps)

  likelihood <- function(parameters) {
    v17_author_likelihood_value(y, parameters[1L], parameters[2L])
  }

  results <- stats::optim(c(.01, .001), likelihood)

  q <- abs(results[[1L]][1L])
  co <- abs(results[[1L]][2L])
  state <- p <- rep(0, length(y) + 1L)
  state[1L] <- y[1L]
  p[1L] <- 10000
  k <- inn <- rep(0, length(y))
  k[1L] <- p[1L] / (p[1L] + 1)
  sigmae <- 0

  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- co + state[1L] + k[1L] * inn[1L]

  for (t in 2:length(y)) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- co + state[t] + k[t] * inn[t]
  }

  PointF <- rep(0, steps)
  PointF[1L] <- state[length(y) + 1L]
  if (steps >= 2L) {
    for (t in 2:steps) {
      PointF[t] <- co * (t - 1L) + state[length(y) + 1L]
    }
  }

  H <- sigmae / (length(y) - 1L)
  P <- tail(p, 1L) * H
  Eta <- q * H
  Inter <- c()
  Inter[1L] <- P
  if (steps >= 2L) {
    for (j in 2:steps) {
      Inter[j] <- Inter[j - 1L] + Eta
    }
  }
  Interv <- c()
  for (j in 1:steps) {
    Interv[j] <- Inter[j] + H
  }
  prob1 <- .85
  prob2 <- .95
  lower1 <- PointF - stats::qnorm((1 + prob1) / 2) * sqrt(Interv)
  upper1 <- PointF + stats::qnorm((1 + prob1) / 2) * sqrt(Interv)
  lower2 <- PointF - stats::qnorm((1 + prob2) / 2) * sqrt(Interv)
  upper2 <- PointF + stats::qnorm((1 + prob2) / 2) * sqrt(Interv)

  structure(
    list(
      mean = PointF,
      lower = cbind(lower1, lower2),
      upper = cbind(upper1, upper2),
      q_fit = q,
      omega_fit = co,
      H_fit = H,
      state = state,
      p = p,
      K = k,
      innovation = inn,
      yhat_one_step = state[seq_along(y)],
      sigmae = sigmae,
      optim = results,
      source_kernel = "all1.R Table 3 first THETAstructural nonseasonal kernel",
      fit_used_test_data_flag = FALSE,
      optimizer_used_DGP_oracle_flag = FALSE,
      optimizer_used_future_truth_flag = FALSE,
      optimizer_used_loss_verdict_flag = FALSE
    ),
    class = c("author_theta_structural_nonseasonal", "list")
  )
}

v17_forecast_author_gaussian <- function(y_train, horizon) {
  fit <- author_theta_structural_nonseasonal(y_train, horizon)
  list(
    forecast = as.numeric(fit$mean),
    fit = fit,
    warning = NULL,
    failure = NULL
  )
}

v17_forecast_oracle_trimmed_last_point <- function(y_train, horizon) {
  y_train <- rst_o_validate_y_train(y_train)
  if (length(y_train) < 3L) {
    stop("oracle trimmed-last-point baseline requires at least three training observations.", call. = FALSE)
  }
  fit <- author_theta_structural_nonseasonal(y_train[-length(y_train)], horizon + 1L)
  list(
    forecast = as.numeric(fit$mean[2:(horizon + 1L)]),
    fit = fit,
    warning = NULL,
    failure = NULL
  )
}

v17_iqr_winsorized_training_series <- function(y_train, first_fit, k = 1.5) {
  y_train <- rst_o_validate_y_train(y_train)
  residual <- as.numeric(first_fit$innovation)
  yhat <- as.numeric(first_fit$yhat_one_step)
  if (length(residual) != length(y_train) || length(yhat) != length(y_train)) {
    stop("author fit path length mismatch.", call. = FALSE)
  }
  q1 <- as.numeric(stats::quantile(residual, 0.25, type = 7, names = FALSE))
  q3 <- as.numeric(stats::quantile(residual, 0.75, type = 7, names = FALSE))
  iqr <- q3 - q1
  if (!is.finite(iqr) || iqr <= 0) {
    return(list(
      y_winsorized = y_train,
      residual = residual,
      residual_winsorized = residual,
      yhat_one_step = yhat,
      q1 = q1,
      q3 = q3,
      iqr = iqr,
      lower_fence = NA_real_,
      upper_fence = NA_real_,
      fallback_used = TRUE,
      warning_type = "iqr_zero_no_winsorization_fallback"
    ))
  }
  lower <- q1 - k * iqr
  upper <- q3 + k * iqr
  residual_w <- pmin(pmax(residual, lower), upper)
  list(
    y_winsorized = yhat + residual_w,
    residual = residual,
    residual_winsorized = residual_w,
    yhat_one_step = yhat,
    q1 = q1,
    q3 = q3,
    iqr = iqr,
    lower_fence = lower,
    upper_fence = upper,
    fallback_used = FALSE,
    warning_type = NA_character_
  )
}

v17_forecast_iqr_winsorized_author_gaussian <- function(y_train, horizon, k = 1.5, first_fit = NULL) {
  first_fit <- if (is.null(first_fit)) {
    author_theta_structural_nonseasonal(y_train, horizon)
  } else {
    first_fit
  }
  win <- v17_iqr_winsorized_training_series(y_train, first_fit, k = k)
  second_fit <- author_theta_structural_nonseasonal(win$y_winsorized, horizon)
  list(
    forecast = as.numeric(second_fit$mean),
    fit = second_fit,
    first_fit = first_fit,
    winsorization = win,
    warning = if (isTRUE(win$fallback_used)) win$warning_type else NULL,
    failure = NULL
  )
}

v17_forecast_rsto_primary_nu5 <- function(y_train, horizon, config = rst_o_config(), locked_params = NULL) {
  fit <- if (!is.null(locked_params)) {
    rst_o_filter_finite_nu(
      y_train = y_train,
      omega = as.numeric(locked_params$omega_fit),
      q = as.numeric(locked_params$q_fit),
      H = as.numeric(locked_params$H_fit),
      nu = config$primary_finite_nu_branch,
      kappa = config$kappa
    )
  } else {
    rst_o_fit(y_train, nu = config$primary_finite_nu_branch, config = config)
  }
  list(
    forecast = rst_o_forecast(fit, horizon),
    fit = fit,
    locked_v1_5_params_used = !is.null(locked_params),
    warning = NULL,
    failure = NULL
  )
}

v17_forecast_classic_theta <- function(y_train, horizon) {
  if (!requireNamespace("forecast", quietly = TRUE)) {
    return(list(
      forecast = rep(NA_real_, horizon),
      fit = NULL,
      warning = NULL,
      failure = "forecast package unavailable for classic_theta_background"
    ))
  }
  fit <- forecast::thetaf(stats::ts(y_train, frequency = 1), h = horizon, level = c(.85, .95))
  list(
    forecast = as.numeric(fit$mean),
    fit = fit,
    warning = NULL,
    failure = NULL,
    package_version = as.character(utils::packageVersion("forecast")),
    call_parameters = "forecast::thetaf(ts(y_train, frequency=1), h=horizon, level=c(.85,.95))"
  )
}

v17_baseline_definitions <- function(include_optional_clipping = FALSE) {
  out <- data.frame(
    method_id = c(
      "matched_gaussian_ST",
      "RSTO_primary_nu5",
      "iqr_winsorized_gaussian_ST",
      "oracle_trimmed_last_point_gaussian_ST",
      "classic_theta_background"
    ),
    required = c(TRUE, TRUE, TRUE, TRUE, TRUE),
    oracle = c(FALSE, FALSE, FALSE, TRUE, FALSE),
    status = c(
      "author_kernel_main_baseline",
      "existing_RSTO_primary_branch",
      "fixed_non_oracle_main_diagnostic",
      "appendix_diagnostic_only",
      "background_reference_only"
    ),
    G_H_verdict_eligible = c(FALSE, FALSE, TRUE, FALSE, FALSE),
    implementation_path = c(
      "author_theta_structural_nonseasonal",
      "rst_o_fit(nu = 5)",
      "author kernel + training-residual IQR winsorization + author refit",
      "drop y_n + author h+1 forecast steps 2..h+1",
      "forecast::thetaf if forecast package is available"
    ),
    stringsAsFactors = FALSE
  )
  if (isTRUE(include_optional_clipping)) {
    out <- rbind(out, data.frame(
      method_id = "residual_clipping_gaussian_ST",
      required = FALSE,
      oracle = FALSE,
      status = "optional_not_in_default_v1_7_revised_run",
      G_H_verdict_eligible = FALSE,
      implementation_path = "not executed by default",
      stringsAsFactors = FALSE
    ))
  }
  rownames(out) <- NULL
  out
}

v17_compute_metric_record <- function(y_train, y_test, yhat) {
  metrics <- rst_o_compute_metrics(y_train, y_test, yhat)
  error <- y_test - yhat
  metrics$RMSE <- sqrt(mean(error^2))
  metrics
}

v17_method_result <- function(series, design_row, method_id, config = rst_o_config(), precomputed = list()) {
  start_time <- proc.time()[["elapsed"]]
  fit_result <- tryCatch(
    switch(
      method_id,
      matched_gaussian_ST = if (!is.null(precomputed$matched_gaussian_author_fit)) {
        list(
          forecast = as.numeric(precomputed$matched_gaussian_author_fit$mean),
          fit = precomputed$matched_gaussian_author_fit,
          warning = NULL,
          failure = NULL
        )
      } else {
        v17_forecast_author_gaussian(series$y_train, series$horizon)
      },
      RSTO_primary_nu5 = v17_forecast_rsto_primary_nu5(
        series$y_train,
        series$horizon,
        config,
        locked_params = precomputed$locked_rsto_params
      ),
      iqr_winsorized_gaussian_ST = v17_forecast_iqr_winsorized_author_gaussian(
        series$y_train,
        series$horizon,
        first_fit = precomputed$matched_gaussian_author_fit
      ),
      oracle_trimmed_last_point_gaussian_ST = v17_forecast_oracle_trimmed_last_point(series$y_train, series$horizon),
      classic_theta_background = v17_forecast_classic_theta(series$y_train, series$horizon),
      stop(sprintf("Unknown v1.7 method_id: %s", method_id), call. = FALSE)
    ),
    error = function(e) list(
      forecast = rep(NA_real_, series$horizon),
      fit = NULL,
      warning = NULL,
      failure = conditionMessage(e)
    )
  )
  runtime_seconds <- proc.time()[["elapsed"]] - start_time
  failure <- fit_result$failure
  valid_forecast <- is.numeric(fit_result$forecast) &&
    length(fit_result$forecast) == series$horizon &&
    all(is.finite(fit_result$forecast))
  metric_error <- NULL
  metrics <- if (is.null(failure) && valid_forecast) {
    tryCatch(
      v17_compute_metric_record(series$y_train, series$y_test, fit_result$forecast),
      error = function(e) {
        metric_error <<- conditionMessage(e)
        NULL
      }
    )
  } else {
    NULL
  }
  failed <- !is.null(failure) || !valid_forecast || is.null(metrics)
  if (is.null(metrics)) {
    metrics <- list(MASE = NA_real_, RMSSE = NA_real_, SMAPE = NA_real_,
                    RMSE = NA_real_, MASE_denom = NA_real_, RMSSE_denom = NA_real_)
  }
  row <- as.list(design_row)
  series_record <- lapply(rst_o_build_series_record(series, design_row, config), rst_o_collapse_field)
  fit <- fit_result$fit
  win <- fit_result$winsorization
  data.frame(
    series_record,
    method_id = method_id,
    branch_id = method_id,
    nu_fit = if (method_id == "RSTO_primary_nu5") config$primary_finite_nu_branch else NA_real_,
    metric_MASE = metrics$MASE,
    metric_RMSSE = metrics$RMSSE,
    metric_SMAPE = metrics$SMAPE,
    metric_RMSE = metrics$RMSE,
    MASE_denom = metrics$MASE_denom,
    RMSSE_denom = metrics$RMSSE_denom,
    q_fit = v17_scalar_or_na(fit$q_fit),
    omega_fit = v17_scalar_or_na(fit$omega_fit),
    H_fit = v17_scalar_or_na(fit$H_fit),
    author_kernel_used = method_id %in% c(
      "matched_gaussian_ST",
      "iqr_winsorized_gaussian_ST",
      "oracle_trimmed_last_point_gaussian_ST"
    ),
    internal_gaussian_rst_o_fit_inf_used = FALSE,
    RSTO_primary_nu5_existing_implementation_used = method_id == "RSTO_primary_nu5",
    RSTO_primary_nu5_locked_v1_5_params_used = isTRUE(fit_result$locked_v1_5_params_used),
    iqr_k = if (method_id == "iqr_winsorized_gaussian_ST") 1.5 else NA_real_,
    iqr_quantile_type = if (method_id == "iqr_winsorized_gaussian_ST") 7L else NA_integer_,
    iqr_q1 = v17_scalar_or_na(win$q1),
    iqr_q3 = v17_scalar_or_na(win$q3),
    iqr_value = v17_scalar_or_na(win$iqr),
    iqr_lower_fence = v17_scalar_or_na(win$lower_fence),
    iqr_upper_fence = v17_scalar_or_na(win$upper_fence),
    iqr_no_winsorization_fallback = isTRUE(win$fallback_used),
    oracle = method_id == "oracle_trimmed_last_point_gaussian_ST",
    background_reference_only = method_id == "classic_theta_background",
    GH_verdict_eligible = method_id == "iqr_winsorized_gaussian_ST",
    fit_used_test_data_flag = FALSE,
    optimizer_used_DGP_oracle_flag = method_id == "oracle_trimmed_last_point_gaussian_ST",
    optimizer_used_future_truth_flag = FALSE,
    optimizer_used_loss_verdict_flag = FALSE,
    failure_flag = failed,
    failure_message = if (!is.null(failure)) failure else if (!is.null(metric_error)) metric_error else "",
    warning_flag = !is.null(fit_result$warning),
    warning_message = if (!is.null(fit_result$warning)) fit_result$warning else "",
    status = if (failed) "failure" else if (!is.null(fit_result$warning)) "warning" else "ok",
    runtime_seconds = runtime_seconds,
    classic_theta_package_version = if (!is.null(fit_result$package_version)) fit_result$package_version else NA_character_,
    classic_theta_call_parameters = if (!is.null(fit_result$call_parameters)) fit_result$call_parameters else NA_character_,
    stringsAsFactors = FALSE
  )
}

v17_allowed_methods_for_family <- function(family) {
  if (family == "DGP2-main") {
    return(c("matched_gaussian_ST", "RSTO_primary_nu5", "iqr_winsorized_gaussian_ST", "classic_theta_background"))
  }
  if (family == "DGP2-last-point-stress") {
    return(c("matched_gaussian_ST", "RSTO_primary_nu5", "iqr_winsorized_gaussian_ST",
             "oracle_trimmed_last_point_gaussian_ST", "classic_theta_background"))
  }
  if (family %in% c("DGP1-main", "DGP4-main")) {
    return(c("matched_gaussian_ST", "RSTO_primary_nu5", "iqr_winsorized_gaussian_ST", "classic_theta_background"))
  }
  character(0)
}
