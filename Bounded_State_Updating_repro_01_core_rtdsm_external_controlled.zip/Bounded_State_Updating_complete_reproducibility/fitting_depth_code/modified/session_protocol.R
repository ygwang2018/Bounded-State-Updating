options(stringsAsFactors=FALSE, warn=1)
.libPaths(unique(c('','',.libPaths())))
ROOT <- '.'
stopifnot(as.character(getRversion())=='4.3.3', as.character(packageVersion('forecast'))=='8.24.0',as.character(packageVersion('Mcomp'))=='2.8')
library(forecast)
library(Mcomp)
writeLines(c(capture.output(sessionInfo()),'',capture.output(formals(forecast::ets)),capture.output(formals(forecast::auto.arima))),file.path(ROOT,'08_LOGS_SESSION/SESSION_INFO.txt'))
data('M3',package='Mcomp');saveRDS(M3,file.path(ROOT,'01_CODE_SNAPSHOT/inputs/M3_frozen.rds'))
writeLines(c('# R1 fitting-depth protocol','',paste('Frozen before batch:',Sys.time()),
'Scope: 450 RTDSM origins, PRE/REF, 4 internal methods, D1/D3/DSTABLE; all 3003 M3 series, Primary clean and terminal last-3 +/-6*max(sd,IQR/1.349,1e-6) arms, official holdout, clean-frozen/full-refit.',
'All depths begin at the same original q/omega starting tuple. Finite-method H0 and logH interval come from the ORIGINAL one-sweep Gaussian fit/fallback; never from deeper Gaussian fitting. Gaussian H is concentrated analytically.',
'Source audit: finite methods profile logH inside each q and omega objective. Preserve q search -> omega search -> final logH search, with the original nested profiling; a simple non-profiled three-coordinate replacement is prohibited.',
'q bounds [1e-8,10]; omega +/-10*training_scale/n; logH=log(H0)+/-8; P1=10000; nu=5; Huber=1.345; stats::optimize tol=0.01 unchanged.',
'D1=one raw sweep, D3=three raw sweeps. At endpoint preserve original starting incumbent if candidate objective exceeds original objective + sqrt(.Machine$double.eps), exactly as frozen code. No per-coordinate or per-sweep incumbent intervention changes the raw trajectory.',
'DSTABLE max=30 sweeps, min=3. Two consecutive raw sweep transitions must satisfy BOTH abs(Jnew-Jold)/max(1,abs(Jold)) <= 1e-6 and max dimensionless parameter change <= 1e-3. Normalize q difference by q interval width, omega by omega interval width, logH by original logH interval width 16. Gaussian stability includes logH change/16 for the analytically concentrated H.',
'Raw candidate states/objectives determine stability (an unchanged preserved incumbent alone is NOT stability). Same raw prefix may be computed once and reused for D1/D3/DSTABLE: mathematically identical deterministic calls from the same original starting tuple, never warm-starting a different fit.',
'Boundary-hit flags use frozen absolute tolerance 1e-7 on q, omega and logH bounds. No enlargement, clipping or refit. Boundary convergence is STABLE_BOUNDARY; other convergence STABLE_INTERIOR; depth-limited fits FIXED_DEPTH; max without criterion MAX_SWEEPS_UNSTABLE.',
'Nonfinite objectives use the original safe objective sentinel during search; record nonfinite counts and never label a final nonfinite result stable. Final invalid path is FAILED_NONFINITE with NA forecast. No fallback forecasts. Original optimizer_max_eval=5000 is diagnostic only, as in source; preserve and report when exceeded.',
'Incumbent-selected stable raw endpoints are labeled STABLE_RAW_INCUMBENT_SELECTED; this is not an optimized stationary-point claim.',
'D1 audit: per-fit forecast/parameter identity to original code within 1e-10*(1+abs(original)); RTDSM stored forecast and M3 MB/CB stored losses within 1e-8*(1+abs(original)); aggregate printed reference tolerance 2e-6. Stop R1 on substantive mismatch before deeper batch.',
'RTDSM phases unchanged: through 2020-02, 2020-03--07, 2020-08--2021-12, 2022-01--2025-06. Descriptive paired comparisons only; no iid-origin significance tests.',
'Primary decision contrasts: M3 pooled MB-minus-CB frozen MASE <0 and full MASE >0; RTDSM EMPLOY and CUT five-month shock-period error/revision contrasts and monthly trajectories, compared at identical interfaces and evaluation targets. Report all depths and unresolved maximum-sweep fits; no winner-driven retuning.',
'Replication eligibility is assessed only after complete Primary results; no automatic Recovery or new designs. TARGETED_REBUILD is returned without manuscript edits or rescue runs.'),file.path(ROOT,'00_PROTOCOL/R1_FITTING_DEPTH_PROTOCOL.md'))
writeLines(c('# R2 benchmark protocol','',paste('Frozen before batch:',Sys.time()),
'R 4.3.3; forecast 8.24.0; installed package and function defaults captured in SESSION_INFO.txt and package SHA256 manifest.',
'Exact calls: fit_ets <- forecast::ets(ts(y, frequency = 1)); fc_ets <- forecast::forecast(fit_ets, h = 1)$mean[1].',
'Exact calls: fit_arima <- forecast::auto.arima(ts(y, frequency = 1)); fc_arima <- forecast::forecast(fit_arima, h = 1)$mean[1].',
'No non-default fitting arguments. Single-process deterministic loop; no changes to d/D, bounds, approximation, stepwise, lambda, trend or frequency.',
'Scope: 5 series * 90 origins * PRE/REF * 2 methods = 1800 rows; h1, full-refit only, exact frozen 120 transformed values and Third target; phase definitions identical to R1.',
'Capture warnings while retaining returned finite fits; fit error or nonfinite forecast creates FAILED row with NA forecast/errors, literal failure reason and no fallback, deletion or adaptive retry. Revision = REF minus PRE plus its absolute value; missing partner leaves NA.',
'Save selected model/order/components/damping/drift/mean, AIC/AICc/BIC and available optimizer convergence. No third benchmark and no performance-based changes.'),file.path(ROOT,'00_PROTOCOL/R2_BENCHMARK_PROTOCOL.md'))
cat('SESSION_PROTOCOL_READY\n')
