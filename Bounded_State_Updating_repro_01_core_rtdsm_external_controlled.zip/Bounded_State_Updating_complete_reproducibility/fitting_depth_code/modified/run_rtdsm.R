source('01_CODE_SNAPSHOT/modified/r1_common.R',encoding='UTF-8')
sn<-commandArgs(TRUE)[1L]
stopifnot(sn%in%c('EMPLOY','IPT','IPM','H','CUT'))
INP<-file.path(ROOT,'01_CODE_SNAPSHOT/inputs/realtime')
tr<-fread(file.path(INP,'complete_vintage_training_long.csv'));tr<-tr[series==sn];setorder(tr,target,interface,train_date)
orig<-fread(file.path(INP,'complete_vintage_origin_manifest.csv'))[series==sn]
baseline<-fread(file.path(INP,'complete_vintage_full_refit_long.csv'))[series==sn]
oldfrozen<-fread(file.path(INP,'complete_vintage_ref_frozen_long.csv'))[series==sn]
fits<-forecasts<-traces<-mechanisms<-qa<-list();nf<-nr<-nt<-nm<-nq<-0L
outdir<-file.path(ROOT,'03_R1_RTDSM/shards');dir.create(outdir,showWarnings=FALSE)
qa_dir<-file.path(ROOT,'02_FIXED_INITIALIZATION/shards');dir.create(qa_dir,showWarnings=FALSE)
qapath<-file.path(qa_dir,paste0(sn,'_qa.csv'))
completed_dates<-character()
if(file.exists(qapath)){
  previous_qa<-fread(qapath,colClasses=c(target_date='character'));completed_dates<-unique(previous_qa$target_date)
  load_completed<-function(suffix){
    z<-fread(file.path(outdir,paste0(sn,suffix)),colClasses=c(target_date='character'));z<-z[target_date%in%completed_dates]
    if('train_date'%in%names(z))z[,train_date:=as.character(train_date)]
    list(z)
  }
  qa<-list(previous_qa);nq<-1L
  fits<-load_completed('_fits.csv');nf<-1L
  forecasts<-load_completed('_forecasts.csv');nr<-1L
  traces<-load_completed('_trace.csv');nt<-1L
  mp<-file.path(outdir,paste0(sn,'_mechanism.csv'))
  if(file.exists(mp)){mechanisms<-load_completed('_mechanism.csv');nm<-1L}
  cat('RESUME completed origins=',length(completed_dates),'\n')
}
old_replay<-function(y,m,f){
  if(m=='G_MATCH')OLD$rst_o_filter_gaussian(y,f$omega_hat,f$q_hat) else if(m=='CB_ST')OLD$rst_o_filter_finite_nu(y,f$omega_hat,f$q_hat,f$H_hat,5) else if(m=='MB_ST')OLD$gate_f_mb_filter(y,f$omega_hat,f$q_hat,f$H_hat) else OLD$gate_f_huber_filter(y,f$omega_hat,f$q_hat,f$H_hat)
}
save_outputs<-function(){
  fwrite(rbindlist(fits),file.path(outdir,paste0(sn,'_fits.csv')))
  fwrite(rbindlist(forecasts),file.path(outdir,paste0(sn,'_forecasts.csv')))
  fwrite(rbindlist(traces),file.path(outdir,paste0(sn,'_trace.csv')))
  if(length(mechanisms))fwrite(rbindlist(mechanisms),file.path(outdir,paste0(sn,'_mechanism.csv')))
  fwrite(rbindlist(qa),file.path(qa_dir,paste0(sn,'_qa.csv')))
}
for(i in seq_len(nrow(orig))){
  date<-as.character(orig$target_date[i]);truth<-orig$truth_third[i]
  if(date%in%completed_dates)next
  yy<-lapply(c('PRE','REF'),function(p)tr[target==date&interface==p,y]);names(yy)<-c('PRE','REF')
  stopifnot(all(lengths(yy)==120L))
  bundles<-list()
  for(p in names(yy)){
    y<-yy[[p]];g0<-NEW$rst_o_fit(y,Inf);bundles[[p]]<-list()
    for(m in methods){
      t0<-proc.time()[3];a<-depth_fit(y,m,original_gaussian=g0);bundles[[p]][[m]]<-a
      b<-baseline[target_date==date&method==m]
      stored<-if(p=='PRE')b$forecast_pre_realtime else b$forecast_ref_replay
      if(!near(a$endpoints$D1$info$forecast_h1,stored,1e-8)){
        fwrite(data.table(series=sn,target_date=date,interface=p,method=m,current=a$endpoints$D1$info$forecast_h1,stored=stored),file.path(outdir,paste0(sn,'_D1_FAILURE.csv')))
        save_outputs();stop('D1 stored full-refit forecast mismatch: ',sn,' ',date,' ',p,' ',m)
      }
      for(d in names(a$endpoints)){
        nf<-nf+1L;fits[[nf]]<-cbind(data.table(series=sn,target_date=date,interface=p,method=m,depth=d,n_train=120L,phase=phase(date),runtime_all_depths_sec=unname(proc.time()[3]-t0)),a$endpoints[[d]]$info)
      }
      nt<-nt+1L;traces[[nt]]<-cbind(data.table(series=sn,target_date=date,interface=p,method=m),a$trace)
    }
  }
  for(m in methods){
    ref1<-bundles$REF[[m]]$endpoints$D1$fit
    oldpre<-fcfit(old_replay(yy$PRE,m,ref1));newpre<-fcfit(replay(yy$PRE,m,ref1,yy$REF[1L]));ref_fc<-fcfit(ref1)
    bf<-oldfrozen[target_date==date&method==m]
    full_unchanged<-all(vapply(names(yy),function(p){ff<-bundles[[p]][[m]]$endpoints$D1$fit;identical(fcfit(old_replay(yy[[p]],m,ff)),fcfit(replay(yy[[p]],m,ff)))},logical(1)))
    stopifnot(full_unchanged,near(oldpre,bf$forecast_pre_refparams,1e-8),near(ref_fc,bf$forecast_ref_refparams,1e-8))
    nq<-nq+1L;qa[[nq]]<-data.table(series=sn,target_date=date,first_pre=yy$PRE[1L],first_ref=yy$REF[1L],first_values_differ=yy$PRE[1L]!=yy$REF[1L],method=m,old_frozen_pre_forecast=oldpre,new_frozen_pre_forecast=newpre,ref_forecast=ref_fc,changed_by_init_alignment=!identical(oldpre,newpre),forecast_change=newpre-oldpre,full_refit_unchanged=full_unchanged,old_stored_reproduction_pass=TRUE)
    for(d in c('D1','D3','DSTABLE'))for(iface in c('full_refit','reference_frozen'))for(p in names(yy)){
      f<-if(iface=='full_refit')bundles[[p]][[m]]$endpoints[[d]]$fit else replay(yy[[p]],m,bundles$REF[[m]]$endpoints[[d]]$fit,yy$REF[1L])
      fc<-fcfit(f)
      nr<-nr+1L;forecasts[[nr]]<-data.table(series=sn,target_date=date,interface=p,fit_interface=iface,method=m,depth=d,phase=phase(date),forecast_h1=fc,target_third=truth,abs_error=abs(fc-truth),sq_error=(fc-truth)^2,initial_state=if(iface=='full_refit')yy[[p]][1L] else yy$REF[1L],fit_status='OK')
      if(sn%in%c('EMPLOY','CUT')&&date>='2020-03-01'&&date<='2020-07-01'){
        ix<-109:120;weight<-if(m=='G_MATCH')rep(1,120) else if(m=='HUBER_ST')f$lambda else f$w_tilde
        nm<-nm+1L;mechanisms[[nm]]<-data.table(series=sn,target_date=date,interface=p,fit_interface=iface,method=m,depth=d,train_index=ix,train_date=as.character(tr[target==date&interface==p,train_date][ix]),observation=yy[[p]][ix],initial_state=if(iface=='full_refit')yy[[p]][1L] else yy$REF[1L],state_prior=f$a_pred[ix],state_posterior=f$a_filt[ix],P_prior=f$P_pred[ix],P_posterior=f$P_filt[ix],innovation=f$v[ix],K=f$K[ix],response_weight=weight[ix],psi_v=weight[ix]*f$v[ix],Kpsi_v=f$K[ix]*weight[ix]*f$v[ix],q=f$q_hat,omega=f$omega_hat,H=f$H_hat,last_state=tail(f$a_filt,1),forecast_h1=fc,target_third=truth)
      }
    }
  }
  ap<-NEW$fit_author_gaussian(yy$PRE);ar<-NEW$fit_author_gaussian(yy$REF)
  oldpre<-NEW$fixed_author_gaussian(yy$PRE,ar$omega,ar$q);newpre<-NEW$fixed_author_gaussian(yy$PRE,ar$omega,ar$q,initial_state=yy$REF[1])
  b<-baseline[target_date==date&method=='ST_AUTHOR'];bf<-oldfrozen[target_date==date&method=='ST_AUTHOR']
  fullpass<-near(ap$mean,b$forecast_pre_realtime,1e-8)&&near(ar$mean,b$forecast_ref_replay,1e-8)
  stopifnot(fullpass,near(oldpre,bf$forecast_pre_refparams,1e-8))
  nq<-nq+1L;qa[[nq]]<-data.table(series=sn,target_date=date,first_pre=yy$PRE[1],first_ref=yy$REF[1],first_values_differ=yy$PRE[1]!=yy$REF[1],method='ST_AUTHOR',old_frozen_pre_forecast=oldpre,new_frozen_pre_forecast=newpre,ref_forecast=ar$mean,changed_by_init_alignment=!identical(oldpre,newpre),forecast_change=newpre-oldpre,full_refit_unchanged=fullpass,old_stored_reproduction_pass=TRUE)
  if(i%%5L==0L||i==nrow(orig)){save_outputs();cat(format(Sys.time()),sn,i,'/',nrow(orig),'\n');flush.console()}
}
writeLines('COMPLETE',file.path(outdir,paste0(sn,'_COMPLETE.txt')))
