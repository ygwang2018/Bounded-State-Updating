# R2 benchmark protocol

Frozen before batch: 2026-09-05 18:36:43.435408
R 4.3.3; forecast 8.24.0; installed package and function defaults captured in SESSION_INFO.txt and package SHA256 manifest.
Exact calls: fit_ets <- forecast::ets(ts(y, frequency = 1)); fc_ets <- forecast::forecast(fit_ets, h = 1)$mean[1].
Exact calls: fit_arima <- forecast::auto.arima(ts(y, frequency = 1)); fc_arima <- forecast::forecast(fit_arima, h = 1)$mean[1].
No non-default fitting arguments. Single-process deterministic loop; no changes to d/D, bounds, approximation, stepwise, lambda, trend or frequency.
Scope: 5 series * 90 origins * PRE/REF * 2 methods = 1800 rows; h1, full-refit only, exact frozen 120 transformed values and Third target; phase definitions identical to R1.
Capture warnings while retaining returned finite fits; fit error or nonfinite forecast creates FAILED row with NA forecast/errors, literal failure reason and no fallback, deletion or adaptive retry. Revision = REF minus PRE plus its absolute value; missing partner leaves NA.
Save selected model/order/components/damping/drift/mean, AIC/AICc/BIC and available optimizer convergence. No third benchmark and no performance-based changes.
