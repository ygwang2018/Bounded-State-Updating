# Run from this figure_table_source_data directory.
suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(svglite)
  library(ragg)
})

# Terminal figure redraw. All empirical values are read unchanged from the
# frozen source-data CSV files copied with this script. Figure 1 is analytic.

width_mm <- 165

okabe_ito <- c(
  black = "#000000",
  orange = "#E69F00",
  sky = "#56B4E9",
  green = "#009E73",
  yellow = "#F0E442",
  blue = "#0072B2",
  vermillion = "#D55E00",
  purple = "#CC79A7"
)

base_theme <- theme_classic(base_size = 9.5, base_family = "Arial") +
  theme(
    axis.line = element_line(linewidth = 0.38, colour = "#222222"),
    axis.ticks = element_line(linewidth = 0.38, colour = "#222222"),
    axis.title = element_text(size = 9.2),
    axis.text = element_text(size = 8.5, colour = "#222222"),
    legend.title = element_blank(),
    legend.text = element_text(size = 8.2),
    legend.key.width = unit(14, "pt"),
    legend.key.height = unit(9, "pt"),
    plot.tag = element_text(size = 10, face = "bold"),
    plot.tag.position = c(0.01, 0.99),
    plot.margin = margin(5, 6, 4, 5),
    panel.grid = element_blank()
  )

theme_set(base_theme)

save_pub <- function(plot, filename, width_mm, height_mm, dpi = 1000) {
  w <- width_mm / 25.4
  h <- height_mm / 25.4

  svglite::svglite(paste0(filename, ".svg"), width = w, height = h)
  print(plot)
  dev.off()

  grDevices::cairo_pdf(paste0(filename, ".pdf"), width = w, height = h,
                       family = "Arial", onefile = TRUE)
  print(plot)
  dev.off()

  ragg::agg_tiff(paste0(filename, ".tiff"), width = w, height = h,
                 units = "in", res = dpi, background = "white",
                 compression = "lzw")
  print(plot)
  dev.off()

  ragg::agg_png(paste0(filename, "_preview.png"), width = w, height = h,
                units = "in", res = 300, background = "white")
  print(plot)
  dev.off()
}

# -----------------------------------------------------------------------------
# Figure 1 contract
# Task: separate the bounded mean-response interface from the working-P update.
# Evidence: exact response identities at nu=5, c_H=1.345 and P=1.
# Panels: (a) mean response; (b) working-P ratio. No empirical statistics.
# -----------------------------------------------------------------------------
x <- seq(-6, 6, length.out = 1201)
nu <- 5
c_h <- 1.345
w_st <- pmin(1, (nu + 1) / (nu + nu * x^2 / (nu - 2)))

response <- rbind(
  data.frame(x = x, value = x, series = "G-MATCH"),
  data.frame(x = x, value = pmax(-c_h, pmin(c_h, x)), series = "Huber-ST"),
  data.frame(x = x, value = x * w_st, series = "MB-ST")
)

variance <- rbind(
  data.frame(x = x, value = 0.5, series = "MB-ST"),
  data.frame(x = x, value = 1 - 0.5 * w_st, series = "CB-ST")
)

figure1_source <- rbind(
  transform(response, panel = "mean_response"),
  transform(variance, panel = "working_uncertainty")
)
write.csv(figure1_source,
          "figure1_response.csv",
          row.names = FALSE)

f1_levels <- c("G-MATCH", "Huber-ST", "MB-ST", "CB-ST")
f1_colours <- c(
  `G-MATCH` = unname(okabe_ito["black"]),
  `Huber-ST` = unname(okabe_ito["blue"]),
  `MB-ST` = unname(okabe_ito["vermillion"]),
  `CB-ST` = unname(okabe_ito["purple"])
)
f1_types <- c(
  `G-MATCH` = "solid",
  `Huber-ST` = "dashed",
  `MB-ST` = "dotdash",
  `CB-ST` = "longdash"
)

common_f1_scales <- list(
  scale_colour_manual(
    values = f1_colours, limits = f1_levels, drop = FALSE, name = NULL,
    guide = guide_legend(override.aes = list(linetype = unname(f1_types[f1_levels])))
  ),
  scale_linetype_manual(values = f1_types, limits = f1_levels, drop = FALSE, guide = "none")
)

p1a <- ggplot(response, aes(x, value, colour = series, linetype = series)) +
  geom_hline(yintercept = 0, linewidth = 0.30, colour = "#B8B8B8") +
  geom_vline(xintercept = 0, linewidth = 0.30, colour = "#B8B8B8") +
  geom_line(linewidth = 0.82) +
  common_f1_scales +
  coord_cartesian(xlim = c(-5, 5), ylim = c(-2, 2), expand = FALSE) +
  labs(x = "Standardized innovation", y = "Standardized mean correction") +
  theme(legend.position = "bottom")

p1b <- ggplot(variance, aes(x, value, colour = series, linetype = series)) +
  geom_line(linewidth = 0.86) +
  common_f1_scales +
  scale_y_continuous(limits = c(0.45, 1.02), breaks = c(0.50, 0.75, 1.00),
                     expand = expansion(mult = c(0, 0.02))) +
  coord_cartesian(xlim = c(-5, 5), expand = FALSE) +
  labs(x = "Standardized innovation", y = "Post-update P / pre-update P") +
  guides(colour = "none") +
  theme(legend.position = "none")

fig1 <- (p1a | p1b) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = "a") &
  theme(legend.position = "bottom",
        legend.box = "vertical",
        legend.margin = margin(t = 1, unit = "pt"))

save_pub(fig1, "../../01_ENGLISH_CANONICAL/figures/figure1_response", width_mm, 74)

# -----------------------------------------------------------------------------
# Figure 2 contract
# Task: show accumulation of false state writing and contraction during recovery.
# Evidence: frozen controlled_evidence.csv; no added smoothing or intervals.
# Panels: (a) k=1,3,5 accumulation; (b) d=0,1,2,4,8 clean recovery.
# -----------------------------------------------------------------------------
controlled <- read.csv("controlled_evidence.csv",
                       check.names = FALSE)
acc <- subset(controlled, panel == "accumulation")
rec <- subset(controlled, panel == "recovery")
acc$method <- ifelse(acc$method == "Gaussian", "G-MATCH", "Huber-ST")
rec$method <- ifelse(rec$method == "Gaussian", "G-MATCH", "Huber-ST")

f2_levels <- c("G-MATCH", "Huber-ST")
f2_colours <- c(`G-MATCH` = unname(okabe_ito["black"]), `Huber-ST` = unname(okabe_ito["blue"]))
f2_types <- c(`G-MATCH` = "solid", `Huber-ST` = "dashed")
f2_shapes <- c(`G-MATCH` = 16, `Huber-ST` = 17)

f2_scales <- list(
  scale_colour_manual(
    values = f2_colours, limits = f2_levels, name = NULL,
    guide = guide_legend(override.aes = list(
      linetype = unname(f2_types[f2_levels]),
      shape = unname(f2_shapes[f2_levels])
    ))
  ),
  scale_linetype_manual(values = f2_types, limits = f2_levels, guide = "none"),
  scale_shape_manual(values = f2_shapes, limits = f2_levels, guide = "none")
)

p2a <- ggplot(acc, aes(x, estimate, colour = method, linetype = method,
                       shape = method, group = method)) +
  geom_line(linewidth = 0.82) +
  geom_point(size = 2.35, stroke = 0.45) +
  f2_scales +
  scale_x_continuous(breaks = c(1, 3, 5)) +
  scale_y_continuous(limits = c(0, 0.62), breaks = seq(0, 0.6, by = 0.1),
                     expand = expansion(mult = c(0, 0.02))) +
  labs(x = "Contaminated block length, k", y = "Normalized retained displacement") +
  theme(legend.position = "bottom")

p2b <- ggplot(rec, aes(x, estimate, colour = method, linetype = method,
                       shape = method, group = method)) +
  geom_line(linewidth = 0.82) +
  geom_point(size = 2.35, stroke = 0.45) +
  f2_scales +
  scale_x_continuous(breaks = c(0, 1, 2, 4, 8)) +
  scale_y_continuous(limits = c(0, 0.62), breaks = seq(0, 0.6, by = 0.1),
                     expand = expansion(mult = c(0, 0.02))) +
  labs(x = "Subsequent clean observations, d", y = "Normalized retained displacement") +
  theme(legend.position = "bottom")

fig2 <- (p2a | p2b) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = "a") &
  theme(legend.position = "bottom",
        legend.margin = margin(t = 1, unit = "pt"),
        plot.tag.position = c(0.055, 0.985),
        axis.title.y = element_text(margin = margin(r = 7)))

save_pub(fig2, "../../01_ENGLISH_CANONICAL/figures/figure2_controlled", width_mm, 69)

# -----------------------------------------------------------------------------
# Figure 3 contract
# Task: show the fitted-layer contribution and the CB-MB ordering change.
# Evidence: frozen fitted_evidence.csv; 95% paired series-bootstrap intervals.
# Panels: (a) Delta_refit by method/profile; (b) CB-MB under frozen/full fits.
# The CB-ROBETS end-to-end result is moved to manuscript Table 3.
# -----------------------------------------------------------------------------
fitted <- read.csv("fitted_evidence.csv", check.names = FALSE)
refit <- subset(fitted, panel == "refit")
cbmb <- subset(fitted, panel == "cbmb")
refit$method <- ifelse(refit$method == "Huber", "Huber-ST", ifelse(refit$method == "MB", "MB-ST", "CB-ST"))

profile_base <- c(Primary = 3, Replication = 2, Recovery = 1)
refit_offset <- c(`Huber-ST` = 0.22, `MB-ST` = 0, `CB-ST` = -0.22)
cbmb_offset <- c(Frozen = 0.16, Full = -0.16)

refit$y <- unname(profile_base[refit$design]) + unname(refit_offset[refit$method])
refit$series <- refit$method
cbmb$y <- unname(profile_base[cbmb$design]) + unname(cbmb_offset[cbmb$fit_mode])
cbmb$series <- ifelse(cbmb$fit_mode == "Frozen", "Frozen fit", "Full refit")

f3_levels <- c("Huber-ST", "MB-ST", "CB-ST", "Frozen fit", "Full refit")
f3_colours <- c(
  `Huber-ST` = unname(okabe_ito["blue"]),
  `MB-ST` = unname(okabe_ito["vermillion"]),
  `CB-ST` = unname(okabe_ito["purple"]),
  `Frozen fit` = unname(okabe_ito["sky"]),
  `Full refit` = unname(okabe_ito["green"])
)
f3_shapes <- c(`Huber-ST` = 16, `MB-ST` = 17, `CB-ST` = 15, `Frozen fit` = 1, `Full refit` = 18)

f3_refit_levels <- c("Huber-ST", "MB-ST", "CB-ST")
f3_fit_levels <- c("Frozen fit", "Full refit")

y_profile_scale <- scale_y_continuous(
  breaks = c(3, 2, 1),
  labels = c("Primary", "Replication", "Recovery"),
  limits = c(0.55, 3.45),
  expand = c(0, 0)
)

p3a <- ggplot(refit, aes(y = y, colour = series, shape = series)) +
  geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.40) +
  geom_segment(aes(x = ci_low, xend = ci_high, yend = y), linewidth = 0.60) +
  geom_point(aes(x = estimate), size = 2.45, stroke = 0.55) +
  scale_colour_manual(values = f3_colours[f3_refit_levels], limits = f3_refit_levels, name = NULL) +
  scale_shape_manual(values = f3_shapes[f3_refit_levels], limits = f3_refit_levels, name = NULL) +
  y_profile_scale +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.04))) +
  labs(x = expression(Delta[refit]~"(MASE)"), y = NULL) +
  theme(legend.position = "bottom",
        legend.margin = margin(t = 1, unit = "pt"))

p3b <- ggplot(cbmb, aes(y = y, colour = series, shape = series)) +
  geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.40) +
  geom_segment(aes(x = ci_low, xend = ci_high, yend = y), linewidth = 0.60) +
  geom_point(aes(x = estimate), size = 2.45, stroke = 0.55) +
  scale_colour_manual(values = f3_colours[f3_fit_levels], limits = f3_fit_levels, name = NULL) +
  scale_shape_manual(values = f3_shapes[f3_fit_levels], limits = f3_fit_levels, name = NULL) +
  y_profile_scale +
  scale_x_continuous(expand = expansion(mult = c(0.04, 0.05))) +
  labs(x = "CB - MB MASE contrast", y = NULL) +
  theme(legend.position = "bottom",
        legend.margin = margin(t = 1, unit = "pt"))

fig3 <- (p3a | p3b) +
  plot_annotation(tag_levels = "a")

save_pub(fig3, "../../01_ENGLISH_CANONICAL/figures/figure3_refitting", width_mm, 74)
