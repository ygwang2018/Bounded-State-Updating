# Data index

Processed and redistributable analysis inputs remain in their validated locations.

- `../realtime/` — processed origin-consistent historical information sets and frozen release targets.
- `../controlled/` — frozen controlled-study registries and result inputs.
- `../figure_table_source_data/` — source data for manuscript figures/tables.
- `../w11_source_data/` — final table/Figure 4 source records.

Provider workbooks that are not redistributed are mapped in `../source_data_mapping.md` and `../realtime/README_INFORMATION_SET_CONSTRUCTION.md`.
