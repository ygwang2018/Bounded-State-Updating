# External code and provenance

Third-party code is not duplicated when it should be obtained from the official source.

- `../realtime/THIRD_PARTY_PROVENANCE.md` records the external Structural Theta / AutoTheta source and acquisition information.
- `../RECOVERED_CODE_PROVENANCE.md` records provenance for recovered project code included in this archive.
- `../README_TECHNICAL_DETAIL.md` records external benchmark interfaces and version notes.

These files use neutral source descriptions suitable for double-blind review.
