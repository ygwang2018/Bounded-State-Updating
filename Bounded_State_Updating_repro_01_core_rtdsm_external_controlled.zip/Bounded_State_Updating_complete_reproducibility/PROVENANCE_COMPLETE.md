# Provenance of the integrated reproducibility package

Source archive for the legacy validated components:

`IJF_anonymous_reproducibility_package_RST_O(1).zip`

The following directories were copied without modification from the archive root `IJF_ANONYMOUS_REPRODUCIBILITY_PACKAGE_RST_O_FINAL_20260913`:

- `method_code/`
- `controlled/`
- `M3/`
- `fitting_depth_code/`
- `realtime/`
- `R1_R2/`
- `figure_table_source_data/`
- `w11_scripts/`
- `w11_source_data/`
- `tables/`
- `external/`
- `environment/`
- `code/`
- `data/`
- `results/`

The following documentation/support files were likewise copied without modification:

- `README_TECHNICAL_DETAIL.md`
- `source_data_mapping.md`
- `RECOVERED_CODE_PROVENANCE.md`
- `smoke_fixed_context.R`

The new long-sample RTDSM extension is stored under:

`long_sample_rtdsm/`

That module was built from the original internal-method source code and the new July 1983--June 2025 information-set construction scripts. Its own `PROVENANCE.md`, `DATA_BUILD_PYTHON_AUDIT.txt`, and `SHA256SUMS.txt` document the extension.

No raw Philadelphia Fed workbook is embedded in this package. No third-party Sbrana--Silvestrini source file is embedded.
