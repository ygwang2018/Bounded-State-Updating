# Provenance of the integrated reproducibility package

The package combines the earlier validated reproducibility materials with the July 1983--June 2025 RTDSM extension used in the current JBES manuscript.

The following directories originate from the earlier validated package and retain their scientific data and estimator definitions:

- `method_code/`
- `controlled/`
- `M3/`
- `fitting_depth_code/`
- `realtime/`
- `R1_R2/`
- `figure_table_source_data/`
- `w11_scripts/`
- `w11_source_data/`
- `tables/`
- `external/`
- `environment/`
- `code/`
- `data/`
- `results/`

The current release applies only bounded portability and reproducibility repairs where required: package-relative M3 entry paths, long-sample validation/checkpoint safeguards, and public documentation cleanup. These repairs do not change the frozen estimator kernels or previously accepted M3/controlled/fitting-depth numerical records.

The July 1983--June 2025 RTDSM extension is stored under `long_sample_rtdsm/`. Its scripts reconstruct the 504-target-per-series balanced panel from the public Philadelphia Fed workbooks and validate the overlapping January 2018--June 2025 window against the frozen records before the long-sample results are used.

No raw Philadelphia Fed workbook is embedded in the distributed archives. No complete third-party Sbrana--Silvestrini source snapshot is embedded.
