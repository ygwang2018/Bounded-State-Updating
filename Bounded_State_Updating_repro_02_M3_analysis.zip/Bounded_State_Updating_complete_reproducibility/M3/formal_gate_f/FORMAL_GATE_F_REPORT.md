# Formal Gate F report

Completed: 2026-08-22 06:27:10.551554
Formal run executed exactly on the frozen M3 substrate/cells/method pool. No exploratory expansion was run.

Best bounded ST on PRIMARY_CORE MASE: CB; Delta_rel vs ROBETS = -0.027130 [-0.074988, 0.023300]; MEANINGFUL_ADVANTAGE
Best bounded ST on REPLICATION_CORE MASE: CB; Delta_rel vs ROBETS = -0.033944 [-0.070255, 0.003547]; MEANINGFUL_ADVANTAGE
New-method route stop rule triggered: FALSE

See aggregate, sign-pooled, bootstrap, and failure CSV files for complete frozen evidence.

STOP: no new cell, dataset, comparator, tuning, filtering, or manuscript change is executed by this runner.
