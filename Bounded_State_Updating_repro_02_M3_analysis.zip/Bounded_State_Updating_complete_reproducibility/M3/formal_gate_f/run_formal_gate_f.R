options(stringsAsFactors=FALSE, warn=1)
cmd0 <- commandArgs(trailingOnly = FALSE)
file_arg0 <- grep("^--file=", cmd0, value = TRUE)[1L]
script_dir0 <- dirname(normalizePath(sub("^--file=", "", file_arg0), mustWork = TRUE))
ROOT <- normalizePath(file.path(script_dir0, "..", ".."), mustWork = TRUE)
args0 <- commandArgs(trailingOnly = TRUE)
out_arg <- grep("^--output-dir=", args0, value = TRUE)
OUT <- if (length(out_arg)) sub("^--output-dir=", "", out_arg[1L]) else file.path(ROOT, "reproduced", "M3", "formal_gate_f")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
ADAPTER <- file.path(ROOT, "method_code", "gate_f_fitted_adapters.R")
AUTH <- file.path(ROOT, "fitting_depth_code", "modified")
RUNTIME <- file.path(ROOT, "method_code")
RAW <- file.path(OUT,'FORMAL_GATE_F_SERIES_METHOD_RESULTS.csv')
PROG <- file.path(OUT,'FORMAL_GATE_F_PROGRESS.txt')
for (rf in c('rst_o_config.R','rst_o_filters.R','rst_o_objectives.R','rst_o_optimizer.R','rst_o_fit.R','rst_o_forecast.R','rst_o_v1_7_revised_baselines.R')) {
  source(file.path(RUNTIME,'R',rf))
}
source(ADAPTER)
source(file.path(AUTH,'n1_method_adapters.R'))
hist_adapters <- n1_make_method_adapters(RUNTIME, file.path(AUTH,'stg_author_isolated.R'))
data('M3', package='Mcomp', envir=environment())
stopifnot(length(M3)==3003L, as.character(packageVersion('Mcomp'))=='2.8', as.character(packageVersion('robets'))=='1.4')
methods <- c('GAUSSIAN_ST','HUBER_ST','MB','CB','RESIDUAL_IQR_ST','ROBETS')
conds <- data.frame(condition=c('CLEAN','PRIMARY_CORE_NEG','PRIMARY_CORE_POS','REPLICATION_CORE_NEG','REPLICATION_CORE_POS','RECOVERY_BOUNDARY_NEG','RECOVERY_BOUNDARY_POS'),k=c(0,3,3,5,5,3,3),d=c(0,0,0,0,0,2,2),sign=c(0,-1,1,-1,1,-1,1))
fallback_fc <- function(y,h,f){ if(f>1L && length(y)>=2L*f) as.numeric(rep(tail(y,f),length.out=h)) else rep(tail(y,1),h) }
scale_den <- function(y,f){ lag <- if(f>1L) f else 1L; d <- y[(lag+1L):length(y)]-y[1L:(length(y)-lag)]; c(MASE=mean(abs(d)),RMSSE=sqrt(mean(d^2))) }
score <- function(actual,fc,den){ c(MASE=unname(mean(abs(actual-fc))/den['MASE']),RMSSE=unname(sqrt(mean((actual-fc)^2))/den['RMSSE'])) }
fitted_adapters <- gate_f_make_m3_fitted_adapters(n1_author_seasonal_bundle)
fit_new <- function(which,y,h,f){ ans <- fitted_adapters[[which]](y,h,f); list(forecast=as.numeric(ans$forecast),q=as.numeric(ans$fit$fit_inputs$q),omega=as.numeric(ans$fit$fit_inputs$omega),H=as.numeric(ans$fit$fit_inputs$H)) }
call_method <- function(m,y,h,f){ if(m=='GAUSSIAN_ST') return(hist_adapters$STG(y,h,f)); if(m=='RESIDUAL_IQR_ST') return(hist_adapters$IQR_ST(y,h,f)); if(m=='CB') return(hist_adapters$RSTO_NU5(y,h,f)); if(m=='ROBETS') return(hist_adapters$ROBETS(y,h,f)); fit_new(m,y,h,f) }
make_train <- function(clean,k,d,sgn){ if(k==0L) return(clean); sc <- max(sd(clean),IQR(clean,type=7)/1.349,1e-6,na.rm=TRUE); idx <- (length(clean)-d-k+1L):(length(clean)-d); z<-clean; z[idx]<-z[idx]+sgn*6*sc; z }
start_i <- 1L
if(file.exists(RAW)){ old <- read.csv(RAW); done <- unique(old$series_index); if(length(done)) start_i <- max(done)+1L }
if(start_i<=3003L) for(i in start_i:3003L){ s<-M3[[i]]; clean<-as.numeric(s$x); actual<-as.numeric(s$xx); h<-as.integer(s$h); f<-as.integer(frequency(s$x)); den<-scale_den(clean,f); rows<-vector('list',nrow(conds)*length(methods)); rr<-0L
 for(ci in seq_len(nrow(conds))){ cc<-conds[ci,]; y<-make_train(clean,cc$k,cc$d,cc$sign); for(m in methods){ rr<-rr+1L; t0<-proc.time()[3]; err<-NA_character_; fb<-FALSE; q<-omega<-H<-NA_real_; ans<-try(call_method(m,y,h,f),silent=TRUE); if(inherits(ans,'try-error') || is.null(ans$forecast) || length(ans$forecast)!=h || any(!is.finite(ans$forecast))){ err<-if(inherits(ans,'try-error')) as.character(ans) else 'NONFINITE_OR_WRONG_LENGTH_FORECAST'; fc<-fallback_fc(y,h,f); fb<-TRUE } else { fc<-as.numeric(ans$forecast); q<-if(!is.null(ans$q)) as.numeric(ans$q) else NA_real_; omega<-if(!is.null(ans$omega)) as.numeric(ans$omega) else NA_real_; H<-if(!is.null(ans$H)) as.numeric(ans$H) else NA_real_ }; met<-score(actual,fc,den); rows[[rr]]<-data.frame(series_index=i,series_name=as.character(s$sn),period=as.character(s$period),frequency=f,h=h,n_train=length(clean),condition=cc$condition,k=cc$k,d=cc$d,sign=cc$sign,method=m,MASE=met['MASE'],RMSSE=met['RMSSE'],success=!fb,fallback=fb,error=err,q_fit=q,omega_fit=omega,H_fit=H,runtime_sec=proc.time()[3]-t0) }}
 chunk<-do.call(rbind,rows); write.table(chunk,RAW,sep=',',row.names=FALSE,col.names=!file.exists(RAW),append=file.exists(RAW),qmethod='double',quote=TRUE); if(i%%10L==0L || i==3003L) writeLines(sprintf('completed_series=%d/3003 time=%s',i,Sys.time()),PROG) }
res <- read.csv(RAW, check.names=FALSE); stopifnot(length(unique(res$series_index))==3003L, nrow(res)==3003L*7L*6L)
agg <- aggregate(cbind(MASE,RMSSE)~condition+method,data=res,FUN=mean,na.rm=TRUE); write.csv(agg,file.path(OUT,'FORMAL_GATE_F_AGGREGATE_SUMMARY.csv'),row.names=FALSE)
fails <- aggregate(cbind(fallback=as.integer(res$fallback),success=as.integer(res$success))~condition+method,data=res,FUN=sum); write.csv(fails,file.path(OUT,'FORMAL_GATE_F_METHOD_FAILURES.csv'),row.names=FALSE)
set.seed(202607131); B<-5000L; bounded<-c('HUBER_ST','MB','CB'); conts<-c('PRIMARY_CORE_NEG','PRIMARY_CORE_POS','REPLICATION_CORE_NEG','REPLICATION_CORE_POS','RECOVERY_BOUNDARY_NEG','RECOVERY_BOUNDARY_POS','CLEAN')
boot_rows<-list(); br<-0L; for(cond in conts){ z<-res[res$condition==cond,]; for(m in bounded){ for(metric in c('MASE','RMSSE')){ a<-z[z$method==m,c('series_index',metric)]; r<-z[z$method=='ROBETS',c('series_index',metric)]; g<-z[z$method=='GAUSSIAN_ST',c('series_index',metric)]; names(a)[2]<-'a';names(r)[2]<-'r';names(g)[2]<-'g'; w<-Reduce(function(x,y) merge(x,y,by='series_index'),list(a,r,g)); n<-nrow(w); point_rel<-(mean(w$a)-mean(w$r))/mean(w$r); point_g<-mean(w$a)-mean(w$g); bv<-numeric(B); bg<-numeric(B); for(b in seq_len(B)){ ix<-sample.int(n,n,replace=TRUE); bv[b]<-(mean(w$a[ix])-mean(w$r[ix]))/mean(w$r[ix]); bg[b]<-mean(w$a[ix])-mean(w$g[ix]) }; br<-br+1L; boot_rows[[br]]<-data.frame(condition=cond,method=m,metric=metric,n=n,delta_rel_vs_ROBETS=point_rel,rel_ci_low=quantile(bv,.025,type=7),rel_ci_high=quantile(bv,.975,type=7),delta_abs_vs_Gaussian=point_g,gaussian_ci_low=quantile(bg,.025,type=7),gaussian_ci_high=quantile(bg,.975,type=7)) }}}
boot<-do.call(rbind,boot_rows); write.csv(boot,file.path(OUT,'FORMAL_GATE_F_BOOTSTRAP_CONTRASTS.csv'),row.names=FALSE)
pair_cells <- list(PRIMARY_CORE=c('PRIMARY_CORE_NEG','PRIMARY_CORE_POS'),REPLICATION_CORE=c('REPLICATION_CORE_NEG','REPLICATION_CORE_POS'),RECOVERY_BOUNDARY=c('RECOVERY_BOUNDARY_NEG','RECOVERY_BOUNDARY_POS'))
pair_rows<-list(); pr<-0L; for(nm in names(pair_cells)){ for(m in methods){ z<-res[res$condition%in%pair_cells[[nm]] & res$method==m,]; tmp<-aggregate(cbind(MASE,RMSSE)~series_index,data=z,FUN=mean); pr<-pr+1L; pair_rows[[pr]]<-data.frame(condition=nm,method=m,MASE=mean(tmp$MASE),RMSSE=mean(tmp$RMSSE)) }}; pairagg<-do.call(rbind,pair_rows); write.csv(pairagg,file.path(OUT,'FORMAL_GATE_F_SIGN_POOLED_SUMMARY.csv'),row.names=FALSE)
set.seed(202607131); pooled_boot<-list(); pb<-0L; for(nm in names(pair_cells)){ for(m in bounded){ z<-res[res$condition%in%pair_cells[[nm]],]; a<-aggregate(MASE~series_index,data=z[z$method==m,],FUN=mean); r<-aggregate(MASE~series_index,data=z[z$method=='ROBETS',],FUN=mean); g<-aggregate(MASE~series_index,data=z[z$method=='GAUSSIAN_ST',],FUN=mean); names(a)[2]<-'a';names(r)[2]<-'r';names(g)[2]<-'g'; w<-Reduce(function(x,y) merge(x,y,by='series_index'),list(a,r,g)); n<-nrow(w); v<-numeric(B); vg<-numeric(B); for(b in seq_len(B)){ix<-sample.int(n,n,TRUE);v[b]<-(mean(w$a[ix])-mean(w$r[ix]))/mean(w$r[ix]);vg[b]<-mean(w$a[ix])-mean(w$g[ix])}; pb<-pb+1L; pooled_boot[[pb]]<-data.frame(condition=nm,method=m,metric='MASE',n=n,delta_rel_vs_ROBETS=(mean(w$a)-mean(w$r))/mean(w$r),rel_ci_low=quantile(v,.025),rel_ci_high=quantile(v,.975),delta_abs_vs_Gaussian=mean(w$a)-mean(w$g),gaussian_ci_low=quantile(vg,.025),gaussian_ci_high=quantile(vg,.975)) }}; pboot<-do.call(rbind,pooled_boot); write.csv(pboot,file.path(OUT,'FORMAL_GATE_F_SIGN_POOLED_BOOTSTRAP.csv'),row.names=FALSE)
best_primary <- pboot[pboot$condition=='PRIMARY_CORE',][which.min(pboot[pboot$condition=='PRIMARY_CORE','delta_rel_vs_ROBETS']),]; best_rep <- pboot[pboot$condition=='REPLICATION_CORE',][which.min(pboot[pboot$condition=='REPLICATION_CORE','delta_rel_vs_ROBETS']),]
classify <- function(x) if(x < -0.02) 'MEANINGFUL_ADVANTAGE' else if(x > 0.02) 'MEANINGFUL_DISADVANTAGE' else 'PRACTICAL_EQUIVALENCE'
stop_route <- isTRUE(best_primary$rel_ci_low>0.02 && best_rep$rel_ci_low>0.02)
report <- c('# Formal Gate F report','',sprintf('Completed: %s',Sys.time()),'Formal run executed exactly on the frozen M3 substrate/cells/method pool. No exploratory expansion was run.','',sprintf('Best bounded ST on PRIMARY_CORE MASE: %s; Delta_rel vs ROBETS = %.6f [%.6f, %.6f]; %s',best_primary$method,best_primary$delta_rel_vs_ROBETS,best_primary$rel_ci_low,best_primary$rel_ci_high,classify(best_primary$delta_rel_vs_ROBETS)),sprintf('Best bounded ST on REPLICATION_CORE MASE: %s; Delta_rel vs ROBETS = %.6f [%.6f, %.6f]; %s',best_rep$method,best_rep$delta_rel_vs_ROBETS,best_rep$rel_ci_low,best_rep$rel_ci_high,classify(best_rep$delta_rel_vs_ROBETS)),sprintf('New-method route stop rule triggered: %s',stop_route),'','See aggregate, sign-pooled, bootstrap, and failure CSV files for complete frozen evidence.','','STOP: no new cell, dataset, comparator, tuning, filtering, or manuscript change is executed by this runner.')
writeLines(report,file.path(OUT,'FORMAL_GATE_F_REPORT.md')); writeLines(sprintf('completed_series=3003/3003 finalized=%s STOP=TRUE',Sys.time()),PROG)
