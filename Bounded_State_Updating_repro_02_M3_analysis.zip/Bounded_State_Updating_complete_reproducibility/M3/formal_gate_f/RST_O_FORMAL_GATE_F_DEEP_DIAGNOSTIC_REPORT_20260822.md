# Formal Gate F 深度结果诊断报告

**项目：** RST-O / Formal Gate F  
**日期：** 2026-08-22  
**证据范围：** 已完成 Formal Gate F；M3 3,003 条序列；126,126 条正式结果。  
**诊断性质：** 只分析既有正式结果，不新增实验、不调参、不筛选序列、不改变冻结设计。

---

## 1. 诊断结论

> **CB/MB 在 M3 中形成覆盖多数序列的明显收益区，同时伴随高度集中的不利尾部。Primary 和 Replication 的不利尾部主要集中在 Yearly；Recovery-boundary 的异常右尾主要集中在 Quarterly，并由 negative contamination 显著放大。**

CB 在 Primary 上有 69.03% 的序列优于 ROBETS，中位改善 43.35%；Replication 胜率 55.24%；Recovery-boundary 胜率 71.83%。这些结果排除‘总体均值优势只由极少数幸运序列制造’的解释。

Primary 的 CB 逐序列相对差 95% 分位为 +372%，99% 分位为 +931%。长右尾使 aggregate mean 与 paired bootstrap 对少数高损失序列敏感。

M3 类型分层：Primary 中 CB 在 Monthly 胜率 87.0%、Other 99.4%，Yearly 30.2%。Replication 中 Monthly 76.7%、Other 94.8%，Yearly 与 Quarterly 转为不利。

训练长度与 CB 相对损失显著负相关：Primary Spearman=-0.700，Replication=-0.648。Primary 内 Yearly/Quarterly/Monthly 分别为 -0.559/-0.471/-0.448。固定 k 下 n_train 与 k/n 共线，当前结果不能把历史长度与相对污染比例分离。

RMSSE 重复胜率和中位数结构，但 aggregate mean 优势减弱：CB Primary=-0.04%，Replication=+0.81%，Recovery=-3.57%。平方损失进一步暴露 catastrophic tail。

Negative contamination 有明显符号不对称。CB 的 aggregate mean MASE：Primary negative=+9.36%、positive=-13.86%；Replication +11.51% / -16.99%；Recovery -3.2% / -31.6%。

Quarterly-negative 中新发生的非正域跨越与失利高度相关。Primary-negative Quarterly：crossing 胜率 26.4%、中位 +53.5%；non-crossing 胜率 55.2%、中位 -9.0%。Recovery-negative Quarterly：crossing 胜率 22.2%、中位 +100.7%；non-crossing 58.1%、中位 -14.8%。

六种方法 fallback 均为 0，结果结构不是代码失败或 fallback 造成。

---

## 2. CB 与 MB 的总体分布

| Cell | 方法 | 胜率 | 中位相对差 | 25%分位 | 75%分位 | 95%分位 | 99%分位 | aggregate mean MASE相对差 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Primary | MB | 72.19% | -51.98% | -78.20% | +11.04% | +393.91% | +1020.72% | -1.04% |
| Primary | CB | 69.03% | -43.35% | -74.65% | +22.53% | +372.03% | +930.60% | -2.71% |
| Replication | MB | 54.98% | -11.30% | -76.75% | +39.44% | +333.31% | +851.21% | +3.07% |
| Replication | CB | 55.24% | -9.90% | -61.76% | +31.88% | +300.95% | +849.20% | -3.39% |
| Recovery boundary | MB | 69.86% | -24.76% | -50.67% | +9.24% | +155.49% | +462.62% | -13.25% |
| Recovery boundary | CB | 71.83% | -27.56% | -53.58% | +5.60% | +149.12% | +477.81% | -16.58% |

Primary 是‘多数明显获益 + 少数严重失利’。Replication 提高到 k=5 后覆盖率下降到约 55%，CB 仍保持负 aggregate mean，MB 转正。Recovery-boundary 的总体优势更完整，但 Quarterly-negative 有异常尾部。

---

## 3. M3 类型异质性

| Cell | 类型 | n | CB胜率 | 中位相对差 | aggregate mean相对差 |
|---|---|---:|---:|---:|---:|
| Primary | Yearly | 645 | 30.2% | +57.6% | +77.6% |
| Primary | Quarterly | 756 | 61.2% | -18.0% | -12.3% |
| Primary | Monthly | 1428 | 87.0% | -68.8% | -64.8% |
| Primary | Other | 174 | 99.4% | -75.4% | -71.9% |
| Replication | Yearly | 645 | 21.1% | +25.7% | +48.1% |
| Replication | Quarterly | 756 | 34.8% | +15.4% | +19.8% |
| Replication | Monthly | 1428 | 76.7% | -50.1% | -43.8% |
| Replication | Other | 174 | 94.8% | -80.6% | -75.5% |
| Recovery boundary | Yearly | 645 | 67.6% | -23.1% | -31.2% |
| Recovery boundary | Quarterly | 756 | 54.4% | -7.1% | +45.9% |
| Recovery boundary | Monthly | 1428 | 81.7% | -34.6% | -34.0% |
| Recovery boundary | Other | 174 | 82.8% | -48.0% | -47.5% |

训练长度分布：Yearly 中位 n=19，Quarterly=44，Monthly=115，Other=63。Primary 中长度与 CB 相对损失在 period 内仍负相关，说明类别标签不能完整解释优势；history length / k:n ratio 是直接候选机制。

---

## 4. RMSSE 诊断

CB RMSSE 在 M3 类型上的方向与 MASE 基本一致：Primary Yearly +81.3%、Quarterly -9.6%、Monthly -62.4%、Other -71.4%；Replication Yearly +49.5%、Quarterly +21.0%、Monthly -34.7%、Other -75.9%；Recovery Yearly -29.5%、Quarterly +86.1%、Monthly -26.6%、Other -44.9%。

全 M3 聚合：CB RMSSE Primary=-0.04%、Replication=+0.81%、Recovery=-3.57%。MASE 对应 -2.71%、-3.39%、-16.58%。同一异质性在两种指标上都存在；RMSSE 表明大误差尾部尚未被稳定控制。

---

## 5. 符号不对称与 domain crossing

CB aggregate mean MASE：Primary negative +9.36%、positive -13.86%；Replication negative +11.51%、positive -16.99%；Recovery negative -3.2%、positive -31.6%。Quarterly 是主要符号不对称来源。

负污染使原本全正序列新跨入非正域的比例约 61%–63%。Quarterly 中约 52%–56%。ROBETS canonical adapter 在训练样本含非正值时切换 additive.only=TRUE。该模型域变化与 Quarterly-negative 的结果恶化强关联。

Primary-negative Quarterly：crossing 胜率 26.4%、中位 +53.5%；non-crossing 胜率 55.2%、中位 -9.0%。Recovery-negative Quarterly：crossing 22.2%、中位 +100.7%；non-crossing 58.1%、中位 -14.8%。

Yearly crossing/non-crossing 两组都偏差，说明 domain crossing 不是 Yearly 失利的完整解释。

---

## 6. 极端右尾集中

Primary CB 最差 1% positive-loss series 100% 来自 Yearly；最差 5% 中 97.4% 来自 Yearly。Replication 最差 1% 中 90.3% Yearly，最差 5% 中 92.1% Yearly。Recovery 最差 1% 中 93.5% Quarterly，最差 5% 中 69.5% Quarterly、25.8% Yearly。

Recovery-negative Quarterly 不是单个 outlier 造成：61.6% 序列上 CB 更差。最差 1% 占 positive-loss mass 的 41.7%，最差 5% 占 59.2%。完整 aggregate mean=+127.6%；描述性去掉最差 1% 后仍 +53.2%，去掉最差 5% 后仍 +22.3%。

最极端序列 N0885：CB MASE=928.25、ROBETS=1.61，占该组 positive-loss mass 的 32.8%；移除这一条后 aggregate mean 仍 +75.3%。该组属于‘广泛失利 + 极端尾部放大’，不能解释成纯异常值。

---

## 7. fitted 参数诊断

Formal raw 保存了 Huber-ST 与 MB 的 q_fit、omega_fit、H_fit；历史 CB adapter 没有把数值参数写入正式结果，CB 参数为 NA。不能用 MB 参数替代推断 CB。

MB 与同一 series 的 clean fit 对齐后：Primary Yearly LOSS 的 H ratio 中位数 24.56x，WIN 1.82x；Primary Quarterly LOSS 20.55x，WIN 6.90x。Replication Yearly LOSS 21.86x、WIN 9.17x；Quarterly LOSS 46.49x、WIN 14.03x。Recovery Quarterly LOSS 的 H ratio 达到 196.01x，WIN 18.61x。

Yearly 中 q 近上界在胜负两组都很常见，q saturation 本身不能解释胜负；H inflation 与失利的区分更强。Monthly 的 H 基本接近 clean scale，优势序列没有相同的 scale inflation。

> **候选机制：短历史及特定 negative/Quarterly 条件下，robust fitted objective 可能把污染冲击吸收到 working observation scale H 中，形成过度 scale inflation；有界 state update 不能阻止完整 fitted parameter adaptation 发生大幅偏移。**

该机制证据目前直接来自 MB。CB 没有记录数值 fitted parameters，尚不能宣称 CB 已被同一参数机制解释。

---

## 8. Clean 条件

Clean M3 上没有明显 robustification penalty：Huber-ST MASE=-0.8%、RMSSE=-1.5%；MB MASE=+0.2%、RMSSE=-0.8%；CB MASE=-1.4%、RMSSE=-2.1%（均相对 ROBETS aggregate mean）。

CB 的污染异质性不是简单的 clean-vs-robustness trade-off。

---

## 9. 机制判断

1. boundedness 不是充分解释：Huber-ST 同样 bounded，但 Primary/Replication aggregate MASE 比 ROBETS 高 61.46%/63.43%。更新权重、working-P recursion、fitted objective 与参数适应路径共同决定结果。
2. 优势区与长历史/较低相对污染比例高度相关，但 n_train 与 k/n 在冻结设计中共线，不能直接做因果归因。
3. negative domain crossing 是 Quarterly-negative 的强替代解释；它是 complete fitted systems 在相同污染样本上的真实模型响应差异，不是实现错误。
4. Recovery-boundary 不应再简单当作 Gate M fixed-state memory 的单调衰减。Gate F 含参数重估、季节预处理与 comparator model selection，两个阶段不是同一 estimand。

---

## 10. 对论文主线的影响

> **Bounded Structural Theta 的收益是结构化而非均匀的：在 M3 的长历史 Monthly/Other 序列和多数 Primary series 中，CB/MB 对 forecast-origin contamination 提供广泛而大的保护；短历史 Yearly 和 negative Quarterly 条件暴露 fitted adaptation cost 与重尾风险。CB 在完整 fitted system 中比 MB 和 Huber-ST 更稳定，并在 clean data 上没有明显代价。**

这条主线比‘整个 M3 上统一显著击败 ROBETS’更符合 Formal Gate F 的完整证据。

---

## 11. 是否需要新的最小判别实验

当前不扩大 benchmark，不搜索新 cell。最强替代解释已压缩为两个：negative-domain crossing 是否解释 Quarterly 主要失利；短训练历史/高 k:n 是否解释 Yearly 主要失利。

若 T33 要求因果层面的机制识别，最有信息价值的候选是：A. 不跨零的 negative contamination 对照，用于判别 domain-crossing；B. 受控分离 n_train 与 k/n，用于判别 history-length 与 contamination-fraction。两者都应先由 T33 冻结，不应直接执行。

CB fitted parameter logging 可作为诊断补充，只记录既有 frozen cells，不重新搜索 performance。

---

## 12. 最终诊断

> **优势不是偶然平均，也不是全局均匀。CB 在大多数 Primary series 上获益，Monthly/Other 上优势非常强；总体不确定性主要由明确的数据区域产生。Primary/Replication 的风险尾部集中于 Yearly，Recovery 的风险尾部集中于 Quarterly-negative。训练长度、negative-domain crossing 和 fitted scale inflation 是当前最有证据支持的三个解释轴。**
