# RST-O Fitted-Layer Decomposition 最终机制分解报告

**日期：2026-08-23**  
**执行来源：** T33 → Code23 `Fitted-Layer Decomposition` 最终机制判别任务  
**任务性质：** 最后一次机制分解；不是新 benchmark，不是新 contamination search  
**正式输出目录：** `M3/fitted_layer/`  
**主指标：** MASE  
**次指标：** RMSSE  
**推断单位：** series-level paired bootstrap，`B=5000`，percentile 95% CI，seed `202607131`

---

## 1. 结论先行

本轮分解对当前论文主线给出了清晰且具有机制含义的裁决：

> **Formal Gate F 中观察到的完整系统行为不能只归因于 local robust state-writing。结果支持一个两层机制：第一层是污染观测如何写入 state / working-P 的局部 dynamics；第二层是污染训练样本如何改变 fitted parameters 与完整系统 adaptation。后者在多个关键场景中产生显著 adaptation cost，并可抵消甚至反转第一层的局部保护。**

六项直接裁决如下。

1. **Huber full-fit failure 主要来自 fitted layer。**  
   Huber 在 clean-fit / frozen-adaptation 下恢复出明显保护；允许 contaminated sample 重新估计 fitted quantities 后，MASE 显著上升。Primary、Replication、Recovery 的 `A_fit=L_full-L_frozen` 分别为 **+9.500、+17.671、+1.117**，95% CI 全部严格大于 0。Huber 的局部 bounded mean update 因而不是完整系统恶化的主要来源；污染驱动的参数重新适应是关键放大器。

2. **CB 相对 MB 的增量不是单一来源。**  
   在 Primary 和 Replication 中，clean-fit frozen 条件下 CB 平均反而略差于 MB；两者的 full-refit 排序改善主要来自 **CB 的 fitted adaptation cost 小于 MB**。但在 Recovery Boundary 中，CB 在 frozen 条件下已经稳定优于 MB，说明 **working-P coupling 的局部增量真实存在，但其优势主要集中在允许状态恢复的场景，而不是所有 terminal-contamination 场景。**

3. **Yearly failure 是“局部困难 + fitted layer 强放大”，不是单纯 local recursion failure。**  
   Yearly 的 frozen losses 本身已经高于 Monthly/Other，但 full refit 额外加入了很大的 adaptation cost。Primary Yearly 的 Huber/MB/CB `A_fit` 为 **+23.006 / +19.493 / +17.327**；Replication Yearly为 **+26.758 / +27.191 / +22.305**。因此 Yearly 的主要恶化不能再归因于 `rho=k/n`，也不能只归因于 bounded update 本身。

4. **Recovery Boundary 的改善与 local recovery dynamics 一致。**  
   从 Primary `d=0` 移到 Recovery `d=2` 后，Huber、MB、CB 在 frozen layer 已分别平均改善 MASE **0.579、0.302、0.508**。这说明 recovery advantage 在 local state/covariance dynamics 中已经存在。Full refit 下差异进一步扩大，主要因为 terminal contamination 的 fitted adaptation cost 更严重，而不是因为 recovery 仅靠重新拟合产生。

5. **Quarterly-negative domain crossing 的灾难主要由 fitted adaptation 放大。**  
   Recovery-negative Quarterly 中，crossing series 的 CB frozen MASE 约 **1.250**，full-refit MASE 升至 **8.418**，`A_fit≈+7.169`；non-crossing 对应约 **1.037 → 1.566**，`A_fit≈+0.529`。MB、Huber呈同方向结构。此前的 crossing failure 因而不能解释为“局部 bounded state-writing 一跨零就崩溃”；更准确的机制是 **domain interaction 与 fitted adaptation 的耦合放大**。

6. **当前论文主线不需要推翻，但机制归因必须重写。**  
   `protection–adaptation boundary` 得到直接支持。需要修正的是过去可能把 CB/MB/Huber 的完整系统表现过多归于 local robust update 的解释。论文应明确区分 **local state-writing protection** 与 **complete fitted adaptation cost**；尤其不能把 Primary/Replication 中 CB 相对 MB 的 full-refit 优势全部写成 working-P coupling 的直接收益。

本轮结果没有触发新的 forecasting / contamination experiment。按 T33 冻结规则，本轮之后应停止新增实验，回交 T33 做理论重构与论文重建裁决。

---

## 2. 执行闭合与实现一致性

### 2.1 正式任务状态

正式进程：

- 启动：2026-08-22 21:37:07
- 完成：2026-08-22 22:51:17
- 总运行时间约 1 小时 14 分
- `completed_series=3003/3003`
- process `exit_code=0`
- stdout/stderr 无错误
- `STOP=TRUE`

正式输出已生成：

1. `FITTED_LAYER_DECOMPOSITION_SERIES_RESULTS.csv`
2. `FITTED_LAYER_DECOMPOSITION_SUMMARY.csv`
3. `FITTED_LAYER_DECOMPOSITION_BOOTSTRAP.csv`
4. `FITTED_LAYER_PARAMETER_DIAGNOSTICS.csv`
5. `run_fitted_layer_decomposition.R`
6. 本报告 `FITTED_LAYER_DECOMPOSITION_REPORT.md`

### 2.2 Mode A / Mode B 定义

**Mode A：Clean-fit / Frozen-adaptation**

每条 M3 series、每种 Structural Theta family 方法只在 clean training series 上完成一次完整 fit。seasonal preprocessing/factors、`omega`、`q`、`H` 与方法固定 hyperparameters 均被冻结。随后对六个正式 contamination variants 只重新执行 sequential state / working-P recursion，不允许 contaminated sample 重新估计 fitted quantities。

**Mode B：Full refit**

没有重新运行。直接复用 Formal Gate F 的正式 full-refit series losses，与 Mode A 逐 series / condition / sign / method 精确合并。

核心 estimand：

\[
A_{\mathrm{fit}} = L_{\mathrm{full}} - L_{\mathrm{frozen}}.
\]

- `A_fit > 0`：污染进入 fitted layer 后进一步增加预测损失；
- `A_fit < 0`：重新拟合吸收了部分污染效应；
- `A_fit ≈ 0`：局部 recursion 已解释大部分完整系统效应。

### 2.3 Gaussian canonical identity 修复

正式运行前发现一个必须处理的实现一致性问题：

Formal Gate F 的 `GAUSSIAN_ST` 使用 `stg_author_isolated.R` 中的 canonical M3 wrapper，其 nonseasonal optimizer 起点为：

`optim(c(.01, 1), likelihood)`

而 runtime 中另一个 author kernel 使用：

`optim(c(.01, .001), ...)`

初始 parity 检查因此出现约 `0.001–0.003` 的 MASE 差异。正式运行前已改为与 Gate F 完全一致的 isolated author semantics，并保留 author Gaussian q 的原始无界行为。

修复后四个代表性 period series 的 clean MASE 与 Formal Gate F 达到浮点精度一致；随后执行 4 个 period 代表序列 × 6 个 contamination cells × 4 个方法，共 96 次 Mode A contaminated smoke，**96/96 成功，无失败**。

因此本轮分解没有将 implementation drift 混入 fitted-layer estimand。

---

## 3. Overall 分解结果

下表为 sign-pooled MASE。`A_fit` 是 full refit 相对 frozen adaptation 的平均增量。

| Cell | Method | Frozen MASE | Full MASE | A_fit mean | A_fit > 0 |
|---|---|---:|---:|---:|---:|
| Primary | Gaussian ST | 18.200 | 21.330 | +3.130 | 97.5% |
| Primary | Huber ST | 2.513 | 12.014 | **+9.500** | 99.6% |
| Primary | MB | 1.949 | 7.363 | **+5.414** | 86.6% |
| Primary | CB | 2.026 | 7.239 | **+5.213** | 92.5% |
| Replication | Gaussian ST | 18.770 | 21.379 | +2.609 | 94.0% |
| Replication | Huber ST | 3.480 | 21.151 | **+17.671** | 100.0% |
| Replication | MB | 2.221 | 13.340 | **+11.119** | 92.6% |
| Replication | CB | 2.653 | 12.503 | **+9.849** | 98.0% |
| Recovery | Gaussian ST | 2.170 | 3.184 | +1.013 | 61.5% |
| Recovery | Huber ST | 1.935 | 3.051 | **+1.117** | 80.2% |
| Recovery | MB | 1.647 | 2.307 | **+0.660** | 69.8% |
| Recovery | CB | 1.518 | 2.219 | **+0.701** | 71.9% |

关键 `A_fit` 的 95% bootstrap CI：

| Cell | Huber ST | MB | CB |
|---|---:|---:|---:|
| Primary | +9.500 [9.084, 9.912] | +5.414 [5.021, 5.805] | +5.213 [4.867, 5.557] |
| Replication | +17.671 [16.870, 18.494] | +11.119 [10.609, 11.653] | +9.849 [9.399, 10.312] |
| Recovery | +1.117 [0.891, 1.495] | +0.660 [0.449, 1.018] | +0.701 [0.493, 1.055] |

RMSSE 与 MASE 给出同方向分解，因此以下科学裁决以 MASE 为主，不依靠单一 metric。

---

## 4. Q1 — Huber paradox：恶化主要来自哪一层？

### 4.1 Frozen Huber 恢复出明显 local protection

Primary：

- Gaussian frozen MASE = 18.200
- Huber frozen MASE = 2.513
- paired difference `Huber - Gaussian = -15.686`
- 95% CI `[-16.459, -14.911]`

Replication：

- Gaussian frozen = 18.770
- Huber frozen = 3.480
- difference = **-15.290**
- 95% CI `[-16.051, -14.533]`

因此 terminal contamination 下，clean-fitted Huber sequential update 保留了很强的 bounded-writing protection。

Recovery overall 中，Huber frozen 相对 Gaussian 的优势较小但仍存在：

- difference ≈ **-0.236**
- 95% CI 约 `[-0.337, -0.147]`

需要保留一个重要例外：Recovery Yearly 中 Huber frozen 仍比 Gaussian frozen差约 **+1.061**。所以“Huber local protection”不是所有 period / recovery 情形都占优；Yearly 存在独立的 local difficulty。

### 4.2 Full refit 是主要 deterioration source

Huber `A_fit`：

- Primary overall：**+9.500**
- Replication overall：**+17.671**
- Recovery overall：**+1.117**

Yearly 更突出：

- Primary Yearly：**+23.006** [21.910, 24.182]
- Replication Yearly：**+26.758** [25.283, 28.239]
- Recovery Yearly：**+1.519** [1.302, 1.741]

因此 Huber complete-system failure 不能归因于 `c_H=1.345` 的 bounded mean update 本身。污染训练样本重新进入 fitted objective / parameter estimation 后产生的大幅 adaptation cost 才是主要放大机制。

### 4.3 Q1 裁决

**支持。**

更准确的表述应为：

> Huber 的 controlled/local robustness 可以迁移到 fitted M3 setting 的 state-writing 层，但不能自动迁移到 complete fitted system；污染对 fitted parameters 的再估计可系统性侵蚀 local protection。

这比“Huber 本身失败”或“bounded update 不适用于 M3”都更符合本轮直接证据。

---

## 5. Q2 — CB vs MB：working-P coupling 还是 refitting？

CB 与 MB 的 paired contrast 定义为：

\[
\Delta_{\mathrm{CB-MB}} = L_{\mathrm{CB}} - L_{\mathrm{MB}}.
\]

负值表示 CB 更好。

### 5.1 Overall

| Cell | Frozen CB−MB | 95% CI | Full CB−MB | 95% CI | A_fit(CB)−A_fit(MB) |
|---|---:|---:|---:|---:|---:|
| Primary | +0.077 | [0.062, 0.091] | -0.124 | [-0.191, -0.059] | -0.201 |
| Replication | +0.432 | [0.399, 0.468] | -0.837 | [-1.049, -0.637] | -1.269 |
| Recovery | **-0.129** | [-0.145, -0.114] | **-0.088** | [-0.115, -0.062] | +0.041 |

Primary 和 Replication 中，frozen layer 下 CB 略差于 MB；full layer 下排序反转，主要原因是 CB 的 fitted adaptation cost 小于 MB。

所以这些 terminal-contamination cells 中，不能把 CB 的 full-system relative advantage 直接写成 working-P coupling 的纯 local benefit。

### 5.2 Period structure

Primary Yearly：

- Frozen CB−MB = **+0.296**
- Full CB−MB = **-1.870**
- `A_fit` differential = **-2.166**

Replication Yearly：

- Frozen = **+1.136**
- Full = **-3.750**
- `A_fit` differential = **-4.886**

这两个 Yearly reversal 特别清楚：CB 的相对优势主要由 fitted layer 的较低恶化产生。

Recovery 则不同：

- Recovery Yearly frozen CB−MB = **-0.272**
- Recovery Quarterly frozen CB−MB = **-0.110**
- 两者 CI 均严格小于 0

因此 Recovery Boundary 下 working-P coupling 已经在 frozen state/covariance dynamics 中形成增量。

### 5.3 Q2 裁决

**部分支持 local coupling，且存在 cell-specific mechanism。**

最合适的机制表述是：

> CB 的 working-P coupling 在 recovery dynamics 中有可识别的局部增量；但 Primary/Replication 中 CB 相对 MB 的 complete-system优势主要来自 fitted adaptation differential，而不是 local coupling alone。

---

## 6. Q3 — Yearly failure：local recursion 还是 full refit？

### 6.1 Frozen layer 已存在 Yearly difficulty

Primary frozen MASE：

- Huber：4.992
- MB：4.076
- CB：4.372

Replication frozen：

- Huber：6.743
- MB：4.688
- CB：5.823

这些数值明显高于 Monthly frozen。

Primary Monthly：

- Huber 1.276
- MB 0.973
- CB 0.989

Replication Monthly：

- Huber 1.747
- MB 1.074
- CB 1.247

因此 Yearly 并非完全由 refitting “创造”出来；局部 recursion / short low-frequency setting 本身已经更困难。

### 6.2 Full refit 产生主要放大

Yearly `A_fit`：

| Cell | Huber | MB | CB |
|---|---:|---:|---:|
| Primary | **+23.006** | **+19.493** | **+17.327** |
| Replication | **+26.758** | **+27.191** | **+22.305** |
| Recovery | +1.519 | +0.437 | +0.420 |

Primary 与 Replication 的 full losses 因而达到：

Primary Yearly：

- Huber 27.998
- MB 23.569
- CB 21.699

Replication Yearly：

- Huber 33.502
- MB 31.879
- CB 28.128

Yearly terminal failure 的数量级主要来自 fitted layer 放大。

### 6.3 与 D1-A 的关系

D1-A 已不支持简单的“`rho=k/n` 越大 → adaptation 越坏”的统一解释。本轮也没有重新引入该解释。

当前证据只支持更精确的说法：

> Yearly 构成一个局部难度更高的 low-frequency regime；污染训练样本上的 complete refit 又大幅放大该局部困难。其来源不能压缩成单一 exposure ratio。

### 6.4 Q3 裁决

**Yearly failure 属于双层叠加，但 fitted layer 是主要放大器。**

---

## 7. Q4 — Recovery Boundary：改善从哪里产生？

### 7.1 Recovery improvement 在 frozen layer 已经存在

定义 Recovery − Primary 的 paired MASE contrast。负值代表 `d=2` Recovery 更好。

Frozen：

- Huber：**-0.579** [−0.605, −0.552]
- MB：**-0.302** [−0.327, −0.279]
- CB：**-0.508** [−0.541, −0.476]

因此，只允许污染进入 sequential state/working-P recursion、完全冻结 fitted layer 时，两个 clean observations 的恢复距离已经显著改善 Huber/MB/CB。

这直接连接了 controlled recovery dynamics 与 M3 fitted decomposition：Recovery Boundary 的核心现象并不依赖 contaminated refitting 才出现。

### 7.2 Full refit 扩大 Recovery-vs-Primary 差异

Full Recovery − Primary：

- Huber：**-8.962**
- MB：**-5.056**
- CB：**-5.020**

这个更大的差距不应解释成“full refit 帮助 recovery”。从 `A_fit` 看，Primary 的 refit cost 明显大于 Recovery：

- Huber：Primary +9.500 vs Recovery +1.117
- MB：Primary +5.414 vs Recovery +0.660
- CB：Primary +5.213 vs Recovery +0.701

所以 full difference 的扩大主要来自 **terminal contamination 下 refitting 更有害**。

### 7.3 CB coupling 与 Recovery

Recovery frozen：

- MB = 1.647
- CB = 1.518
- CB−MB = **-0.129** [−0.145, −0.114]

这一结果尤其重要，因为它说明 Recovery Boundary 中 CB 的优势不是 full-refit 排序的副产物；coupled working-P dynamics 在 fitted quantities 固定时已经产生额外恢复收益。

### 7.4 Q4 裁决

**支持 local recovery mechanism。**

Recovery Boundary 可以被解释为：

> bounded state-writing 先限制 contamination 对 state 的写入；随后 clean observations 在固定 fitted system 中允许 state / working-P 重新回到正常轨道。complete refitting 并非 recovery benefit 的必要条件。

---

## 8. Quarterly-negative domain crossing 复核

D1-B 已指出 negative contamination 导致的 domain crossing 是 Quarterly 的重要 amplifier。本轮分解进一步定位了它主要作用在哪一层。

### 8.1 Primary-negative Quarterly

CB：

- crossing frozen = 1.718
- crossing full = 10.511
- crossing `A_fit` = **+8.793**

non-crossing：

- frozen = 1.459
- full = 6.185
- `A_fit` = **+4.727**

MB：

- crossing `A_fit` ≈ +7.800
- non-crossing ≈ +4.254

Huber：

- crossing ≈ +12.036
- non-crossing ≈ +9.512

### 8.2 Replication-negative Quarterly

CB：

- crossing `A_fit` ≈ **+16.973**
- non-crossing ≈ **+14.137**

MB：

- crossing ≈ +18.831
- non-crossing ≈ +15.669

Huber：

- crossing ≈ +18.633
- non-crossing ≈ +15.273

### 8.3 Recovery-negative Quarterly

最具有识别力的是 Recovery。

CB crossing：

- Frozen = **1.250**
- Full = **8.418**
- `A_fit = +7.169`

CB non-crossing：

- Frozen = **1.037**
- Full = **1.566**
- `A_fit = +0.529`

MB crossing：

- `A_fit ≈ +7.102`

MB non-crossing：

- `A_fit ≈ +0.475`

Huber crossing：

- `A_fit ≈ +7.224`

Huber non-crossing：

- `A_fit ≈ +0.838`

因此 crossing interaction 在 Recovery 中几乎完整表现为 fitted-layer amplification。

### 8.4 机制裁决

不能再把 Quarterly negative crossing 描述成“鲁棒局部 update 在跨过零后失效”。

本轮更支持：

> domain crossing 改变了 contaminated fitted sample 的估计几何，使 complete fitting 对污染产生更激进的 adaptation；局部 bounded recursion 本身在 frozen fit 下仍保持相对稳定。

---

## 9. Fitted parameter diagnostics

### 9.1 Huber / MB 的 H inflation

对可从 Formal Gate F raw 直接恢复 full-refit 参数的 Huber 与 MB，比较：

\[
H_{\mathrm{full}} / H_{\mathrm{clean}}.
\]

Huber 中位数：

| Cell | Yearly | Quarterly |
|---|---:|---:|
| Primary | 13.55× | 15.25× |
| Replication | 17.33× | 24.05× |
| Recovery | 47.75× | 88.25× |

Huber 90% 分位尤其大：

- Primary Quarterly：约 206×
- Replication Quarterly：约 412×
- Recovery Quarterly：约 1478×

MB 也存在显著 inflation：

| Cell | Yearly | Quarterly |
|---|---:|---:|
| Primary | 8.33× | 4.12× |
| Replication | 18.32× | 19.12× |
| Recovery | 18.77× | 18.58× |

Recovery Quarterly 的 MB 90% 分位约 668×。

这些参数变化与 `A_fit>0` 的系统性恶化方向一致，说明 fitted scale / variance structure 对 contaminated sample 的重新适应很可能是 adaptation cost 的重要载体。

但本轮 decomposition 识别的是 **layer effect**，并未单独识别 `H` 对损失的因果贡献。因此正文不应把“H inflation”写成唯一机制；它应作为 fitted-adaptation interpretation 的参数证据。

### 9.2 CB parameter logging blocker

Clean-fit CB 的：

- `q_fit`
- `omega_fit`
- `H_fit`
- optimizer status
- objective

均已记录。

但 existing Formal Gate F raw 没有持久化 contaminated full-refit CB parameters，而 T33 明确禁止重新运行 Mode B。因此本轮按 protocol 记录：

`CB_PARAMETER_LOGGING_BLOCKER_MODE_B_NOT_RERUN`

这不是科学结果 blocker，也不影响 `L_full-L_frozen` 的 loss decomposition；它只限制了对 CB fitted adaptation 的参数级归因。

Gaussian full parameters同样未持久化，且没有为了 instrumentation 重新运行。

---

## 10. Two-layer mechanism 的最终裁决

### 10.1 Layer 1：state-writing / working-P dynamics

本轮支持以下局部事实：

- Huber/MB/CB 在 terminal contamination 下 frozen-fit 明显优于 frozen Gaussian；
- `d=2` recovery advantage 在 frozen layer 已经出现；
- CB 在 Recovery Boundary 的 frozen layer 稳定优于 MB；
- 因此 bounded observation-to-state writing 与 working-P recovery 不是完整拟合的伪影。

### 10.2 Layer 2：fitted adaptation

本轮同时支持：

- Huber/MB/CB 的 `A_fit` 在 Primary/Replication 中大幅为正；
- Yearly terminal failure 主要被 full refit 放大；
- Quarterly negative crossing 的巨大异常主要集中于 fitted adaptation；
- CB/MB 在 Primary/Replication 的 relative ranking 可因 fitted-layer differential 而反转。

因此 fitted layer 不是外围 nuisance，而是完整 forecasting system 的第二个机制层。

### 10.3 最终判定

**Two-layer mechanism：SUPPORTED。**

更完整的表述：

> Robust Structural Theta 的 complete-system behavior 由至少两个可分离层决定：  
> （1）local state-writing / covariance dynamics 决定污染如何进入并如何被后续 clean observations 修复；  
> （2）complete fitting 决定污染是否通过 parameter adaptation 再次写入整个预测系统。  
> 局部保护可以成立而 complete fitted robustness 仍失败；反之，某些方法间的 full-system 排序也可主要来自 adaptation cost differential，而非局部 update 优势。

---

## 11. 对当前论文主线的影响

### 11.1 不需要推翻主线

当前 `protection–adaptation boundary` paper spine 与本轮结果一致，甚至比此前更有直接证据支撑。

本轮不要求回到旧的“哪个 robust update 赢 benchmark”叙事，也不支持继续扩充污染网格。

### 11.2 必须重写的机制归因

论文后续至少应完成三项科学重构：

1. **把 local robustness 与 fitted robustness 明确分层。**  
   Formal B / Gate M 对应第一层；本轮 decomposition 给出两层之间的桥梁。

2. **重写 CB vs MB 的解释。**  
   Recovery Boundary 可以用 working-P coupling 的 local increment 解释；Primary/Replication 的 complete-system relative advantage 不能全部这样解释，必须纳入 fitted adaptation differential。

3. **重写 Yearly 与 Quarterly-negative 的失败解释。**  
   Yearly：local difficulty + strong refit amplification。  
   Quarterly crossing：domain interaction + fitted adaptation amplification。  
   不再用单一 `rho`、单一 short-n 或单一 bounded-update failure 解释。

### 11.3 不应做的事

本轮结果不构成以下授权：

- 不把 Frozen Mode A 包装成新的 deployable forecasting method；
- 不开启 `rho=5%`；
- 不新增 contamination geometry；
- 不新增 benchmark / comparator；
- 不根据 decomposition 继续调 Huber、nu、CB 或 optimizer；
- 不自动修改论文正文；
- 不继续寻找更有利 subgroup。

Frozen Mode A 是一个 **mechanism-identification counterfactual**：它回答“如果污染不能进入 fitted layer，只能进入 sequential state recursion，会发生什么”。它不是实际部署系统的直接候选。

---

## 12. T33 应据此裁决的论文级命题

建议 T33 在理论与 manuscript adjudication 中围绕以下三个命题收束，而不是再开实验。

### 命题 A：Local protection is real but not sufficient

bounded state-writing 在 real-series contamination setting 中具有直接可识别的保护作用，但 local robustness 不推出 complete fitted robustness。

### 命题 B：Adaptation can overwrite protection

当 contaminated history 同时进入 parameter fitting 时，fitted adaptation 可产生大于 local contamination effect 的二次损失；Yearly 与 Quarterly crossing 是两个最清晰的 amplification regimes。

### 命题 C：Covariance coupling has a conditional, not universal, role

CB 的 working-P coupling 在 Recovery Boundary 中有直接 frozen-layer increment；但在 terminal contamination 中，其 full-system relative advantage还依赖较低的 fitted adaptation cost。因而 coupling 的作用应写成 **conditional mechanism**，而不是 universal dominance claim。

---

## 13. 最终状态

本轮 scientific decomposition 已闭合。

`NEW_BENCHMARK_SEARCH = STOP`

`NEW_CONTAMINATION_SEARCH = STOP`

`NEW_FORECASTING_EXPERIMENTS = STOP`

`FITTED_LAYER_DECOMPOSITION = COMPLETE`

`TWO_LAYER_MECHANISM = SUPPORTED`

`CB_LOCAL_COUPLING_INCREMENT = SUPPORTED_IN_RECOVERY_BOUNDARY`

`PRIMARY_REPLICATION_CB_ADVANTAGE = PARTLY_FITTED_ADAPTATION_DIFFERENTIAL`

`HUBER_COMPLETE_SYSTEM_FAILURE = MAINLY_FITTED_LAYER_AMPLIFICATION`

`YEARLY_FAILURE = LOCAL_DIFFICULTY_PLUS_STRONG_REFIT_AMPLIFICATION`

`QUARTERLY_NEGATIVE_CROSSING = DOMAIN_INTERACTION_PLUS_FITTED_LAYER_AMPLIFICATION`

`CB_PARAMETER_LOGGING_BLOCKER = MODE_B_NOT_RERUN`

`RETURN_TO_T33_FOR_THEORY_AND_MANUSCRIPT_ADJUDICATION = TRUE`

---

## 14. 一句话交接

> **本轮最终机制分解支持“local state-writing protection + complete fitted adaptation”两层结构：局部 bounded update 与 recovery dynamics 确实提供保护，但 contaminated refitting 会在 Yearly、terminal contamination 与 Quarterly domain crossing 中显著侵蚀该保护；CB 的 local working-P 增量主要在 Recovery Boundary 可直接识别，而 Primary/Replication 的 CB–MB full-system 排序还受到 fitted adaptation differential 的实质影响。**
