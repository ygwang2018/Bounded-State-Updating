options(stringsAsFactors = FALSE, warn = 1)
.libPaths(unique(c(
  "",
  "",
  .libPaths()
)))

OUT <- "M3/fitted_layer"
FORMAL <- "M3/formal_gate_f"
ADAPTER <- "method_code/gate_f_fitted_adapters.R"
AUTH <- "method_code"
RUNTIME <- file.path(AUTH, "frozen_runtime")

dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

for (rf in c(
  "rst_o_config.R", "rst_o_filters.R", "rst_o_objectives.R",
  "rst_o_optimizer.R", "rst_o_fit.R", "rst_o_forecast.R",
  "rst_o_v1_7_revised_baselines.R"
)) source(file.path(RUNTIME, "R", rf))
source(file.path(AUTH, "n1_method_adapters.R"))
source(ADAPTER)

data("M3", package = "Mcomp", envir = environment())
stopifnot(length(M3) == 3003L, as.character(packageVersion("Mcomp")) == "2.8")

FORMAL_RAW <- file.path(FORMAL, "FORMAL_GATE_F_SERIES_METHOD_RESULTS.csv")
formal <- read.csv(FORMAL_RAW, check.names = FALSE)
stopifnot(nrow(formal) == 126126L)

methods <- c("GAUSSIAN_ST", "HUBER_ST", "MB", "CB")
conds <- data.frame(
  condition = c(
    "PRIMARY_CORE_NEG","PRIMARY_CORE_POS",
    "REPLICATION_CORE_NEG","REPLICATION_CORE_POS",
    "RECOVERY_BOUNDARY_NEG","RECOVERY_BOUNDARY_POS"
  ),
  k = c(3L,3L,5L,5L,3L,3L),
  d = c(0L,0L,0L,0L,2L,2L),
  sign = c(-1L,1L,-1L,1L,-1L,1L)
)

RAW <- file.path(OUT, "FITTED_LAYER_DECOMPOSITION_SERIES_RESULTS.csv")
PAR <- file.path(OUT, "FITTED_LAYER_PARAMETER_DIAGNOSTICS.csv")
PROG <- file.path(OUT, "FITTED_LAYER_DECOMPOSITION_PROGRESS.txt")

scale_den <- function(y, f) {
  lag <- if (f > 1L) f else 1L
  d <- y[(lag + 1L):length(y)] - y[1L:(length(y) - lag)]
  c(MASE = mean(abs(d)), RMSSE = sqrt(mean(d^2)))
}
score <- function(actual, fc, den) c(
  MASE = unname(mean(abs(actual - fc)) / den["MASE"]),
  RMSSE = unname(sqrt(mean((actual - fc)^2)) / den["RMSSE"])
)
make_train <- function(clean, k, d, sgn) {
  sc <- max(sd(clean), IQR(clean, type = 7) / 1.349, 1e-6, na.rm = TRUE)
  idx <- (length(clean) - d - k + 1L):(length(clean) - d)
  z <- clean
  z[idx] <- z[idx] + sgn * 6 * sc
  z
}

clean_seasonal_freeze <- function(y_train, horizon, frequency) {
  y_train <- as.numeric(y_train)
  frequency <- as.integer(frequency)
  horizon <- as.integer(horizon)
  if (frequency <= 1L) {
    return(list(
      trim_start = 1L, n_eff = length(y_train), sfactors = 1,
      y_sa = y_train, sfactout = rep(1, horizon)
    ))
  }
  nz <- which(y_train != 0)
  trim_start <- if (length(nz)) nz[[1L]] else 1L
  y <- y_train[trim_start:length(y_train)]
  s <- frequency
  if (length(y) <= s) stop("training series too short for frozen seasonal factors")
  w <- rep(1 / (2 * s), s + 1L); w[2:s] <- 1 / s
  cma <- matrix(NA_real_, length(y), 1L)
  for (g in seq_len(length(y) - s)) cma[g + s / 2] <- sum(w * y[g:(g + s)])
  residuals <- y / cma
  sfactors <- numeric(s)
  for (seas in seq_len(s)) {
    sfactors[[seas]] <- mean(stats::na.omit(residuals[
      seq(seas, length(y) - s + seas, by = s)
    ]))
  }
  sfactors <- sfactors * s / sum(sfactors)
  patt <- rep(sfactors, ceiling(length(y) / s))[seq_along(y)]
  sfactout <- rep(sfactors, length(y) + horizon)[
    (length(y) + 1L):(length(y) + horizon)
  ]
  list(
    trim_start = trim_start, n_eff = length(y), sfactors = sfactors,
    y_sa = y / patt, sfactout = sfactout
  )
}
apply_frozen_seasonal <- function(y, freeze) {
  z <- as.numeric(y)[freeze$trim_start:length(y)]
  if (length(freeze$sfactors) == 1L) return(z)
  patt <- rep(freeze$sfactors, ceiling(length(z) / length(freeze$sfactors)))[seq_along(z)]
  z / patt
}

fixed_author_gaussian <- function(y, omega, q, horizon) {
  n <- length(y)
  state <- p <- rep(0, n + 1L)
  state[1L] <- y[1L]; p[1L] <- 10000
  k <- inn <- numeric(n)
  k[1L] <- p[1L] / (p[1L] + 1)
  p[2L] <- p[1L] - p[1L] * k[1L] + q
  state[2L] <- omega + state[1L]
  if (n >= 2L) for (t in 2:n) {
    k[t] <- p[t] / (p[t] + 1)
    inn[t] <- y[t] - state[t]
    p[t + 1L] <- p[t] - p[t] * k[t] + q
    state[t + 1L] <- omega + state[t] + k[t] * inn[t]
  }
  state[n + 1L] + omega * (0:(horizon - 1L))
}


fit_author_gaussian_m3 <- function(y, horizon) {
  likelihood <- function(parameters) {
    q <- abs(parameters[1L]); co <- abs(parameters[2L]); n <- length(y)
    state <- p <- rep(0, n + 1L); state[1L] <- y[1L]; p[1L] <- 10000
    k <- inn <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1); sigmae <- 0
    p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- co + state[1L]
    if (n >= 2L) for (t in 2:n) {
      k[t] <- p[t] / (p[t] + 1); inn[t] <- y[t] - state[t]
      sigmae <- sigmae + inn[t]^2 / (p[t] + 1)
      p[t + 1L] <- p[t] - p[t] * k[t] + q
      state[t + 1L] <- co + state[t] + k[t] * inn[t]
    }
    sum(log(p + 1)) + n * log(sigmae / n)
  }
  op <- stats::optim(c(.01, 1), likelihood)
  q <- abs(op$par[1L]); co <- abs(op$par[2L])
  fc <- fixed_author_gaussian(y, co, q, horizon)
  # Recompute H exactly as in isolated M3 author kernel.
  n <- length(y); state <- p <- rep(0, n + 1L); state[1L] <- y[1L]; p[1L] <- 10000
  k <- inn <- numeric(n); k[1L] <- p[1L] / (p[1L] + 1); sigmae <- 0
  p[2L] <- p[1L] - p[1L] * k[1L] + q; state[2L] <- co + state[1L]
  if (n >= 2L) for (t in 2:n) { k[t] <- p[t]/(p[t]+1); inn[t] <- y[t]-state[t]; sigmae <- sigmae + inn[t]^2/(p[t]+1); p[t+1L] <- p[t]-p[t]*k[t]+q; state[t+1L] <- co+state[t]+k[t]*inn[t] }
  list(mean=fc, q_fit=q, omega_fit=co, H_fit=sigmae/(n-1L), optim=op)
}

clean_fits <- function(clean, h, f) {
  seas <- clean_seasonal_freeze(clean, h, f)
  ys <- seas$y_sa
  g <- fit_author_gaussian_m3(ys, h)
  hb <- gate_f_optimize(ys, "HUBER")
  mb <- gate_f_optimize(ys, "MB")
  cb <- rst_o_fit(ys, nu = 5)
  list(seas = seas, GAUSSIAN_ST = g, HUBER_ST = hb, MB = mb, CB = cb)
}

frozen_forecast <- function(m, y_contam, h, fits) {
  ys <- apply_frozen_seasonal(y_contam, fits$seas)
  sf <- fits$seas$sfactout
  if (m == "GAUSSIAN_ST") {
    fit <- fits$GAUSSIAN_ST
    return(fixed_author_gaussian(ys, fit$omega_fit, fit$q_fit, h) * sf)
  }
  if (m == "HUBER_ST") {
    fit <- fits$HUBER_ST
    ff <- gate_f_huber_filter(
      ys, fit$fit_inputs$omega, fit$fit_inputs$q, fit$fit_inputs$H
    )
    return(gate_f_forecast(ff, h) * sf)
  }
  if (m == "MB") {
    fit <- fits$MB
    ff <- gate_f_mb_filter(
      ys, fit$fit_inputs$omega, fit$fit_inputs$q, fit$fit_inputs$H
    )
    return(gate_f_forecast(ff, h) * sf)
  }
  if (m == "CB") {
    fit <- fits$CB
    ff <- rst_o_filter_finite_nu(
      ys, fit$omega_hat, fit$q_hat, fit$H_hat, 5
    )
    return(rst_o_forecast(ff, h) * sf)
  }
  stop("unknown method")
}

param_row <- function(i, s, m, fit) {
  if (m == "GAUSSIAN_ST") {
    return(data.frame(
      series_index=i, series_name=as.character(s$sn), period=as.character(s$period),
      method=m, layer="CLEAN_FIT", q_fit=fit$q_fit, omega_fit=fit$omega_fit,
      H_fit=fit$H_fit, optimizer_status=as.character(fit$optim$convergence),
      boundary_hit=NA, objective_value=as.numeric(fit$optim$value),
      parameter_logging_status="OK"
    ))
  }
  if (m %in% c("HUBER_ST","MB")) {
    return(data.frame(
      series_index=i, series_name=as.character(s$sn), period=as.character(s$period),
      method=m, layer="CLEAN_FIT", q_fit=fit$fit_inputs$q,
      omega_fit=fit$fit_inputs$omega, H_fit=fit$fit_inputs$H,
      optimizer_status=fit$optimizer$selected_source,
      boundary_hit=NA, objective_value=fit$optimizer$objective_final,
      parameter_logging_status="OK"
    ))
  }
  data.frame(
    series_index=i, series_name=as.character(s$sn), period=as.character(s$period),
    method=m, layer="CLEAN_FIT", q_fit=fit$q_hat, omega_fit=fit$omega_hat,
    H_fit=fit$H_hat, optimizer_status=fit$optimizer$optimizer_status,
    boundary_hit=fit$optimizer$boundary_flag,
    objective_value=fit$optimizer$objective_value_final,
    parameter_logging_status="OK"
  )
}

full_par <- formal[
  formal$method %in% c("HUBER_ST","MB") &
    formal$condition %in% conds$condition,
  c("series_index","series_name","period","condition","method","q_fit","omega_fit","H_fit")
]
full_par$layer <- "FULL_REFIT_EXISTING"
full_par$optimizer_status <- NA_character_
full_par$boundary_hit <- NA
full_par$objective_value <- NA_real_
full_par$parameter_logging_status <- "RECOVERED_FROM_FORMAL_GATE_F_RAW"

cb_block <- unique(formal[
  formal$method %in% c("CB","GAUSSIAN_ST") &
    formal$condition %in% conds$condition,
  c("series_index","series_name","period","condition","method")
])
cb_block$q_fit <- cb_block$omega_fit <- cb_block$H_fit <- NA_real_
cb_block$layer <- "FULL_REFIT_EXISTING"
cb_block$optimizer_status <- NA_character_
cb_block$boundary_hit <- NA
cb_block$objective_value <- NA_real_
cb_block$parameter_logging_status <- ifelse(
  cb_block$method == "CB",
  "CB_PARAMETER_LOGGING_BLOCKER_MODE_B_NOT_RERUN",
  "GAUSSIAN_FULL_PARAMETER_NOT_PERSISTED_MODE_B_NOT_RERUN"
)

start_i <- 1L
if (file.exists(RAW)) {
  old <- read.csv(RAW)
  done <- unique(old$series_index)
  if (length(done)) start_i <- max(done) + 1L
}

if (start_i <= 3003L) for (i in start_i:3003L) {
  s <- M3[[i]]
  clean <- as.numeric(s$x)
  actual <- as.numeric(s$xx)
  h <- as.integer(s$h)
  f <- as.integer(frequency(s$x))
  den <- scale_den(clean, f)

  cf <- try(clean_fits(clean, h, f), silent = TRUE)
  if (inherits(cf, "try-error")) stop(sprintf("clean fit failure series %d: %s", i, cf))

  rows <- vector("list", nrow(conds) * length(methods))
  rr <- 0L
  for (ci in seq_len(nrow(conds))) {
    cc <- conds[ci,]
    y <- make_train(clean, cc$k, cc$d, cc$sign)
    clean_positive <- all(clean > 0)
    crossing <- clean_positive && any(y <= 0)
    domain_group <- if (!clean_positive) "ALREADY_NONPOSITIVE" else if (crossing) "CROSSING" else "NO_CROSSING_ELIGIBLE"
    for (m in methods) {
      rr <- rr + 1L
      ans <- try(frozen_forecast(m, y, h, cf), silent = TRUE)
      if (inherits(ans, "try-error") || length(ans) != h || any(!is.finite(ans))) {
        stop(sprintf("Mode A failure series=%d condition=%s method=%s", i, cc$condition, m))
      }
      met <- score(actual, ans, den)
      full <- formal[
        formal$series_index == i &
          formal$condition == cc$condition &
          formal$method == m, ,
        drop = FALSE
      ]
      if (nrow(full) != 1L) stop("Mode B key mismatch")
      rows[[rr]] <- data.frame(
        series_index=i, series_name=as.character(s$sn), period=as.character(s$period),
        frequency=f, h=h, n_train=length(clean), condition=cc$condition,
        k=cc$k, d=cc$d, sign=cc$sign, domain_group=domain_group, method=m,
        MASE_frozen=met["MASE"], RMSSE_frozen=met["RMSSE"],
        MASE_full=full$MASE, RMSSE_full=full$RMSSE,
        A_fit_MASE=full$MASE-met["MASE"],
        A_fit_RMSSE=full$RMSSE-met["RMSSE"]
      )
    }
  }
  chunk <- do.call(rbind, rows)
  write.table(
    chunk, RAW, sep=",", row.names=FALSE,
    col.names=!file.exists(RAW), append=file.exists(RAW),
    qmethod="double", quote=TRUE
  )

  pr <- do.call(rbind, lapply(methods, function(m) param_row(i, s, m, cf[[m]])))
  write.table(
    pr, PAR, sep=",", row.names=FALSE,
    col.names=!file.exists(PAR), append=file.exists(PAR),
    qmethod="double", quote=TRUE
  )
  if (i %% 10L == 0L || i == 3003L) {
    writeLines(sprintf("completed_series=%d/3003 time=%s", i, Sys.time()), PROG)
  }
}

res <- read.csv(RAW, check.names=FALSE)
stopifnot(nrow(res) == 3003L * 6L * 4L, length(unique(res$series_index)) == 3003L)

clean_par <- read.csv(PAR, check.names=FALSE)
par_all <- rbind(
  transform(clean_par, condition=NA_character_)[
    ,c("series_index","series_name","period","condition","method","q_fit","omega_fit","H_fit",
       "layer","optimizer_status","boundary_hit","objective_value","parameter_logging_status")
  ],
  full_par[,c("series_index","series_name","period","condition","method","q_fit","omega_fit","H_fit",
              "layer","optimizer_status","boundary_hit","objective_value","parameter_logging_status")],
  cb_block[,c("series_index","series_name","period","condition","method","q_fit","omega_fit","H_fit",
              "layer","optimizer_status","boundary_hit","objective_value","parameter_logging_status")]
)
write.csv(par_all, PAR, row.names=FALSE)

families <- list(
  PRIMARY_CORE=c("PRIMARY_CORE_NEG","PRIMARY_CORE_POS"),
  REPLICATION_CORE=c("REPLICATION_CORE_NEG","REPLICATION_CORE_POS"),
  RECOVERY_BOUNDARY=c("RECOVERY_BOUNDARY_NEG","RECOVERY_BOUNDARY_POS")
)
pool <- list(); pp <- 0L
for (fam in names(families)) for (m in methods) {
  z <- res[res$condition %in% families[[fam]] & res$method == m,]
  tmp <- aggregate(
    cbind(MASE_frozen,RMSSE_frozen,MASE_full,RMSSE_full,A_fit_MASE,A_fit_RMSSE) ~
      series_index + series_name + period + n_train,
    data=z, FUN=mean
  )
  tmp$cell <- fam; tmp$method <- m
  pp <- pp + 1L; pool[[pp]] <- tmp
}
pooled <- do.call(rbind, pool)

summary_rows <- list(); ss <- 0L
for (cell in unique(pooled$cell)) for (m in methods) {
  z <- pooled[pooled$cell == cell & pooled$method == m,]
  for (per in c("ALL","YEARLY","QUARTERLY","MONTHLY","OTHER")) {
    zz <- if (per == "ALL") z else z[z$period == per,]
    if (!nrow(zz)) next
    for (metric in c("MASE","RMSSE")) {
      ss <- ss + 1L
      af <- zz[[paste0("A_fit_",metric)]]
      summary_rows[[ss]] <- data.frame(
        cell=cell, method=m, period=per, metric=metric, n=nrow(zz),
        frozen_mean=mean(zz[[paste0(metric,"_frozen")]]),
        full_mean=mean(zz[[paste0(metric,"_full")]]),
        A_fit_mean=mean(af), A_fit_median=median(af),
        A_fit_positive_pct=100*mean(af > 0)
      )
    }
  }
}
summary_df <- do.call(rbind, summary_rows)
write.csv(summary_df, file.path(OUT,"FITTED_LAYER_DECOMPOSITION_SUMMARY.csv"), row.names=FALSE)

set.seed(202607131)
B <- 5000L
boot_rows <- list(); bb <- 0L
for (j in seq_len(nrow(summary_df))) {
  sr <- summary_df[j,]
  z <- pooled[pooled$cell==sr$cell & pooled$method==sr$method,]
  if (sr$period != "ALL") z <- z[z$period==sr$period,]
  x <- z[[paste0("A_fit_",sr$metric)]]
  vals <- numeric(B); n <- length(x)
  for (b in seq_len(B)) vals[b] <- mean(x[sample.int(n,n,TRUE)])
  bb <- bb + 1L
  boot_rows[[bb]] <- data.frame(
    cell=sr$cell, method=sr$method, period=sr$period, metric=sr$metric, n=n,
    A_fit_mean=mean(x),
    ci_low=unname(quantile(vals,.025,type=7)),
    ci_high=unname(quantile(vals,.975,type=7))
  )
}
boot <- do.call(rbind, boot_rows)
write.csv(boot, file.path(OUT,"FITTED_LAYER_DECOMPOSITION_BOOTSTRAP.csv"), row.names=FALSE)

writeLines(
  sprintf("completed_series=3003/3003 finalized=%s STOP=TRUE", Sys.time()),
  PROG
)
