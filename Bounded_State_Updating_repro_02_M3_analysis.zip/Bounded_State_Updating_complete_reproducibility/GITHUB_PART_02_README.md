# Part 2: M3 analysis

Contains the M3 analysis code and supporting outputs. Extract into the same parent directory as Parts 1, 3, and 4.
