# Part 4: M3 primary fits

Contains the large series-level `R1_M3_PRIMARY_FITS.csv` record. Extract into the same parent directory as Parts 1, 2, and 3.
